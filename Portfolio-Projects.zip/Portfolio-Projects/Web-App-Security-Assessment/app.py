"""
Web Application Security Assessment — Complete Flask Application
Interactive OWASP Top 10 security lab, exploitation walk-throughs, secure code mitigations.
"""

import os
from flask import Flask, render_template_string, request, redirect, url_for, jsonify

app = Flask(__name__)
app.secret_key = "webapp-security-secret"

# ── Vulnerability Lab Data ──────────────────────────────────────────────────

VULNERABILITIES = {
    "sqli": {
        "title": "SQL Injection (SQLi) - OWASP A03:2021",
        "description": "SQL injection occurs when user-supplied data is concatenated directly into a database query, allowing an attacker to manipulate the SQL statement.",
        "vulnerable_code": "query = \"SELECT * FROM users WHERE username = '\" + user_input + \"' AND password = '\" + password + \"'\"",
        "secure_code": "query = \"SELECT * FROM users WHERE username = %s AND password = %s\"\ncursor.execute(query, (user_input, password))",
        "demo_payload": "' OR '1'='1",
        "explanation": "Using the payload ' OR '1'='1 bypasses password checks because '1'='1' is always true, resulting in logging in as the first user in the database."
    },
    "xss": {
        "title": "Cross-Site Scripting (XSS) - OWASP A03:2021",
        "description": "Cross-Site Scripting vulnerabilities occur when an application includes untrusted data in a web page without proper validation or escaping, leading to execution of malicious scripts in the user's browser.",
        "vulnerable_code": "return \"<h1>Welcome, \" + user_input + \"!</h1>\"",
        "secure_code": "import html\nreturn \"<h1>Welcome, \" + html.escape(user_input) + \"!</h1>\"",
        "demo_payload": "<script>alert('XSS Stolen Cookie: ' + document.cookie)</script>",
        "explanation": "If the input is not sanitized, the browser interprets the script tags and executes the JavaScript code within the context of the user's session."
    },
    "csrf": {
        "title": "Cross-Site Request Forgery (CSRF) - OWASP A01:2021",
        "description": "CSRF is an attack that forces an end user to execute unwanted actions on a web application in which they're currently authenticated.",
        "vulnerable_code": "<form action='/transfer' method='POST'>\n  <input type='text' name='to'>\n  <input type='submit'>\n</form>",
        "secure_code": "<form action='/transfer' method='POST'>\n  <input type='hidden' name='csrf_token' value='{{ csrf_token() }}'>\n  <input type='text' name='to'>\n  <input type='submit'>\n</form>",
        "demo_payload": "<img src='http://bank.com/transfer?to=attacker&amount=10000' width='0' height='0'>",
        "explanation": "When an authenticated user loads the attacker's site, the browser automatically sends the session cookies to bank.com, executing the unauthorized transfer."
    },
    "ssrf": {
        "title": "Server-Side Request Forgery (SSRF) - OWASP A10:2021",
        "description": "SSRF allows an attacker to abuse functionality on the server to read or update internal resources that are otherwise inaccessible.",
        "vulnerable_code": "import requests\nresponse = requests.get(request.args.get('url'))\nreturn response.text",
        "secure_code": "from urllib.parse import urlparse\nallowed_domains = ['api.trusted.com']\nparsed_url = urlparse(url)\nif parsed_url.netloc in allowed_domains:\n    response = requests.get(url)",
        "demo_payload": "http://169.254.169.254/latest/meta-data/",
        "explanation": "Providing the AWS metadata IP (169.254.169.254) allows the attacker to query the instance metadata service from the server side and steal cloud credentials."
    }
}

# In-memory logs
reports = []

# ── Templates ──────────────────────────────────────────────────────────────

TMPL = """
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Web App Security Assessment Lab</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#090d16;--bg2:#0f1524;--card:#151e36;--text:#e2e8f0;--dim:#94a3b8;--blue:#2563eb;--red:#dc2626;--orange:#d97706;--green:#16a34a;--border:#1e293b;--purple:#7c3aed;--cyan:#0891b2}
body{font-family:'Segoe UI',sans-serif;background:var(--bg);color:var(--text)}
.header{background:linear-gradient(135deg,#151e36,#0c111c);border-bottom:1px solid var(--border);padding:16px 32px;display:flex;align-items:center;justify-content:space-between}
.header h1{font-size:1.4rem;background:linear-gradient(135deg,#0891b2,#7c3aed);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav{background:var(--bg2);border-bottom:1px solid var(--border);display:flex;padding:0 32px}
.nav a{color:var(--dim);text-decoration:none;padding:12px 18px;font-size:.85rem;font-weight:500;border-bottom:2px solid transparent;transition:.2s}
.nav a:hover,.nav a.active{color:var(--cyan);border-bottom-color:var(--cyan)}
.container{max-width:1400px;margin:0 auto;padding:24px}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:24px}
.card h2{font-size:1.1rem;margin-bottom:16px}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:600;text-transform:uppercase}
.badge.critical{background:rgba(220,38,38,.12);color:var(--red);border:1px solid rgba(220,38,38,.25)}
.badge.high{background:rgba(217,119,6,.12);color:var(--orange);border:1px solid rgba(217,119,6,.25)}
.btn{padding:8px 16px;border-radius:8px;border:none;cursor:pointer;font-size:.85rem;font-weight:500;transition:.2s;text-decoration:none;display:inline-block;margin:2px}
.btn-cyan{background:var(--cyan);color:#fff}.btn-red{background:var(--red);color:#fff}.btn-blue{background:var(--blue);color:#fff}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px}@media(max-width:768px){.two-col{grid-template-columns:1fr}}
pre{background:#020408;padding:16px;border-radius:8px;overflow-x:auto;font-family:monospace;font-size:.8rem;color:#00ffcc;border:1px solid var(--border);margin-bottom:12px}
pre.secure{color:#00ff66}
.expl-box{background:rgba(217,119,6,.05);border-left:4px solid var(--orange);padding:12px 16px;border-radius:4px;font-size:.85rem;margin-top:12px}
input[type=text]{width:100%;padding:10px 14px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text);font-size:.9rem;margin-bottom:12px}
.result-box{background:#0b0f19;border:1px solid var(--border);padding:16px;border-radius:8px;margin-top:12px}
</style></head><body>
<div class="header"><h1>🌐 Web Application Security Assessment</h1><span style="color:var(--dim);font-size:.8rem">OWASP Lab</span></div>
<div class="nav">
    <a href="/" class="{{ 'active' if page=='dash' }}">OWASP Lab</a>
    <a href="/reports" class="{{ 'active' if page=='reports' }}">Assessed Reports</a>
</div>
<div class="container">{% block c %}{% endblock %}</div>
</body></html>
"""

# ── Routes ─────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>🎯 OWASP Top 10 Vulnerability Lab</h2>
    <p style="color:var(--dim);margin-bottom:16px">Select a vulnerability from the panel below to examine exploitation and secure implementation strategies.</p>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
        <a href="/vuln/sqli" class="btn btn-cyan">💉 SQL Injection (SQLi)</a>
        <a href="/vuln/xss" class="btn btn-cyan">📜 Cross-Site Scripting (XSS)</a>
        <a href="/vuln/csrf" class="btn btn-cyan">🛡️ CSRF</a>
        <a href="/vuln/ssrf" class="btn btn-cyan">🌍 SSRF</a>
    </div>
</div>
<div class="card">
    <h2>📋 Assessment Methodology</h2>
    <p style="color:var(--dim);line-height:1.6">We follow standard OWASP testing guidelines to identify web vulnerabilities. The assessment covers Injection, Broken Authentication, Sensitive Data Exposure, XML External Entities (XXE), Broken Access Control, Security Misconfiguration, and Cross-Site Scripting (XSS). Remediation advice relies on defense-in-depth principles.</p>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="dash")


@app.route("/vuln/<vtype>", methods=["GET", "POST"])
def view_vuln(vtype):
    vuln = VULNERABILITIES.get(vtype)
    if not vuln:
        return redirect(url_for("index"))

    result = None
    if request.method == "POST":
        user_input = request.form.get("payload", "")
        # Simulated exploitation output
        if vtype == "sqli":
            if user_input.strip() == vuln["demo_payload"]:
                result = {
                    "status": "exploited",
                    "output": "Database Response:\n[+] Authentication Successful!\n[+] Logged in as: admin\n[+] Token: secret_admin_session_token_5528",
                    "log_msg": f"SQLi payload '{user_input}' bypassed authorization checks."
                }
            else:
                result = {
                    "status": "failed",
                    "output": f"Database Error: User '{user_input}' not found or password incorrect.",
                    "log_msg": f"Failed login attempt with input '{user_input}'"
                }
        elif vtype == "xss":
            result = {
                "status": "exploited",
                "output": f"Rendered HTML Output:\n<h1>Welcome, {user_input}!</h1>\n[!] Browser Warning: Script executed in DOM context.",
                "log_msg": f"XSS script executed successfully."
            }
        elif vtype == "csrf":
            result = {
                "status": "exploited",
                "output": "HTTP POST /transfer\nReferer: http://attacker.com\nCookie: session=authorized\n[+] Status: 200 OK\n[+] Transferred $10,000 to attacker account.",
                "log_msg": "Unauthorized action triggered via CSRF request cross-origin."
            }
        elif vtype == "ssrf":
            if "169.254.169.254" in user_input:
                result = {
                    "status": "exploited",
                    "output": "AWS Metadata Server Response:\n{\n  \"role\": \"admin-role\",\n  \"AccessKeyId\": \"ASIAIOSFODNN7EXAMPLE\",\n  \"SecretAccessKey\": \"wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY\"\n}",
                    "log_msg": "Cloud credentials exfiltrated via SSRF."
                }
            else:
                result = {
                    "status": "failed",
                    "output": f"Connection Refused: Internal address {user_input} is protected.",
                    "log_msg": f"SSRF block on {user_input}"
                }

        # Add to reports if exploited
        if result and result["status"] == "exploited":
            reports.append({
                "vtype": vtype,
                "title": vuln["title"],
                "payload": user_input,
                "output": result["output"],
                "date": datetime.now().strftime("%Y-%m-%d %H:%M")
            })

    content = TMPL.replace("{% block c %}{% endblock %}", """
<h2 style="margin-bottom:16px">{{ v.title }}</h2>
<div class="two-col">
    <div class="card">
        <h2>🔬 Vulnerability Description</h2>
        <p style="color:var(--dim);margin-bottom:16px;line-height:1.6">{{ v.description }}</p>
        
        <h2>🚨 Vulnerable Code (Flask/Python)</h2>
        <pre>{{ v.vulnerable_code }}</pre>
        
        <h2 style="color:var(--green)">🛡️ Secure Mitigated Implementation</h2>
        <pre class="secure">{{ v.secure_code }}</pre>
    </div>
    
    <div class="card">
        <h2>🛠️ Simulated Exploitation Lab</h2>
        <p style="color:var(--dim);margin-bottom:12px">Paste the demo payload below to execute the simulated attack.</p>
        <p style="margin-bottom:8px"><strong>Demo Payload:</strong> <code style="color:var(--orange)">{{ v.demo_payload }}</code></p>
        
        <form method="POST">
            <input type="text" name="payload" placeholder="Enter exploitation payload here..." required>
            <button type="submit" class="btn btn-red">💥 Execute Exploit</button>
        </form>
        
        {% if res %}
        <div class="result-box">
            <h4 style="margin-bottom:6px">Exploit Result: <span class="badge {% if res.status == 'exploited' %}critical{% else %}high{% endif %}">{{ res.status|upper }}</span></h4>
            <pre style="background:#05070c;border:1px solid #1e293b">{{ res.output }}</pre>
            <div class="expl-box">
                <strong>Mechanism:</strong> {{ v.explanation }}
            </div>
        </div>
        {% endif %}
    </div>
</div>
<a href="/" class="btn btn-blue">← Back</a>
""")
    from jinja2 import Template
    return Template(content).render(page="dash", v=vuln, res=result)


@app.route("/reports")
def view_reports():
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>📋 Vulnerability Assessment Report Logs ({{ reports|length }})</h2>
    {% if reports %}
    <table><thead><tr><th>Time</th><th>Vulnerability</th><th>Payload Used</th><th>Impact Output</th></tr></thead><tbody>
    {% for r in reports|reverse %}
    <tr>
        <td style="font-size:.75rem">{{ r.date }}</td>
        <td><strong>{{ r.title }}</strong></td>
        <td style="font-family:monospace;font-size:.8rem;color:var(--orange)">{{ r.payload }}</td>
        <td><pre style="margin:0;padding:6px;max-height:80px;font-size:.7rem">{{ r.output[:100] }}...</pre></td>
    </tr>{% endfor %}</tbody></table>
    {% else %}
    <p style="color:var(--dim);text-align:center;padding:20px">No vulnerabilities successfully exploited yet in this session.</p>
    {% endif %}
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="reports", reports=reports)


if __name__ == "__main__":
    print("\n  🌐 Web App Security Assessment — http://localhost:5009\n")
    app.run(debug=True, port=5009)
