# 🌐 Web Application Security Assessment
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge)](https://python.org)

Simulated OWASP Top 10 Web Application Security Assessment platform. Allows security testing and documentation of SQLi, XSS, CSRF, SSRF, XXE, and Authentication vulnerabilities with screenshots, descriptions, mitigation strategies, and executive report downloads.

## Features
- Interactive OWASP Top 10 vulnerability demonstration laboratory
- Practical walk-throughs for SQL Injection, Cross-Site Scripting (XSS), CSRF, XXE, SSRF
- Detailed mitigation code snippets in Python, PHP, JS, and Java
- Automated Executive Summary report generation (HTML/JSON)

## Quick Start
```bash
pip install -r requirements.txt
python app.py  # http://localhost:5009
```
## License — MIT — **Koventhan M**
