"""ThreatHunter Pro - Threat Hunting Platform.

A comprehensive threat hunting platform for security analysts.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional
from enum import Enum

__version__ = "1.0.0"
__author__ = "ThreatHunter Pro"


class Severity(Enum):
    """Detection severity levels."""
    INFORMATIONAL = "informational"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class LogEntry:
    """Represents a single log entry from any source."""
    timestamp: datetime
    source: str
    event_id: int
    data: dict[str, Any] = field(default_factory=dict)
    raw: str = ""
    computer: str = ""
    provider: str = ""

    def get(self, key: str, default: Any = None) -> Any:
        """Get a value from the data dictionary."""
        return self.data.get(key, default)

    def __str__(self) -> str:
        return f"[{self.timestamp}] {self.source} EventID={self.event_id} | {self.data}"


@dataclass
class Detection:
    """Represents a detection/alert from rule evaluation."""
    rule_name: str
    severity: Severity
    description: str
    matched_log: LogEntry
    mitre_tactic: str = ""
    mitre_technique: str = ""
    timestamp: datetime = field(default_factory=datetime.now)
    rule_id: str = ""
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class IOC:
    """Indicator of Compromise."""
    ioc_type: str  # ip, hash, domain
    value: str
    source: str = ""
    category: str = ""
    description: str = ""
    added_date: datetime = field(default_factory=datetime.now)
    active: bool = True


@dataclass
class HuntResult:
    """Result from a hunt query."""
    query: str
    matches: list[LogEntry] = field(default_factory=list)
    total_searched: int = 0
    timestamp: datetime = field(default_factory=datetime.now)
    duration_ms: float = 0.0


@dataclass
class TimelineEvent:
    """A single event in an investigation timeline."""
    timestamp: datetime
    event_type: str
    description: str
    severity: Severity = Severity.INFORMATIONAL
    source: str = ""
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class ThreatReport:
    """Comprehensive threat hunting report."""
    title: str
    summary: str = ""
    detections: list[Detection] = field(default_factory=list)
    hunt_results: list[HuntResult] = field(default_factory=list)
    timeline: list[TimelineEvent] = field(default_factory=list)
    ioc_matches: list[dict[str, Any]] = field(default_factory=list)
    generated_at: datetime = field(default_factory=datetime.now)
    analyst: str = "ThreatHunter Pro"
    recommendations: list[str] = field(default_factory=list)
