# 🎣 Phishing Detection Framework

[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![ML](https://img.shields.io/badge/Machine%20Learning-Scikit--Learn-orange?style=for-the-badge)](https://scikit-learn.org)

ML-powered phishing detection framework analyzing URLs, email headers, and content using feature engineering, NLP, and VirusTotal API integration. Provides real-time scoring dashboard.

## ✨ Features
- **URL Analysis** — Domain age, TLD, SSL, redirect chains, entropy scoring
- **Email Analysis** — Header inspection, SPF/DKIM/DMARC, reply-to mismatch, urgency language
- **ML Classification** — Random Forest model with 20+ engineered features
- **VirusTotal Integration** — API-based reputation checking
- **WHOIS Lookup** — Domain registration analysis
- **Dashboard** — Flask web UI with real-time scoring

## 🚀 Quick Start
```bash
pip install -r requirements.txt
python app.py  # http://localhost:5005
```
## 📜 License — MIT — **Koventhan M**
