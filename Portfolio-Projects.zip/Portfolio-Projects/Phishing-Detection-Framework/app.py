"""
Phishing Detection Framework — Complete Flask Application
URL analysis, email header inspection, ML classification, reputation checking, scoring dashboard.
"""

import os, re, math, json, random, hashlib
from datetime import datetime, timedelta
from urllib.parse import urlparse
from collections import Counter
from flask import Flask, render_template_string, request, redirect, url_for, jsonify
import numpy as np

app = Flask(__name__)
app.secret_key = "phishing-detect-secret"

# ── Feature Engineering ────────────────────────────────────────────────────

SUSPICIOUS_TLDS = [".tk", ".ml", ".ga", ".cf", ".gq", ".xyz", ".top", ".pw", ".cc", ".ws", ".info", ".buzz", ".click"]
BRAND_KEYWORDS = ["paypal", "apple", "microsoft", "google", "amazon", "netflix", "bank", "secure", "login", "verify", "update", "confirm", "account", "password", "suspended", "urgent"]
LEGITIMATE_DOMAINS = ["google.com", "microsoft.com", "apple.com", "amazon.com", "github.com", "linkedin.com", "facebook.com", "twitter.com", "paypal.com", "netflix.com"]

class URLAnalyzer:
    """Analyze URLs for phishing indicators."""

    @staticmethod
    def analyze(url: str) -> dict:
        try:
            parsed = urlparse(url if url.startswith("http") else f"http://{url}")
        except Exception:
            return {"error": "Invalid URL", "score": 100}

        domain = parsed.netloc or parsed.path.split("/")[0]
        path = parsed.path

        features = {}

        # Domain features
        features["domain_length"] = len(domain)
        features["has_ip"] = bool(re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}', domain))
        features["subdomain_count"] = domain.count(".") - 1
        features["has_at_symbol"] = "@" in url
        features["has_double_slash_redirect"] = "//" in path
        features["dash_count"] = domain.count("-")
        features["dot_count"] = domain.count(".")
        features["digit_count"] = sum(c.isdigit() for c in domain)
        features["has_https"] = url.startswith("https://")
        features["url_length"] = len(url)
        features["path_length"] = len(path)
        features["has_suspicious_tld"] = any(domain.endswith(tld) for tld in SUSPICIOUS_TLDS)
        features["brand_impersonation"] = any(kw in domain.lower() for kw in BRAND_KEYWORDS if kw not in domain.lower().split(".")[-2] if len(domain.split(".")) > 1)
        features["entropy"] = URLAnalyzer._entropy(domain)
        features["has_port"] = ":" in domain.split("@")[-1]
        features["special_char_count"] = sum(1 for c in url if c in "~!@#$%^&*()+={}[]|\\:;'<>,?")
        features["query_length"] = len(parsed.query)
        features["has_suspicious_words"] = any(w in url.lower() for w in ["login", "signin", "verify", "update", "secure", "confirm", "account", "password"])

        # Score calculation
        score = 0
        indicators = []

        if features["has_ip"]:
            score += 30; indicators.append("URL uses IP address instead of domain name")
        if features["has_suspicious_tld"]:
            score += 20; indicators.append(f"Suspicious TLD detected")
        if features["domain_length"] > 30:
            score += 10; indicators.append("Unusually long domain name")
        if features["subdomain_count"] > 3:
            score += 15; indicators.append(f"Excessive subdomains ({features['subdomain_count']})")
        if features["has_at_symbol"]:
            score += 25; indicators.append("@ symbol in URL — possible redirect")
        if features["dash_count"] > 3:
            score += 10; indicators.append(f"Excessive dashes in domain ({features['dash_count']})")
        if features["brand_impersonation"]:
            score += 25; indicators.append("Brand name impersonation detected")
        if features["entropy"] > 4.0:
            score += 10; indicators.append(f"High domain entropy ({features['entropy']:.2f}) — possibly random")
        if not features["has_https"]:
            score += 5; indicators.append("No HTTPS — insecure connection")
        if features["url_length"] > 75:
            score += 10; indicators.append("Unusually long URL")
        if features["has_suspicious_words"]:
            score += 15; indicators.append("Contains phishing-related keywords")

        score = min(score, 100)
        verdict = "phishing" if score >= 60 else "suspicious" if score >= 30 else "legitimate"

        return {
            "url": url, "domain": domain, "features": features,
            "score": score, "verdict": verdict, "indicators": indicators,
            "analyzed_at": datetime.utcnow().isoformat(),
        }

    @staticmethod
    def _entropy(s):
        if not s: return 0
        counter = Counter(s.lower())
        length = len(s)
        return -sum((c / length) * math.log2(c / length) for c in counter.values())


class EmailAnalyzer:
    """Analyze email headers and content for phishing indicators."""

    @staticmethod
    def analyze(email_data: dict) -> dict:
        score = 0
        indicators = []
        headers = email_data.get("headers", {})
        body = email_data.get("body", "")
        subject = email_data.get("subject", "")

        # Header analysis
        from_addr = headers.get("From", "")
        reply_to = headers.get("Reply-To", "")
        return_path = headers.get("Return-Path", "")
        received = headers.get("Received", [])
        spf = headers.get("SPF", "none")
        dkim = headers.get("DKIM", "none")
        dmarc = headers.get("DMARC", "none")

        # Reply-To mismatch
        if reply_to and from_addr and reply_to.split("@")[-1] != from_addr.split("@")[-1]:
            score += 25; indicators.append(f"Reply-To mismatch: {reply_to} vs From: {from_addr}")

        # SPF/DKIM/DMARC
        if spf == "fail":
            score += 20; indicators.append("SPF check FAILED")
        if dkim == "fail":
            score += 20; indicators.append("DKIM check FAILED")
        if dmarc == "fail":
            score += 15; indicators.append("DMARC check FAILED")
        if spf == "none":
            score += 5; indicators.append("No SPF record")

        # Subject urgency
        urgency_words = ["urgent", "immediately", "suspended", "verify now", "action required",
                         "your account", "click here", "expire", "limited time", "act now"]
        for word in urgency_words:
            if word in subject.lower() or word in body.lower():
                score += 5
                indicators.append(f"Urgency language detected: '{word}'")
                break

        # Links in body
        urls = re.findall(r'https?://[^\s<>"]+', body)
        if urls:
            for url in urls[:3]:
                url_result = URLAnalyzer.analyze(url)
                if url_result["verdict"] == "phishing":
                    score += 20; indicators.append(f"Phishing URL in body: {url}")
                elif url_result["verdict"] == "suspicious":
                    score += 10; indicators.append(f"Suspicious URL in body: {url}")

        # Attachment checks
        attachments = email_data.get("attachments", [])
        dangerous_ext = [".exe", ".scr", ".js", ".vbs", ".bat", ".cmd", ".ps1", ".hta"]
        for att in attachments:
            if any(att.lower().endswith(ext) for ext in dangerous_ext):
                score += 30; indicators.append(f"Dangerous attachment: {att}")

        score = min(score, 100)
        verdict = "phishing" if score >= 60 else "suspicious" if score >= 30 else "legitimate"

        return {
            "subject": subject, "from": from_addr, "score": score,
            "verdict": verdict, "indicators": indicators,
            "auth_results": {"spf": spf, "dkim": dkim, "dmarc": dmarc},
            "urls_found": len(urls), "attachments": attachments,
            "analyzed_at": datetime.utcnow().isoformat(),
        }


# ── Sample Data ────────────────────────────────────────────────────────────

SAMPLE_URLS = [
    "http://paypa1-secure-login.tk/verify/account",
    "https://www.google.com/search?q=python",
    "http://192.168.1.1/admin/login",
    "http://amaz0n-order-confirm.xyz/track?id=12345",
    "https://github.com/user/repo",
    "http://update-microsoft-security.ml/windows/fix",
    "https://www.linkedin.com/in/username",
    "http://login-netflix-verify.ga/secure/auth?token=abc",
    "http://free-iphone-winner.click/claim-now!!!",
    "https://docs.python.org/3/library/re.html",
]

SAMPLE_EMAILS = [
    {
        "subject": "URGENT: Your PayPal Account Has Been Suspended",
        "headers": {"From": "security@paypa1-alerts.tk", "Reply-To": "hacker@evil.com",
                    "Return-Path": "bounce@evil.com", "SPF": "fail", "DKIM": "fail", "DMARC": "fail"},
        "body": "Dear Customer, Your account has been suspended. Click here immediately: http://paypa1-secure.tk/login",
        "attachments": [],
    },
    {
        "subject": "Meeting Tomorrow at 3 PM",
        "headers": {"From": "john.smith@company.com", "Reply-To": "john.smith@company.com",
                    "Return-Path": "john.smith@company.com", "SPF": "pass", "DKIM": "pass", "DMARC": "pass"},
        "body": "Hi team, just a reminder about our meeting tomorrow at 3 PM in the conference room.",
        "attachments": ["meeting_agenda.pdf"],
    },
    {
        "subject": "Action Required: Verify Your Microsoft Account",
        "headers": {"From": "no-reply@micros0ft-security.xyz", "Reply-To": "attacker@darkmail.com",
                    "Return-Path": "attacker@darkmail.com", "SPF": "fail", "DKIM": "none", "DMARC": "fail"},
        "body": "Your Microsoft account will expire in 24 hours. Verify now: http://micros0ft-verify.xyz/auth",
        "attachments": ["security_update.exe"],
    },
    {
        "subject": "Invoice #INV-2024-3456",
        "headers": {"From": "billing@company.com", "Reply-To": "billing@company.com",
                    "Return-Path": "billing@company.com", "SPF": "pass", "DKIM": "pass", "DMARC": "pass"},
        "body": "Please find attached the invoice for March 2024 services.",
        "attachments": ["invoice_march.pdf"],
    },
]

# Store results
url_results = []
email_results = []


# ── Routes ─────────────────────────────────────────────────────────────────

TMPL = """
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Phishing Detection Framework</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#080c18;--bg2:#0e1526;--card:#141e38;--text:#dde4ef;--dim:#6e7d95;--blue:#4a8ef7;--purple:#9266f5;--red:#ef4444;--orange:#f59e0b;--green:#22c55e;--border:#1e2d4a}
body{font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:var(--text)}
.header{background:linear-gradient(135deg,#141e38,#0b1020);border-bottom:1px solid var(--border);padding:16px 32px}
.header h1{font-size:1.4rem;background:linear-gradient(135deg,#f59e0b,#ef4444);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav{background:var(--bg2);border-bottom:1px solid var(--border);display:flex;padding:0 32px}
.nav a{color:var(--dim);text-decoration:none;padding:12px 18px;font-size:.85rem;border-bottom:2px solid transparent;transition:.2s}
.nav a:hover,.nav a.active{color:var(--orange);border-bottom-color:var(--orange)}
.container{max-width:1400px;margin:0 auto;padding:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:24px}
.stat{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:20px}
.stat .label{font-size:.7rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}
.stat .val{font-size:1.8rem;font-weight:700}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:24px}
.card h2{font-size:1.1rem;margin-bottom:16px}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:10px;font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:var(--dim);border-bottom:1px solid var(--border)}
td{padding:10px;border-bottom:1px solid var(--border);font-size:.85rem}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:600;text-transform:uppercase}
.badge.phishing{background:rgba(239,68,68,.12);color:var(--red);border:1px solid rgba(239,68,68,.25)}
.badge.suspicious{background:rgba(245,158,11,.12);color:var(--orange);border:1px solid rgba(245,158,11,.25)}
.badge.legitimate{background:rgba(34,197,94,.12);color:var(--green);border:1px solid rgba(34,197,94,.25)}
.btn{padding:8px 16px;border-radius:8px;border:none;cursor:pointer;font-size:.85rem;font-weight:500;transition:.2s;text-decoration:none;display:inline-block;margin:2px}
.btn-orange{background:var(--orange);color:#fff}.btn-blue{background:var(--blue);color:#fff}
.btn-red{background:var(--red);color:#fff}.btn-sm{padding:4px 12px;font-size:.75rem}
input[type=text],textarea{width:100%;padding:10px 14px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text);font-size:.9rem;margin-bottom:12px}
.indicator{padding:6px 12px;margin:4px 0;background:rgba(239,68,68,.05);border-left:3px solid var(--red);border-radius:4px;font-size:.85rem}
.indicator.safe{border-color:var(--green);background:rgba(34,197,94,.05)}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px}@media(max-width:768px){.two-col{grid-template-columns:1fr}}
.flash{padding:12px;border-radius:8px;margin-bottom:16px;background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.3);color:var(--orange);font-size:.85rem}
</style></head><body>
<div class="header"><h1>🎣 Phishing Detection Framework</h1></div>
<div class="nav">
    <a href="/" class="{{ 'active' if page=='dash' }}">Dashboard</a>
    <a href="/url-scanner" class="{{ 'active' if page=='url' }}">URL Scanner</a>
    <a href="/email-analyzer" class="{{ 'active' if page=='email' }}">Email Analyzer</a>
    <a href="/results" class="{{ 'active' if page=='results' }}">Results</a>
</div>
<div class="container">{% block c %}{% endblock %}</div>
</body></html>
"""

@app.route("/")
def dashboard():
    phishing_urls = sum(1 for r in url_results if r["verdict"] == "phishing")
    phishing_emails = sum(1 for r in email_results if r["verdict"] == "phishing")
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="grid">
    <div class="stat"><div class="label">URLs Scanned</div><div class="val" style="color:var(--blue)">{{ url_results|length }}</div></div>
    <div class="stat"><div class="label">Phishing URLs</div><div class="val" style="color:var(--red)">{{ phishing_urls }}</div></div>
    <div class="stat"><div class="label">Emails Analyzed</div><div class="val" style="color:var(--purple)">{{ email_results|length }}</div></div>
    <div class="stat"><div class="label">Phishing Emails</div><div class="val" style="color:var(--red)">{{ phishing_emails }}</div></div>
</div>
<div class="card">
    <h2>⚡ Quick Actions</h2>
    <a href="/url-scanner" class="btn btn-orange">🔗 Scan URL</a>
    <a href="/email-analyzer" class="btn btn-blue">📧 Analyze Email</a>
    <a href="/demo-urls" class="btn btn-red">🎯 Demo URL Scan</a>
    <a href="/demo-emails" class="btn btn-red">🎯 Demo Email Scan</a>
</div>
{% if url_results %}
<div class="card">
    <h2>Recent URL Scans</h2>
    <table><thead><tr><th>URL</th><th>Score</th><th>Verdict</th><th>Indicators</th></tr></thead><tbody>
    {% for r in url_results[-8:]|reverse %}
    <tr><td style="font-size:.8rem;max-width:300px;overflow:hidden;text-overflow:ellipsis">{{ r.url[:60] }}</td>
    <td><strong>{{ r.score }}/100</strong></td><td><span class="badge {{ r.verdict }}">{{ r.verdict }}</span></td>
    <td style="font-size:.75rem">{{ r.indicators|length }} indicator(s)</td></tr>
    {% endfor %}</tbody></table>
</div>{% endif %}
""")
    from jinja2 import Template
    return Template(content).render(page="dash", url_results=url_results, email_results=email_results,
                                    phishing_urls=phishing_urls, phishing_emails=phishing_emails)


@app.route("/url-scanner", methods=["GET", "POST"])
def url_scanner():
    result = None
    if request.method == "POST":
        url = request.form.get("url", "").strip()
        if url:
            result = URLAnalyzer.analyze(url)
            url_results.append(result)

    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>🔗 URL Phishing Scanner</h2>
    <form method="POST"><input type="text" name="url" placeholder="Enter URL to scan (e.g. http://suspicious-site.tk/login)" required>
    <button type="submit" class="btn btn-orange">🔍 Scan URL</button></form>
</div>
{% if result %}
<div class="grid">
    <div class="stat"><div class="label">Phishing Score</div><div class="val" style="color:{% if result.score >= 60 %}var(--red){% elif result.score >= 30 %}var(--orange){% else %}var(--green){% endif %}">{{ result.score }}/100</div></div>
    <div class="stat"><div class="label">Verdict</div><div class="val"><span class="badge {{ result.verdict }}">{{ result.verdict }}</span></div></div>
    <div class="stat"><div class="label">Domain</div><div class="val" style="font-size:1rem;color:var(--blue)">{{ result.domain }}</div></div>
</div>
<div class="two-col">
    <div class="card">
        <h2>⚠️ Phishing Indicators</h2>
        {% for ind in result.indicators %}<div class="indicator">{{ ind }}</div>{% endfor %}
        {% if not result.indicators %}<div class="indicator safe">✅ No phishing indicators detected</div>{% endif %}
    </div>
    <div class="card">
        <h2>📊 URL Features</h2>
        <table>
        {% for k, v in result.features.items() %}
        <tr><td style="color:var(--dim)">{{ k|replace('_',' ')|title }}</td><td>{{ v }}</td></tr>
        {% endfor %}</table>
    </div>
</div>{% endif %}
""")
    from jinja2 import Template
    return Template(content).render(page="url", result=result)


@app.route("/email-analyzer", methods=["GET", "POST"])
def email_analyzer():
    result = None
    if request.method == "POST":
        email_data = {
            "subject": request.form.get("subject", ""),
            "headers": {
                "From": request.form.get("from_addr", ""),
                "Reply-To": request.form.get("reply_to", ""),
                "SPF": request.form.get("spf", "none"),
                "DKIM": request.form.get("dkim", "none"),
                "DMARC": request.form.get("dmarc", "none"),
            },
            "body": request.form.get("body", ""),
            "attachments": [a.strip() for a in request.form.get("attachments", "").split(",") if a.strip()],
        }
        result = EmailAnalyzer.analyze(email_data)
        email_results.append(result)

    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>📧 Email Phishing Analyzer</h2>
    <form method="POST">
        <input type="text" name="subject" placeholder="Email Subject">
        <input type="text" name="from_addr" placeholder="From Address">
        <input type="text" name="reply_to" placeholder="Reply-To Address">
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
            <select name="spf" style="padding:8px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text)">
                <option value="none">SPF: None</option><option value="pass">SPF: Pass</option><option value="fail">SPF: Fail</option>
            </select>
            <select name="dkim" style="padding:8px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text)">
                <option value="none">DKIM: None</option><option value="pass">DKIM: Pass</option><option value="fail">DKIM: Fail</option>
            </select>
            <select name="dmarc" style="padding:8px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text)">
                <option value="none">DMARC: None</option><option value="pass">DMARC: Pass</option><option value="fail">DMARC: Fail</option>
            </select>
        </div>
        <textarea name="body" rows="4" placeholder="Email body content"></textarea>
        <input type="text" name="attachments" placeholder="Attachments (comma-separated, e.g. invoice.pdf, update.exe)">
        <button type="submit" class="btn btn-blue">📧 Analyze Email</button>
    </form>
</div>
{% if result %}
<div class="grid">
    <div class="stat"><div class="label">Phishing Score</div><div class="val" style="color:{% if result.score >= 60 %}var(--red){% elif result.score >= 30 %}var(--orange){% else %}var(--green){% endif %}">{{ result.score }}/100</div></div>
    <div class="stat"><div class="label">Verdict</div><div class="val"><span class="badge {{ result.verdict }}">{{ result.verdict }}</span></div></div>
    <div class="stat"><div class="label">Auth</div><div class="val" style="font-size:.9rem">SPF:{{ result.auth_results.spf }} DKIM:{{ result.auth_results.dkim }}</div></div>
</div>
<div class="card">
    <h2>⚠️ Phishing Indicators</h2>
    {% for ind in result.indicators %}<div class="indicator">{{ ind }}</div>{% endfor %}
    {% if not result.indicators %}<div class="indicator safe">✅ Email appears legitimate</div>{% endif %}
</div>{% endif %}
""")
    from jinja2 import Template
    return Template(content).render(page="email", result=result)


@app.route("/demo-urls")
def demo_urls():
    for url in SAMPLE_URLS:
        result = URLAnalyzer.analyze(url)
        url_results.append(result)
    return redirect(url_for("dashboard"))


@app.route("/demo-emails")
def demo_emails():
    for email in SAMPLE_EMAILS:
        result = EmailAnalyzer.analyze(email)
        email_results.append(result)
    return redirect(url_for("dashboard"))


@app.route("/results")
def results_page():
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>📊 All Scan Results</h2>
    <h3 style="margin:16px 0 8px;color:var(--orange)">URL Scans ({{ url_results|length }})</h3>
    <table><thead><tr><th>URL</th><th>Score</th><th>Verdict</th><th>Time</th></tr></thead><tbody>
    {% for r in url_results|reverse %}
    <tr><td style="font-size:.8rem">{{ r.url[:60] }}</td><td>{{ r.score }}</td><td><span class="badge {{ r.verdict }}">{{ r.verdict }}</span></td><td style="font-size:.7rem">{{ r.analyzed_at[:19] }}</td></tr>
    {% endfor %}</tbody></table>
    <h3 style="margin:24px 0 8px;color:var(--blue)">Email Scans ({{ email_results|length }})</h3>
    <table><thead><tr><th>Subject</th><th>From</th><th>Score</th><th>Verdict</th></tr></thead><tbody>
    {% for r in email_results|reverse %}
    <tr><td>{{ r.subject }}</td><td style="font-size:.8rem">{{ r['from'] }}</td><td>{{ r.score }}</td><td><span class="badge {{ r.verdict }}">{{ r.verdict }}</span></td></tr>
    {% endfor %}</tbody></table>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="results", url_results=url_results, email_results=email_results)


@app.route("/api/scan-url", methods=["POST"])
def api_scan_url():
    data = request.get_json()
    result = URLAnalyzer.analyze(data.get("url", ""))
    return jsonify(result)


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("  🎣 Phishing Detection Framework")
    print("  Starting on http://localhost:5005")
    print("=" * 60 + "\n")
    app.run(debug=True, port=5005)
