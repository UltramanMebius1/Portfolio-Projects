# 🚆 Advanced Railway Reservation System
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge)](https://python.org)

Upgraded enterprise railway booking system featuring PNR generation, payment simulation, seat confirmation probability predictions, interactive admin panels, and responsive portals.

## Features
- Complete booking workflow: Route Search, Seat Selection, PNR Booking, Payment
- Seat Confirmation Probability engine using simple historical metrics
- Administrative schedule management (Create Train, Adjust Fare/Seats)
- Real-time dashboard showing booking analytics and occupancy rates
- Simulated confirmation email dispatch tracker

## Quick Start
```bash
pip install -r requirements.txt
python app.py  # http://localhost:5014
```
## License — MIT — **Koventhan M**
