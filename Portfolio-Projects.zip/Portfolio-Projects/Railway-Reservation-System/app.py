"""
Advanced Railway Reservation System — Complete Flask Application
Train schedules, booking workflow with PNR, payment simulation, seat prediction.
"""

import os
import random
from datetime import datetime, timedelta
from flask import Flask, render_template_string, request, redirect, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = "railway-reservation-secret"
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'railway.db')}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)


# ── Models ─────────────────────────────────────────────────────────────────

class Train(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    train_number = db.Column(db.String(10), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    source = db.Column(db.String(100), nullable=False)
    destination = db.Column(db.String(100), nullable=False)
    departure_time = db.Column(db.String(20), nullable=False)
    arrival_time = db.Column(db.String(20), nullable=False)
    available_seats = db.Column(db.Integer, default=50)
    waiting_list = db.Column(db.Integer, default=0)
    ticket_price = db.Column(db.Float, nullable=False)
    bookings = db.relationship("Booking", backref="train", lazy=True, cascade="all, delete-orphan")


class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pnr = db.Column(db.String(20), unique=True, nullable=False)
    passenger_name = db.Column(db.String(100), nullable=False)
    passenger_age = db.Column(db.Integer, nullable=False)
    seat_number = db.Column(db.String(10))
    status = db.Column(db.String(20), default="Confirmed")  # Confirmed, WL (Waiting List), Cancelled
    wl_number = db.Column(db.Integer, default=0)
    booked_at = db.Column(db.DateTime, default=datetime.utcnow)
    train_id = db.Column(db.Integer, db.ForeignKey("train.id"), nullable=False)


def seed_data():
    if Train.query.count() > 0:
        return

    trains = [
        {"num": "12626", "name": "Kerala Express", "src": "New Delhi", "dst": "Trivandrum", "dep": "20:10", "arr": "19:00", "seats": 4, "price": 45.0},
        {"num": "12952", "name": "Mumbai Rajdhani", "src": "New Delhi", "dst": "Mumbai", "dep": "16:55", "arr": "08:35", "seats": 45, "price": 60.0},
        {"num": "12002", "name": "Bhopal Shatabdi", "src": "New Delhi", "dst": "Bhopal", "dep": "06:00", "arr": "14:40", "seats": 80, "price": 25.0},
        {"num": "12301", "name": "Howrah Rajdhani", "src": "Howrah", "dst": "New Delhi", "dep": "16:50", "arr": "10:00", "seats": 1, "price": 55.0},
    ]

    for t in trains:
        tr = Train(train_number=t["num"], name=t["name"], source=t["src"], destination=t["dst"],
                   departure_time=t["dep"], arrival_time=t["arr"], available_seats=t["seats"],
                   ticket_price=t["price"])
        db.session.add(tr)
    db.session.commit()


# ── Templates ──────────────────────────────────────────────────────────────

TMPL = """
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Advanced Railway Reservation System</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0f172a;--bg2:#1e293b;--card:#334155;--text:#f8fafc;--dim:#94a3b8;--blue:#0284c7;--red:#ef4444;--orange:#f97316;--green:#10b981;--border:#475569;--purple:#8b5cf6}
body{font-family:'Segoe UI',sans-serif;background:var(--bg);color:var(--text)}
.header{background:linear-gradient(135deg,#1e293b,#0f172a);border-bottom:1px solid var(--border);padding:16px 32px;display:flex;align-items:center;justify-content:space-between}
.header h1{font-size:1.4rem;background:linear-gradient(135deg,#0284c7,#8b5cf6);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav{background:var(--bg2);border-bottom:1px solid var(--border);display:flex;padding:0 32px}
.nav a{color:var(--dim);text-decoration:none;padding:12px 18px;font-size:.85rem;font-weight:500;border-bottom:2px solid transparent;transition:.2s}
.nav a:hover,.nav a.active{color:var(--blue);border-bottom-color:var(--blue)}
.container{max-width:1400px;margin:0 auto;padding:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:24px}
.stat{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:20px}
.stat .label{font-size:.7rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}
.stat .val{font-size:1.8rem;font-weight:700}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:24px}
.card h2{font-size:1.1rem;margin-bottom:16px}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:10px;font-size:.7rem;text-transform:uppercase;color:var(--dim);border-bottom:1px solid var(--border)}
td{padding:10px;border-bottom:1px solid var(--border);font-size:.85rem}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:600;text-transform:uppercase}
.badge.alert{background:rgba(239,68,68,.12);color:var(--red);border:1px solid rgba(239,68,68,.25)}
.badge.safe{background:rgba(16,185,129,.12);color:var(--green);border:1px solid rgba(16,185,129,.25)}
.badge.waiting{background:rgba(249,115,22,.12);color:var(--orange);border:1px solid rgba(249,115,22,.25)}
.btn{padding:8px 16px;border-radius:8px;border:none;cursor:pointer;font-size:.85rem;font-weight:500;transition:.2s;text-decoration:none;display:inline-block;margin:2px}
.btn-blue{background:var(--blue);color:#fff}.btn-red{background:var(--red);color:#fff}.btn-purple{background:var(--purple);color:#fff}
.btn-sm{padding:4px 12px;font-size:.75rem}
.form-group{margin-bottom:12px}
label{display:block;margin-bottom:6px;font-size:.85rem;color:var(--dim)}
input[type=text],input[type=number],select{width:100%;padding:10px 14px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text);font-size:.9rem}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px}@media(max-width:768px){.two-col{grid-template-columns:1fr}}
.flash{padding:12px;border-radius:8px;margin-bottom:16px;background:rgba(2,132,199,.12);border:1px solid rgba(2,132,199,.3);color:var(--blue);font-size:.85rem}
</style></head><body>
<div class="header"><h1>🚆 Advanced Railway Reservation System</h1><span style="color:var(--dim);font-size:.8rem">IRCTC Upgraded</span></div>
<div class="nav">
    <a href="/" class="{{ 'active' if page=='dash' }}">Book Ticket</a>
    <a href="/bookings" class="{{ 'active' if page=='bookings' }}">My Bookings</a>
    <a href="/pnr" class="{{ 'active' if page=='pnr' }}">PNR Status Query</a>
</div>
<div class="container">{% if flash %}<div class="flash">{{ flash }}</div>{% endif %}{% block c %}{% endblock %}</div>
</body></html>
"""

# ── Routes ─────────────────────────────────────────────────────────────────

@app.route("/", methods=["GET", "POST"])
def dashboard():
    if request.method == "POST":
        tid = int(request.form.get("train_id"))
        name = request.form.get("name")
        age = int(request.form.get("age", 18))

        train = Train.query.get(tid)
        if not train:
            return redirect(url_for("dashboard"))

        # Seat confirmation probability engine simulation
        # If available seats > 5: 100%. If WL, predict base on waiting list size
        pnr = "PNR-" + "".join(random.choices("0123456789", k=8))

        status = "Confirmed"
        seat = None
        wl_num = 0

        if train.available_seats > 0:
            train.available_seats -= 1
            seat = f"Coach B{random.randint(1,4)}-Seat {random.randint(1,64)}"
        else:
            train.waiting_list += 1
            status = "WL"
            wl_num = train.waiting_list

        b = Booking(pnr=pnr, passenger_name=name, passenger_age=age, seat_number=seat,
                    status=status, wl_number=wl_num, train_id=train.id)
        db.session.add(b)
        db.session.commit()

        return redirect(url_for("bookings", msg=f"Booking successful! PNR: {pnr}. Status: {status}"))

    trains = Train.query.all()
    # Confirmation Probability Calculator helper
    probabilities = {}
    for t in trains:
        if t.available_seats > 5:
            probabilities[t.id] = 100
        elif t.available_seats > 0:
            probabilities[t.id] = 90
        else:
            wl = t.waiting_list
            prob = max(10, 85 - (wl * 15))
            probabilities[t.id] = prob

    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="two-col">
    <div class="card">
        <h2>🚆 Available Trains & Confirmation Probabilities</h2>
        <table><thead><tr><th>Train</th><th>From / To</th><th>Seats Left</th><th>Fare</th><th>Conf. Prob %</th></tr></thead><tbody>
        {% for t in trains %}
        <tr>
            <td><strong>{{ t.name }}</strong> ({{ t.train_number }})<br><span style="font-size:.75rem;color:var(--dim)">Dep: {{ t.departure_time }} | Arr: {{ t.arrival_time }}</span></td>
            <td>{{ t.source }} → {{ t.destination }}</td>
            <td style="font-weight:700;color:{% if t.available_seats == 0 %}var(--red){% else %}var(--green){% endif %}">
                {% if t.available_seats > 0 %}{{ t.available_seats }} seats{% else %}WL-{{ t.waiting_list + 1 }}{% endif %}
            </td>
            <td>${{ t.ticket_price }}</td>
            <td>
                <span class="badge {% if probs[t.id] >= 80 %}safe{% elif probs[t.id] >= 50 %}waiting{% else %}alert{% endif %}">
                    {{ probs[t.id] }}%
                </span>
            </td>
        </tr>{% endfor %}</tbody></table>
    </div>
    <div class="card">
        <h2>🎟️ Book Train Ticket</h2>
        <form method="POST">
            <div class="form-group">
                <label>Select Train</label>
                <select name="train_id">
                    {% for t in trains %}
                    <option value="{{ t.id }}">{{ t.name }} ({{ t.train_number }}) - ${{ t.ticket_price }}</option>
                    {% endfor %}
                </select>
            </div>
            <div class="form-group"><label>Passenger Name</label><input type="text" name="name" required></div>
            <div class="form-group"><label>Passenger Age</label><input type="number" name="age" required></div>
            <button type="submit" class="btn btn-blue">Pay & Confirm Booking</button>
        </form>
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="dash", trains=trains, probs=probabilities, flash=request.args.get("msg"))


@app.route("/bookings")
def bookings():
    bookings_list = Booking.query.order_by(Booking.booked_at.desc()).all()
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>My Bookings / PNR Ledger</h2>
    <table><thead><tr><th>Booked At</th><th>PNR</th><th>Passenger</th><th>Train</th><th>Fare</th><th>Seat Info</th><th>Status</th></tr></thead><tbody>
    {% for b in bookings %}
    <tr>
        <td style="font-size:.75rem">{{ b.booked_at.strftime('%Y-%m-%d %H:%M') }}</td>
        <td style="font-family:monospace;font-weight:700">{{ b.pnr }}</td>
        <td>{{ b.passenger_name }} (Age: {{ b.passenger_age }})</td>
        <td>{{ b.train.name }} ({{ b.train.train_number }})</td>
        <td>${{ b.train.ticket_price }}</td>
        <td>{{ b.seat_number or 'WL-' ~ b.wl_number }}</td>
        <td><span class="badge {% if b.status == 'Confirmed' %}safe{% else %}waiting{% endif %}">{{ b.status }}</span></td>
    </tr>{% endfor %}</tbody></table>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="bookings", bookings=bookings_list, flash=request.args.get("msg"))


@app.route("/pnr", methods=["GET", "POST"])
def pnr():
    result = None
    if request.method == "POST":
        code = request.form.get("pnr_code", "").strip()
        b = Booking.query.filter_by(pnr=code).first()
        if b:
            result = b
        else:
            result = "Not Found"

    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card" style="max-width: 600px; margin: 0 auto">
    <h2>🔍 PNR Status Lookup</h2>
    <form method="POST">
        <input type="text" name="pnr_code" placeholder="Enter PNR code..." required autofocus>
        <button type="submit" class="btn btn-blue">Query PNR Status</button>
    </form>
    
    {% if res %}
        {% if res == 'Not Found' %}
            <div style="background:rgba(239,68,68,.06);border-left:4px solid var(--red);padding:12px;margin-top:16px;border-radius:4px">
                [-] Booking not found in database for provided PNR code.
            </div>
        {% else %}
            <div style="background:rgba(16,185,129,.06);border-left:4px solid var(--green);padding:16px;margin-top:16px;border-radius:8px">
                <h3 style="color:var(--green);margin-bottom:8px">Booking Found: {{ res.passenger_name }}</h3>
                <p><strong>PNR Code:</strong> {{ res.pnr }}</p>
                <p><strong>Train:</strong> {{ res.train.name }} ({{ res.train.train_number }})</p>
                <p><strong>Route:</strong> {{ res.train.source }} → {{ res.train.destination }}</p>
                <p><strong>Seat/Coach:</strong> {{ res.seat_number or 'Waiting List (WL-' ~ res.wl_number ~ ')' }}</p>
                <p><strong>Status:</strong> <span class="badge {% if res.status == 'Confirmed' %}safe{% else %}waiting{% endif %}">{{ res.status }}</span></p>
            </div>
        {% endif %}
    {% endif %}
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="pnr", res=result)


with app.app_context():
    db.create_all()
    seed_data()

if __name__ == "__main__":
    print("\n  🚆 Advanced Railway Reservation System — http://localhost:5014\n")
    app.run(debug=True, port=5014)
