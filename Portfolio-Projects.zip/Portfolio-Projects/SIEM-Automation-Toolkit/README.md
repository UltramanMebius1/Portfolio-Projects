<div align="center">

# 🛡️ SIEM Automation Toolkit

[![Python](https://img.shields.io/badge/Python-3.10+-blue.svg)](https://python.org)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![MITRE ATT&CK](https://img.shields.io/badge/MITRE%20ATT%26CK-Mapped-red.svg)](https://attack.mitre.org)
[![Flask](https://img.shields.io/badge/Dashboard-Flask-lightgrey.svg)](https://flask.palletsprojects.com)

A professional-grade Security Information and Event Management (SIEM) automation toolkit for parsing security logs, detecting threats using configurable rules, correlating events, and generating actionable incident reports.

[Features](#-features) • [Architecture](#-architecture) • [Quick Start](#-quick-start) • [Usage](#-usage) • [Dashboard](#-dashboard) • [Documentation](#-documentation)

</div>

---

## ✨ Features

- **Multi-Format Log Parsing** — Automatically detect and parse Windows Event XML, Syslog, Apache access/error logs, JSON-structured logs, and Linux auth logs
- **Configurable Detection Rules** — YAML-based rule definitions with severity levels, pattern matching, threshold-based detection, and time-window analysis
- **Event Correlation Engine** — Correlate events across multiple log sources using temporal proximity, shared attributes (IP, user, process), and attack sequence detection
- **MITRE ATT&CK Mapping** — Every alert is automatically mapped to MITRE ATT&CK techniques and tactics for standardized threat classification
- **Real-Time Web Dashboard** — Dark-themed Flask dashboard with alert summaries, severity breakdowns, filterable alert tables, and live statistics
- **Automated Incident Ticketing** — Automatically generate and manage incident tickets for critical and high-severity alerts with full lifecycle tracking
- **Multi-Channel Notifications** — Alert delivery via email (SMTP) and Slack webhooks with configurable thresholds and batch support
- **Comprehensive Reporting** — Generate HTML, JSON, and CSV reports with executive summaries, MITRE coverage matrices, and timeline visualizations
- **Rich CLI Interface** — Beautiful terminal output with progress bars, colored tables, and status panels powered by the Rich library
- **RESTful API** — JSON API endpoints for programmatic access to alerts, statistics, and ticket management

---

## 🏗️ Architecture

```mermaid
flowchart LR
    A["📄 Log Sources"] --> B["🔍 Log Parser"]
    B --> C["⚙️ Rules Engine"]
    C --> D["🚨 Alert Manager"]
    D --> E["📊 Reporter"]
    D --> F["🔔 Notifier"]
    D --> G["🌐 Dashboard"]
    D --> H["🎫 Ticket Manager"]
    B --> I["🔗 Correlator"]
    I --> D
    D --> J["🗺️ MITRE Mapper"]

    style A fill:#1a1a2e,stroke:#e94560,color:#fff
    style B fill:#16213e,stroke:#0f3460,color:#fff
    style C fill:#16213e,stroke:#0f3460,color:#fff
    style D fill:#0f3460,stroke:#e94560,color:#fff
    style E fill:#1a1a2e,stroke:#53868b,color:#fff
    style F fill:#1a1a2e,stroke:#53868b,color:#fff
    style G fill:#1a1a2e,stroke:#53868b,color:#fff
    style H fill:#1a1a2e,stroke:#53868b,color:#fff
    style I fill:#16213e,stroke:#0f3460,color:#fff
    style J fill:#16213e,stroke:#0f3460,color:#fff
```

**Data Flow:**
1. **Ingestion** — Raw logs are fed into the parser via CLI or watched directories
2. **Normalization** — The parser auto-detects format and converts entries into structured `LogEntry` objects
3. **Detection** — The rules engine evaluates normalized events against YAML-defined detection rules
4. **Correlation** — The correlation engine links related events across sources and time windows
5. **Alerting** — Matched rules generate `Alert` objects with severity, MITRE mappings, and context
6. **Response** — Alerts flow to the reporter, notifier, ticketing system, and dashboard simultaneously

---

## 📁 Project Structure

```
SIEM-Automation-Toolkit/
├── main.py                     # CLI entry point with rich interface
├── dashboard.py                # Flask web dashboard application
├── requirements.txt            # Python dependencies
├── README.md                   # This file
├── .gitignore                  # Git ignore rules
│
├── siem/                       # Core SIEM engine package
│   ├── __init__.py             # Data models (LogEntry, Alert, Severity, etc.)
│   ├── parser.py               # Multi-format log parser
│   ├── rules_engine.py         # YAML-based detection rules engine
│   ├── alert_manager.py        # Alert lifecycle management
│   ├── correlator.py           # Cross-source event correlation
│   ├── mitre_mapper.py         # MITRE ATT&CK technique mapper
│   ├── reporter.py             # HTML/JSON/CSV report generator
│   ├── notifier.py             # Email & Slack notification sender
│   └── ticket_manager.py       # Incident ticket management
│
├── config/                     # Configuration files
│   ├── config.yaml             # Main application configuration
│   ├── rules.yaml              # Detection rule definitions
│   └── mitre_mapping.yaml      # MITRE ATT&CK mapping database
│
├── sample_logs/                # Example log files for testing
│   ├── windows_security.xml    # Windows Security Event Log
│   ├── auth.log                # Linux authentication log
│   ├── syslog.log              # Syslog-format messages
│   ├── apache_access.log       # Apache HTTP access log
│   └── app_events.json         # JSON-structured application log
│
├── templates/                  # Jinja2 HTML templates
│   └── report.html             # HTML report template
│
├── static/                     # Static web assets
│   ├── css/
│   │   └── dashboard.css       # Dashboard stylesheet
│   └── js/
│       └── dashboard.js        # Dashboard JavaScript
│
├── tests/                      # Unit and integration tests
│   ├── test_parser.py
│   ├── test_rules_engine.py
│   ├── test_alert_manager.py
│   ├── test_correlator.py
│   └── test_integration.py
│
├── output/                     # Generated reports (git-ignored)
└── tickets/                    # Incident tickets (git-ignored)
```

---

## 🚀 Quick Start

### Prerequisites

- Python 3.10 or higher
- pip package manager

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/SIEM-Automation-Toolkit.git
cd SIEM-Automation-Toolkit

# Create and activate virtual environment
python -m venv venv
source venv/bin/activate        # Linux/macOS
venv\Scripts\activate           # Windows

# Install dependencies
pip install -r requirements.txt
```

### First Run

```bash
# Analyze sample logs with default settings
python main.py analyze -i sample_logs/

# Analyze with correlation and notifications
python main.py analyze -i sample_logs/ --correlate --notify -v

# Launch the web dashboard
python main.py dashboard

# View all tickets
python main.py tickets list
```

---

## 📖 Usage

### Analyze Logs

```bash
# Auto-detect format and analyze a single file
python main.py analyze -i sample_logs/auth.log

# Specify format explicitly
python main.py analyze -i sample_logs/windows_security.xml -f windows_xml

# Analyze entire directory with all features enabled
python main.py analyze -i /var/log/ --correlate --notify --report-format all -v

# Custom rules and output directory
python main.py analyze -i logs/ -r custom_rules.yaml -o /tmp/siem-output/
```

**Sample Output:**
```
╔══════════════════════════════════════════════════════════════╗
║              🛡️  SIEM Automation Toolkit v1.0               ║
╚══════════════════════════════════════════════════════════════╝

[•] Loading configuration... ✓
[•] Loading detection rules... 15 rules loaded ✓
[•] Parsing log files...

  Parsing ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 5/5 files

[•] Evaluating rules... 23 alerts generated ✓
[•] Correlating events... 7 correlations found ✓

┌─────────────────────────────── Alert Summary ────────────────────────────────┐
│ Severity │ Count │ Description                           │ MITRE Technique  │
├──────────┼───────┼───────────────────────────────────────┼──────────────────┤
│ CRITICAL │     3 │ Brute Force Authentication Detected   │ T1110            │
│ HIGH     │     8 │ Privilege Escalation Attempt          │ T1068            │
│ MEDIUM   │     7 │ Suspicious Process Execution          │ T1059            │
│ LOW      │     5 │ Unusual Login Time                    │ T1078            │
└──────────┴───────┴───────────────────────────────────────┴──────────────────┘

[•] Report generated: output/siem_report.html ✓
[•] Tickets created: 11 (3 CRITICAL, 8 HIGH) ✓
```

### Manage Tickets

```bash
# List all open tickets
python main.py tickets list

# Show ticket details
python main.py tickets show TKT-001

# Close a ticket with resolution
python main.py tickets close TKT-001 --resolution "False positive - internal scan"
```

### Export Alerts

```bash
# Export alerts as CSV
python main.py export --format csv -o alerts.csv

# Export alerts as JSON
python main.py export --format json -o alerts.json
```

### Launch Dashboard

```bash
# Start on default port 5000
python main.py dashboard

# Custom host and port
python main.py dashboard --host 127.0.0.1 -p 8080
```

---

## 🔍 Detection Rules

The toolkit ships with a comprehensive set of detection rules mapped to MITRE ATT&CK:

| Rule Name | Severity | MITRE Technique | Description |
|:----------|:---------|:----------------|:------------|
| Brute Force Detection | CRITICAL | T1110 - Brute Force | Multiple failed logins from same source |
| Privilege Escalation | HIGH | T1068 - Exploitation for Privilege Escalation | Unauthorized privilege elevation |
| Suspicious Process | HIGH | T1059 - Command and Scripting Interpreter | Execution of known-malicious processes |
| Lateral Movement | HIGH | T1021 - Remote Services | Unusual remote access patterns |
| Data Exfiltration | CRITICAL | T1041 - Exfiltration Over C2 Channel | Large outbound data transfers |
| Account Manipulation | MEDIUM | T1098 - Account Manipulation | User/group modification events |
| Unusual Login Time | LOW | T1078 - Valid Accounts | Authentication outside business hours |
| Log Tampering | HIGH | T1070 - Indicator Removal | Evidence of log deletion or modification |
| SQL Injection Attempt | HIGH | T1190 - Exploit Public-Facing Application | SQL injection patterns in web logs |
| Directory Traversal | MEDIUM | T1083 - File and Directory Discovery | Path traversal attempts in requests |

Rules are defined in `config/rules.yaml` and are fully customizable. See the [Configuration](#-configuration) section for details.

---

## 🌐 Dashboard

The web dashboard provides a real-time overview of your security posture with a sleek dark theme:

**Features:**
- **Overview Panel** — Total alerts, severity distribution, and trend indicators
- **Alert Table** — Sortable, filterable list of all alerts with status management
- **Severity Chart** — Visual breakdown of alerts by severity level
- **Ticket Tracker** — View and manage incident tickets directly from the browser
- **REST API** — Programmatic access via `/api/alerts`, `/api/stats`, and `/api/tickets`

```bash
# Launch dashboard
python main.py dashboard

# Access at http://localhost:5000
```

---

## ⚙️ Configuration

The main configuration file is `config/config.yaml`:

```yaml
# Logging
log_level: INFO

# Analysis
analysis:
  default_format: auto
  time_window: 300        # Correlation time window (seconds)
  max_events: 100000      # Maximum events to process

# Notifications
notifications:
  email:
    enabled: false
    smtp_server: smtp.gmail.com
    smtp_port: 587
    sender: alerts@yourorg.com
    recipients:
      - soc@yourorg.com
  slack:
    enabled: false
    webhook_url: https://hooks.slack.com/services/YOUR/WEBHOOK/URL
    channel: "#siem-alerts"

# Reporting
reporting:
  default_format: html
  template_dir: templates/
  output_dir: output/

# Dashboard
dashboard:
  host: 0.0.0.0
  port: 5000
  debug: false

# Ticketing
ticketing:
  auto_create: true
  auto_create_severities:
    - CRITICAL
    - HIGH
  tickets_dir: tickets/
```

---

## 🗺️ MITRE ATT&CK Coverage

The toolkit provides detection coverage across the following MITRE ATT&CK tactics:

| Tactic | Techniques Covered | Example |
|:-------|:-------------------|:--------|
| Initial Access | T1190, T1133 | Exploit Public-Facing Application |
| Execution | T1059, T1053 | Command and Scripting Interpreter |
| Persistence | T1098, T1136 | Account Manipulation |
| Privilege Escalation | T1068, T1078 | Exploitation for Privilege Escalation |
| Defense Evasion | T1070, T1036 | Indicator Removal on Host |
| Credential Access | T1110, T1003 | Brute Force |
| Discovery | T1083, T1046 | File and Directory Discovery |
| Lateral Movement | T1021, T1076 | Remote Services |
| Exfiltration | T1041, T1048 | Exfiltration Over C2 Channel |
| Impact | T1486, T1489 | Data Encrypted for Impact |

---

## 📊 Sample Output

### Executive Summary

```
╔══════════════════════════════════════════════════╗
║           Executive Security Summary             ║
╠══════════════════════════════════════════════════╣
║ Analysis Period:  2025-01-01 to 2025-01-07       ║
║ Total Events:     45,823                         ║
║ Alerts Generated: 23                             ║
║ Critical:         3  ████░░░░░░  13%             ║
║ High:             8  █████████░  35%             ║
║ Medium:           7  ████████░░  30%             ║
║ Low:              5  ██████░░░░  22%             ║
║ Correlated:       7 event chains                 ║
║ Tickets Created:  11                             ║
╚══════════════════════════════════════════════════╝
```

---

## 📚 API Reference

| Module | Class | Description |
|:-------|:------|:------------|
| `siem.parser` | `LogParser` | Multi-format log file parser with auto-detection |
| `siem.rules_engine` | `RulesEngine` | YAML-based configurable detection rules engine |
| `siem.alert_manager` | `AlertManager` | Alert lifecycle management and deduplication |
| `siem.correlator` | `LogCorrelator` | Cross-source temporal event correlation |
| `siem.mitre_mapper` | `MitreMapper` | MITRE ATT&CK technique and tactic mapping |
| `siem.reporter` | `ReportGenerator` | Multi-format report generation (HTML, JSON, CSV) |
| `siem.notifier` | `Notifier` | Multi-channel alert notification (Email, Slack) |
| `siem.ticket_manager` | `TicketManager` | Incident ticket creation and lifecycle management |

---

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

Please ensure your code:
- Follows PEP 8 style guidelines
- Includes appropriate docstrings and comments
- Adds unit tests for new functionality
- Updates documentation as needed

---

## 📄 License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.

---

<div align="center">

**Built with ❤️ for the cybersecurity community**

*Demonstrating security engineering depth through automated threat detection and incident response*

</div>
