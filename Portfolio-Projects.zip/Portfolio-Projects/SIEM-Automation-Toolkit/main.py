#!/usr/bin/env python3
"""
SIEM Automation Toolkit - CLI Entry Point
==========================================
Rich-powered command-line interface for parsing security logs,
detecting threats, correlating events, and generating reports.
"""

import argparse
import logging
import os
import sys
from datetime import datetime
from pathlib import Path

import yaml
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.table import Table
from rich.text import Text
from rich import box

from siem import Severity, AlertStatus
from siem.parser import LogParser
from siem.rules_engine import RulesEngine
from siem.alert_manager import AlertManager
from siem.correlator import LogCorrelator
from siem.mitre_mapper import MitreMapper
from siem.reporter import ReportGenerator
from siem.notifier import Notifier
from siem.ticket_manager import TicketManager

console = Console()

# ─── Banner ───────────────────────────────────────────────────────────────────

BANNER = r"""
[bold cyan]
 ╔══════════════════════════════════════════════════════════════════╗
 ║                                                                  ║
 ║   ███████╗██╗███████╗███╗   ███╗    ████████╗██╗  ██╗           ║
 ║   ██╔════╝██║██╔════╝████╗ ████║    ╚══██╔══╝██║ ██╔╝           ║
 ║   ███████╗██║█████╗  ██╔████╔██║       ██║   █████╔╝            ║
 ║   ╚════██║██║██╔══╝  ██║╚██╔╝██║       ██║   ██╔═██╗            ║
 ║   ███████║██║███████╗██║ ╚═╝ ██║       ██║   ██║  ██╗           ║
 ║   ╚══════╝╚═╝╚══════╝╚═╝     ╚═╝       ╚═╝   ╚═╝  ╚═╝           ║
 ║                                                                  ║
 ║        🛡️  SIEM Automation Toolkit  v1.0.0                       ║
 ║        Security Information & Event Management                   ║
 ║                                                                  ║
 ╚══════════════════════════════════════════════════════════════════╝
[/bold cyan]
"""

# ─── Severity color mapping ──────────────────────────────────────────────────

SEVERITY_COLORS = {
    Severity.CRITICAL: "bold white on red",
    Severity.HIGH: "bold red",
    Severity.MEDIUM: "bold yellow",
    Severity.LOW: "bold blue",
    Severity.INFO: "dim white",
}

SEVERITY_ICONS = {
    Severity.CRITICAL: "🔴",
    Severity.HIGH: "🟠",
    Severity.MEDIUM: "🟡",
    Severity.LOW: "🔵",
    Severity.INFO: "⚪",
}


# ─── Utility helpers ─────────────────────────────────────────────────────────

def load_config(config_path: str = "config/config.yaml") -> dict:
    """Load YAML configuration file."""
    path = Path(config_path)
    if not path.exists():
        console.print(f"[yellow]⚠  Config file not found at {config_path}, using defaults[/yellow]")
        return {
            "log_level": "INFO",
            "analysis": {
                "default_format": "auto",
                "time_window": 300,
                "max_events": 100000,
            },
            "notifications": {
                "email": {"enabled": False},
                "slack": {"enabled": False},
            },
            "reporting": {
                "default_format": "html",
                "template_dir": "templates/",
                "output_dir": "output/",
            },
            "dashboard": {
                "host": "0.0.0.0",
                "port": 5000,
                "debug": False,
            },
            "ticketing": {
                "auto_create": True,
                "auto_create_severities": ["CRITICAL", "HIGH"],
                "tickets_dir": "tickets/",
            },
        }

    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def setup_logging(level: str = "INFO", verbose: bool = False) -> None:
    """Configure logging based on config and verbosity flag."""
    effective_level = "DEBUG" if verbose else level
    logging.basicConfig(
        level=getattr(logging, effective_level.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def collect_log_files(input_path: str) -> list[Path]:
    """Collect all parseable log files from the given path."""
    p = Path(input_path)
    if p.is_file():
        return [p]
    elif p.is_dir():
        extensions = {".log", ".xml", ".json", ".txt"}
        files = []
        for f in sorted(p.iterdir()):
            if f.is_file() and (f.suffix in extensions or not f.suffix):
                files.append(f)
        return files
    else:
        console.print(f"[bold red]✗  Path not found: {input_path}[/bold red]")
        sys.exit(1)


def display_alert_table(alerts: list) -> None:
    """Render a rich table of alerts."""
    table = Table(
        title="Alert Summary",
        box=box.ROUNDED,
        title_style="bold cyan",
        header_style="bold white",
        border_style="bright_blue",
        show_lines=True,
        padding=(0, 1),
    )
    table.add_column("#", style="dim", width=4, justify="center")
    table.add_column("Severity", width=10, justify="center")
    table.add_column("Rule", min_width=30)
    table.add_column("Description", min_width=35, max_width=50)
    table.add_column("MITRE", width=12, justify="center")
    table.add_column("Events", width=7, justify="center")
    table.add_column("Status", width=14, justify="center")

    for idx, alert in enumerate(alerts, 1):
        sev = alert.severity
        sev_style = SEVERITY_COLORS.get(sev, "white")
        icon = SEVERITY_ICONS.get(sev, "")
        mitre = alert.mitre_technique or "—"
        event_count = str(len(alert.source_events)) if alert.source_events else str(alert.count)
        status_text = alert.status.value if alert.status else "NEW"

        table.add_row(
            str(idx),
            Text(f"{icon} {sev.value}", style=sev_style),
            Text(alert.rule_name, style="bold"),
            alert.description[:50] + ("…" if len(alert.description) > 50 else ""),
            Text(mitre, style="cyan"),
            event_count,
            Text(status_text, style="green" if status_text == "RESOLVED" else "yellow"),
        )

    console.print()
    console.print(table)


def display_statistics(stats: dict) -> None:
    """Display alert statistics in a panel."""
    lines = []
    lines.append(f"[bold]Total Alerts:[/bold]  {stats.get('total', 0)}")
    lines.append("")

    severity_counts = stats.get("by_severity", {})
    for sev_name in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]:
        count = severity_counts.get(sev_name, 0)
        try:
            sev = Severity(sev_name)
            icon = SEVERITY_ICONS.get(sev, "")
            style = SEVERITY_COLORS.get(sev, "white")
        except ValueError:
            icon = ""
            style = "white"
        bar_len = min(count, 30)
        bar = "█" * bar_len + "░" * (30 - bar_len)
        lines.append(f"  {icon} [{style}]{sev_name:<10}[/{style}] {bar} {count}")

    lines.append("")
    status_counts = stats.get("by_status", {})
    for status_name, cnt in status_counts.items():
        lines.append(f"  {status_name}: {cnt}")

    panel = Panel(
        "\n".join(lines),
        title="📊 Statistics",
        border_style="bright_blue",
        padding=(1, 2),
    )
    console.print()
    console.print(panel)


def display_correlation_summary(correlations: list) -> None:
    """Display a summary of correlated events."""
    if not correlations:
        return

    table = Table(
        title="🔗 Correlated Event Chains",
        box=box.ROUNDED,
        title_style="bold magenta",
        header_style="bold white",
        border_style="magenta",
    )
    table.add_column("#", width=4, justify="center")
    table.add_column("Type", width=18)
    table.add_column("Description", min_width=40)
    table.add_column("Events", width=8, justify="center")
    table.add_column("Confidence", width=12, justify="center")
    table.add_column("Severity", width=10, justify="center")

    for idx, corr in enumerate(correlations, 1):
        sev = corr.severity
        sev_style = SEVERITY_COLORS.get(sev, "white")
        icon = SEVERITY_ICONS.get(sev, "")
        confidence = f"{corr.confidence:.0%}" if corr.confidence else "—"

        table.add_row(
            str(idx),
            corr.correlation_type,
            corr.description[:45] + ("…" if len(corr.description) > 45 else ""),
            str(len(corr.events)),
            confidence,
            Text(f"{icon} {sev.value}", style=sev_style),
        )

    console.print()
    console.print(table)


# ─── Command handlers ────────────────────────────────────────────────────────

def cmd_analyze(args: argparse.Namespace, config: dict) -> None:
    """Execute the full analysis pipeline."""
    console.print(BANNER)

    analysis_cfg = config.get("analysis", {})
    reporting_cfg = config.get("reporting", {})
    ticketing_cfg = config.get("ticketing", {})

    # ── Step 1: Load rules ────────────────────────────────────────────────
    console.print("[bold cyan][•][/bold cyan] Loading detection rules...", end=" ")
    rules_engine = RulesEngine(args.rules)
    rules_engine.load_rules()
    console.print("[green]✓[/green]")

    # ── Step 2: Collect and parse log files ───────────────────────────────
    log_files = collect_log_files(args.input)
    if not log_files:
        console.print("[bold red]✗  No log files found![/bold red]")
        sys.exit(1)

    console.print(f"[bold cyan][•][/bold cyan] Found [bold]{len(log_files)}[/bold] log file(s)")

    parser = LogParser()
    all_events = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(bar_width=40),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn("{task.completed}/{task.total} files"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Parsing logs", total=len(log_files))

        for log_file in log_files:
            fmt = args.format if args.format != "auto" else None
            events = parser.parse_file(str(log_file), format=fmt)
            all_events.extend(events)
            progress.advance(task)

    console.print(
        f"[bold cyan][•][/bold cyan] Parsed [bold]{len(all_events)}[/bold] events [green]✓[/green]"
    )

    # ── Step 3: Evaluate rules ────────────────────────────────────────────
    console.print("[bold cyan][•][/bold cyan] Evaluating rules...", end=" ")
    alerts = rules_engine.evaluate(all_events)
    console.print(f"[bold]{len(alerts)}[/bold] alerts generated [green]✓[/green]")

    # ── Step 4: Correlation ───────────────────────────────────────────────
    correlations = []
    if args.correlate:
        console.print("[bold cyan][•][/bold cyan] Correlating events...", end=" ")
        correlator = LogCorrelator()
        time_window = analysis_cfg.get("time_window", 300)
        correlations = correlator.correlate(all_events, time_window=time_window)
        console.print(
            f"[bold]{len(correlations)}[/bold] correlations found [green]✓[/green]"
        )

    # ── Step 5: MITRE mapping ─────────────────────────────────────────────
    console.print("[bold cyan][•][/bold cyan] Mapping MITRE ATT&CK techniques...", end=" ")
    mitre_path = "config/mitre_mapping.yaml"
    mapper = MitreMapper(mitre_path)
    for alert in alerts:
        mapper.map_alert(alert)
    console.print("[green]✓[/green]")

    # ── Step 6: Alert management ──────────────────────────────────────────
    alert_mgr = AlertManager()
    for alert in alerts:
        alert_mgr.add_alert(alert)
    alert_mgr.deduplicate_alerts()
    stats = alert_mgr.get_statistics()

    # ── Display results ───────────────────────────────────────────────────
    display_alert_table(alerts)
    if correlations:
        display_correlation_summary(correlations)
    display_statistics(stats)

    # ── Step 7: Generate reports ──────────────────────────────────────────
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    template_dir = reporting_cfg.get("template_dir", "templates/")
    reporter = ReportGenerator(template_dir)

    report_format = args.report_format
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    console.print("[bold cyan][•][/bold cyan] Generating reports...", end=" ")

    if report_format in ("html", "all"):
        html_path = str(output_dir / f"siem_report_{timestamp}.html")
        reporter.generate_html_report(alerts, correlations, stats, html_path)
        console.print(f"\n    [dim]→ HTML:[/dim] {html_path}")

    if report_format in ("json", "all"):
        json_path = str(output_dir / f"siem_report_{timestamp}.json")
        reporter.generate_json_report(alerts, json_path)
        console.print(f"    [dim]→ JSON:[/dim] {json_path}")

    if report_format in ("csv", "all"):
        csv_path = str(output_dir / f"siem_report_{timestamp}.csv")
        reporter.generate_csv_report(alerts, csv_path)
        console.print(f"    [dim]→ CSV:[/dim]  {csv_path}")

    # Executive summary
    summary = reporter.generate_executive_summary(alerts, stats)
    console.print()
    console.print(Panel(summary, title="📋 Executive Summary", border_style="green"))

    console.print("[green]✓[/green]")

    # ── Step 8: Ticketing ─────────────────────────────────────────────────
    if ticketing_cfg.get("auto_create", True):
        tickets_dir = ticketing_cfg.get("tickets_dir", "tickets/")
        ticket_mgr = TicketManager(tickets_dir)
        auto_severities = ticketing_cfg.get("auto_create_severities", ["CRITICAL", "HIGH"])
        created = 0

        for alert in alerts:
            if alert.severity.value in auto_severities:
                ticket_mgr.create_ticket(alert)
                created += 1

        if created:
            console.print(
                f"[bold cyan][•][/bold cyan] Tickets created: [bold]{created}[/bold] [green]✓[/green]"
            )

    # ── Step 9: Notifications ─────────────────────────────────────────────
    if args.notify:
        console.print("[bold cyan][•][/bold cyan] Sending notifications...", end=" ")
        notifier_cfg = config.get("notifications", {})
        notifier = Notifier(notifier_cfg)
        critical_high = [a for a in alerts if a.severity in (Severity.CRITICAL, Severity.HIGH)]
        if critical_high:
            notifier.batch_notify(critical_high)
            console.print(
                f"[bold]{len(critical_high)}[/bold] notifications sent [green]✓[/green]"
            )
        else:
            console.print("[dim]No critical/high alerts to notify[/dim]")

    # ── Done ──────────────────────────────────────────────────────────────
    console.print()
    console.print(
        Panel(
            f"[bold green]Analysis complete![/bold green]\n\n"
            f"  Events parsed:     {len(all_events)}\n"
            f"  Alerts generated:  {len(alerts)}\n"
            f"  Correlations:      {len(correlations)}\n"
            f"  Reports:           {output_dir}\n",
            title="✅ Summary",
            border_style="green",
        )
    )


def cmd_dashboard(args: argparse.Namespace, config: dict) -> None:
    """Launch the Flask web dashboard."""
    console.print(BANNER)
    console.print("[bold cyan][•][/bold cyan] Starting web dashboard...")
    console.print(f"    [dim]Host:[/dim] {args.host}")
    console.print(f"    [dim]Port:[/dim] {args.port}")
    console.print(f"    [dim]URL:[/dim]  [link=http://{args.host}:{args.port}]http://{args.host}:{args.port}[/link]")
    console.print()

    # Import and run the dashboard app
    from dashboard import create_app

    app = create_app(config)
    debug = config.get("dashboard", {}).get("debug", False)
    app.run(host=args.host, port=args.port, debug=debug)


def cmd_tickets_list(args: argparse.Namespace, config: dict) -> None:
    """List all incident tickets."""
    tickets_dir = config.get("ticketing", {}).get("tickets_dir", "tickets/")
    ticket_mgr = TicketManager(tickets_dir)
    tickets = ticket_mgr.list_tickets(status=None)

    if not tickets:
        console.print("[dim]No tickets found.[/dim]")
        return

    table = Table(
        title="🎫 Incident Tickets",
        box=box.ROUNDED,
        title_style="bold cyan",
        header_style="bold white",
        border_style="bright_blue",
        show_lines=True,
    )
    table.add_column("ID", style="bold", width=12)
    table.add_column("Severity", width=10, justify="center")
    table.add_column("Title", min_width=35)
    table.add_column("Status", width=14, justify="center")
    table.add_column("Created", width=20)
    table.add_column("Assigned To", width=15)

    for ticket in tickets:
        sev = ticket.severity
        sev_style = SEVERITY_COLORS.get(sev, "white")
        icon = SEVERITY_ICONS.get(sev, "")
        created = ticket.created_at.strftime("%Y-%m-%d %H:%M") if ticket.created_at else "—"
        assigned = ticket.assigned_to or "Unassigned"
        status_style = "green" if ticket.status == "CLOSED" else "yellow"

        table.add_row(
            ticket.id,
            Text(f"{icon} {sev.value}", style=sev_style),
            ticket.title,
            Text(ticket.status, style=status_style),
            created,
            assigned,
        )

    console.print()
    console.print(table)
    console.print(f"\n[dim]Total: {len(tickets)} ticket(s)[/dim]")


def cmd_tickets_show(args: argparse.Namespace, config: dict) -> None:
    """Show detailed view of a single ticket."""
    tickets_dir = config.get("ticketing", {}).get("tickets_dir", "tickets/")
    ticket_mgr = TicketManager(tickets_dir)
    ticket = ticket_mgr.get_ticket(args.id)

    if not ticket:
        console.print(f"[bold red]✗  Ticket not found: {args.id}[/bold red]")
        sys.exit(1)

    sev = ticket.severity
    sev_style = SEVERITY_COLORS.get(sev, "white")
    icon = SEVERITY_ICONS.get(sev, "")

    content = []
    content.append(f"[bold]ID:[/bold]          {ticket.id}")
    content.append(f"[bold]Title:[/bold]       {ticket.title}")
    content.append(f"[bold]Severity:[/bold]    [{sev_style}]{icon} {sev.value}[/{sev_style}]")
    content.append(f"[bold]Status:[/bold]      {ticket.status}")
    content.append(f"[bold]Assigned To:[/bold] {ticket.assigned_to or 'Unassigned'}")
    content.append(f"[bold]Created:[/bold]     {ticket.created_at}")
    content.append(f"[bold]Updated:[/bold]     {ticket.updated_at}")
    content.append("")
    content.append("[bold]Description:[/bold]")
    content.append(ticket.description)

    if ticket.alerts:
        content.append("")
        content.append(f"[bold]Linked Alerts:[/bold] {len(ticket.alerts)}")
        for alert_id in ticket.alerts:
            content.append(f"  • {alert_id}")

    if ticket.comments:
        content.append("")
        content.append("[bold]Comments:[/bold]")
        for comment in ticket.comments:
            content.append(f"  [{comment.get('timestamp', '')}] {comment.get('author', 'System')}: {comment.get('text', '')}")

    panel = Panel(
        "\n".join(content),
        title=f"🎫 Ticket: {ticket.id}",
        border_style="bright_blue",
        padding=(1, 2),
    )
    console.print()
    console.print(panel)


def cmd_tickets_close(args: argparse.Namespace, config: dict) -> None:
    """Close a ticket with resolution."""
    tickets_dir = config.get("ticketing", {}).get("tickets_dir", "tickets/")
    ticket_mgr = TicketManager(tickets_dir)
    ticket = ticket_mgr.get_ticket(args.id)

    if not ticket:
        console.print(f"[bold red]✗  Ticket not found: {args.id}[/bold red]")
        sys.exit(1)

    ticket_mgr.close_ticket(args.id, args.resolution)
    console.print(f"[green]✓  Ticket {args.id} closed[/green]")
    console.print(f"  [dim]Resolution: {args.resolution}[/dim]")


def cmd_export(args: argparse.Namespace, config: dict) -> None:
    """Export alerts to CSV or JSON."""
    console.print(BANNER)

    # First, run the analysis pipeline to generate alerts
    console.print("[bold cyan][•][/bold cyan] Loading data for export...")

    # Parse all sample logs
    parser = LogParser()
    sample_dir = Path("sample_logs")
    if not sample_dir.exists():
        console.print("[bold red]✗  sample_logs/ directory not found. Run analyze first.[/bold red]")
        sys.exit(1)

    all_events = []
    for log_file in sample_dir.iterdir():
        if log_file.is_file():
            events = parser.parse_file(str(log_file))
            all_events.extend(events)

    # Evaluate rules
    rules_path = config.get("analysis", {}).get("rules_path", "config/rules.yaml")
    rules_engine = RulesEngine(rules_path)
    rules_engine.load_rules()
    alerts = rules_engine.evaluate(all_events)

    # Set up alert manager
    alert_mgr = AlertManager()
    for alert in alerts:
        alert_mgr.add_alert(alert)

    # Export
    output_path = args.output or f"alerts_export.{args.format}"
    console.print(f"[bold cyan][•][/bold cyan] Exporting {len(alerts)} alerts to {output_path}...", end=" ")
    alert_mgr.export_alerts(format=args.format, output_path=output_path)
    console.print("[green]✓[/green]")
    console.print(f"\n[bold green]Export complete:[/bold green] {output_path}")


# ─── Argument parser ─────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser with all subcommands."""
    parser = argparse.ArgumentParser(
        prog="siem-toolkit",
        description="🛡️  SIEM Automation Toolkit — Security Log Analysis & Threat Detection",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s analyze -i sample_logs/                  Analyze all sample logs
  %(prog)s analyze -i auth.log -f auth --correlate   Analyze with correlation
  %(prog)s dashboard -p 8080                         Start dashboard on port 8080
  %(prog)s tickets list                              List all incident tickets
  %(prog)s export --format csv -o alerts.csv         Export alerts to CSV
        """,
    )
    parser.add_argument(
        "--config", "-c",
        default="config/config.yaml",
        help="Path to configuration file (default: config/config.yaml)",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # ── analyze ───────────────────────────────────────────────────────────
    analyze_parser = subparsers.add_parser(
        "analyze",
        help="Parse and analyze log files for security threats",
    )
    analyze_parser.add_argument(
        "--input", "-i",
        required=True,
        help="Path to log file or directory containing log files",
    )
    analyze_parser.add_argument(
        "--format", "-f",
        default="auto",
        choices=["auto", "windows_xml", "syslog", "apache", "json", "auth"],
        help="Log format (default: auto-detect)",
    )
    analyze_parser.add_argument(
        "--rules", "-r",
        default="config/rules.yaml",
        help="Path to detection rules file (default: config/rules.yaml)",
    )
    analyze_parser.add_argument(
        "--output", "-o",
        default="./output",
        help="Output directory for reports (default: ./output)",
    )
    analyze_parser.add_argument(
        "--report-format",
        default="html",
        choices=["html", "json", "csv", "all"],
        help="Report output format (default: html)",
    )
    analyze_parser.add_argument(
        "--notify",
        action="store_true",
        help="Enable alert notifications (email/Slack)",
    )
    analyze_parser.add_argument(
        "--correlate",
        action="store_true",
        help="Enable cross-source event correlation",
    )
    analyze_parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose output",
    )

    # ── dashboard ─────────────────────────────────────────────────────────
    dashboard_parser = subparsers.add_parser(
        "dashboard",
        help="Launch the web-based security dashboard",
    )
    dashboard_parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="Dashboard host address (default: 0.0.0.0)",
    )
    dashboard_parser.add_argument(
        "--port", "-p",
        type=int,
        default=5000,
        help="Dashboard port (default: 5000)",
    )

    # ── tickets ───────────────────────────────────────────────────────────
    tickets_parser = subparsers.add_parser(
        "tickets",
        help="Manage incident tickets",
    )
    tickets_sub = tickets_parser.add_subparsers(dest="tickets_command", help="Ticket actions")

    # tickets list
    tickets_sub.add_parser("list", help="List all tickets")

    # tickets show
    show_parser = tickets_sub.add_parser("show", help="Show ticket details")
    show_parser.add_argument("id", help="Ticket ID")

    # tickets close
    close_parser = tickets_sub.add_parser("close", help="Close a ticket")
    close_parser.add_argument("id", help="Ticket ID")
    close_parser.add_argument(
        "--resolution",
        required=True,
        help="Resolution description",
    )

    # ── export ────────────────────────────────────────────────────────────
    export_parser = subparsers.add_parser(
        "export",
        help="Export alerts to CSV or JSON",
    )
    export_parser.add_argument(
        "--format",
        default="csv",
        choices=["csv", "json"],
        help="Export format (default: csv)",
    )
    export_parser.add_argument(
        "--output", "-o",
        help="Output file path",
    )

    return parser


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    """Main entry point for the SIEM Automation Toolkit CLI."""
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        console.print(BANNER)
        parser.print_help()
        sys.exit(0)

    # Load configuration
    config = load_config(args.config)

    # Set up logging
    verbose = getattr(args, "verbose", False)
    log_level = config.get("log_level", "INFO")
    setup_logging(log_level, verbose)

    # Dispatch commands
    if args.command == "analyze":
        cmd_analyze(args, config)
    elif args.command == "dashboard":
        cmd_dashboard(args, config)
    elif args.command == "tickets":
        if not args.tickets_command:
            console.print("[yellow]Usage: siem-toolkit tickets {list|show|close}[/yellow]")
            sys.exit(1)
        if args.tickets_command == "list":
            cmd_tickets_list(args, config)
        elif args.tickets_command == "show":
            cmd_tickets_show(args, config)
        elif args.tickets_command == "close":
            cmd_tickets_close(args, config)
    elif args.command == "export":
        cmd_export(args, config)


if __name__ == "__main__":
    main()
