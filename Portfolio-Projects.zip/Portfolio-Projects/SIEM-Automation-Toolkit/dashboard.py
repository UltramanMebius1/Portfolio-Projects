#!/usr/bin/env python3
"""
SIEM Automation Toolkit - Web Dashboard
=========================================
Flask-based web dashboard for real-time security monitoring,
alert management, and incident ticket tracking.
"""

import json
import logging
from datetime import datetime
from enum import Enum
from pathlib import Path

import yaml
from flask import Flask, render_template_string, jsonify, request, abort
from rich.console import Console

from siem import Severity, AlertStatus, Alert, LogEntry, CorrelatedEvent, Ticket
from siem.parser import LogParser
from siem.rules_engine import RulesEngine
from siem.alert_manager import AlertManager
from siem.correlator import LogCorrelator
from siem.mitre_mapper import MitreMapper
from siem.ticket_manager import TicketManager

logger = logging.getLogger(__name__)
console = Console()

# ─── Custom JSON Encoder ─────────────────────────────────────────────────────

class SIEMJSONEncoder(json.JSONEncoder):
    """Custom JSON encoder for SIEM data types."""

    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        if isinstance(obj, Enum):
            return obj.value
        if hasattr(obj, "__dataclass_fields__"):
            return {k: getattr(obj, k) for k in obj.__dataclass_fields__}
        return super().default(obj)


# ─── Dashboard HTML Templates ────────────────────────────────────────────────

DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIEM Automation Toolkit — Dashboard</title>
    <meta name="description" content="Real-time security monitoring dashboard for SIEM Automation Toolkit">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-primary: #0a0e17;
            --bg-secondary: #111827;
            --bg-card: #1a2332;
            --bg-card-hover: #1f2b3d;
            --border-color: #2a3548;
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --text-dim: #64748b;
            --accent-blue: #3b82f6;
            --accent-cyan: #06b6d4;
            --accent-purple: #8b5cf6;
            --severity-critical: #ef4444;
            --severity-high: #f97316;
            --severity-medium: #eab308;
            --severity-low: #3b82f6;
            --severity-info: #6b7280;
            --status-new: #f59e0b;
            --status-resolved: #22c55e;
            --status-investigating: #8b5cf6;
            --gradient-1: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --gradient-2: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --gradient-3: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            --gradient-4: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* ── Navigation ───────────────────────────────────── */
        .navbar {
            background: rgba(17, 24, 39, 0.8);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-color);
            padding: 0 2rem;
            height: 64px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .navbar-brand {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--text-primary);
            text-decoration: none;
        }

        .navbar-brand .shield { font-size: 1.5rem; }

        .nav-links {
            display: flex;
            gap: 0.25rem;
            list-style: none;
        }

        .nav-links a {
            color: var(--text-secondary);
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-size: 0.9rem;
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .nav-links a:hover, .nav-links a.active {
            color: var(--text-primary);
            background: var(--bg-card);
        }

        .nav-status {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
            color: var(--text-dim);
        }

        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #22c55e;
            animation: pulse 2s ease-in-out infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.4; }
        }

        /* ── Main Content ─────────────────────────────────── */
        .main-content {
            padding: 2rem;
            max-width: 1440px;
            margin: 0 auto;
        }

        .page-header {
            margin-bottom: 2rem;
        }

        .page-header h1 {
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }

        .page-header p {
            color: var(--text-secondary);
            font-size: 0.95rem;
        }

        /* ── Stat Cards ───────────────────────────────────── */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.25rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.5rem;
            position: relative;
            overflow: hidden;
            transition: transform 0.2s ease, border-color 0.2s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            border-color: var(--accent-blue);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
        }

        .stat-card:nth-child(1)::before { background: var(--gradient-1); }
        .stat-card:nth-child(2)::before { background: var(--gradient-2); }
        .stat-card:nth-child(3)::before { background: var(--gradient-3); }
        .stat-card:nth-child(4)::before { background: var(--gradient-4); }

        .stat-label {
            font-size: 0.8rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-dim);
            margin-bottom: 0.75rem;
        }

        .stat-value {
            font-size: 2.25rem;
            font-weight: 700;
            line-height: 1;
            margin-bottom: 0.5rem;
        }

        .stat-subtitle {
            font-size: 0.85rem;
            color: var(--text-secondary);
        }

        /* ── Severity Bar Chart ───────────────────────────── */
        .severity-chart {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        .severity-chart h2 {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 1.25rem;
        }

        .severity-bars {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }

        .severity-bar-row {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .severity-bar-label {
            width: 90px;
            font-size: 0.85rem;
            font-weight: 600;
            text-align: right;
        }

        .severity-bar-track {
            flex: 1;
            height: 28px;
            background: var(--bg-secondary);
            border-radius: 6px;
            overflow: hidden;
            position: relative;
        }

        .severity-bar-fill {
            height: 100%;
            border-radius: 6px;
            transition: width 0.8s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            align-items: center;
            padding-left: 10px;
            font-size: 0.8rem;
            font-weight: 600;
            color: white;
            min-width: fit-content;
        }

        .severity-bar-fill.critical { background: linear-gradient(90deg, #dc2626, #ef4444); }
        .severity-bar-fill.high { background: linear-gradient(90deg, #ea580c, #f97316); }
        .severity-bar-fill.medium { background: linear-gradient(90deg, #ca8a04, #eab308); }
        .severity-bar-fill.low { background: linear-gradient(90deg, #2563eb, #3b82f6); }
        .severity-bar-fill.info { background: linear-gradient(90deg, #4b5563, #6b7280); }

        .severity-bar-count {
            width: 50px;
            text-align: right;
            font-size: 0.95rem;
            font-weight: 700;
        }

        /* ── Alert Table ──────────────────────────────────── */
        .table-container {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            overflow: hidden;
            margin-bottom: 2rem;
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.25rem 1.5rem;
            border-bottom: 1px solid var(--border-color);
        }

        .table-header h2 {
            font-size: 1.1rem;
            font-weight: 600;
        }

        .table-filters {
            display: flex;
            gap: 0.5rem;
        }

        .filter-btn {
            padding: 0.4rem 0.9rem;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            background: transparent;
            color: var(--text-secondary);
            font-size: 0.8rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            font-family: inherit;
        }

        .filter-btn:hover, .filter-btn.active {
            border-color: var(--accent-blue);
            color: var(--accent-blue);
            background: rgba(59, 130, 246, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            text-align: left;
            padding: 0.85rem 1.5rem;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-dim);
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
        }

        td {
            padding: 0.85rem 1.5rem;
            font-size: 0.9rem;
            border-bottom: 1px solid rgba(42, 53, 72, 0.5);
        }

        tr:hover td {
            background: var(--bg-card-hover);
        }

        .severity-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.25rem 0.65rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .severity-badge.critical {
            background: rgba(239, 68, 68, 0.15);
            color: var(--severity-critical);
            border: 1px solid rgba(239, 68, 68, 0.3);
        }

        .severity-badge.high {
            background: rgba(249, 115, 22, 0.15);
            color: var(--severity-high);
            border: 1px solid rgba(249, 115, 22, 0.3);
        }

        .severity-badge.medium {
            background: rgba(234, 179, 8, 0.15);
            color: var(--severity-medium);
            border: 1px solid rgba(234, 179, 8, 0.3);
        }

        .severity-badge.low {
            background: rgba(59, 130, 246, 0.15);
            color: var(--severity-low);
            border: 1px solid rgba(59, 130, 246, 0.3);
        }

        .severity-badge.info {
            background: rgba(107, 114, 128, 0.15);
            color: var(--severity-info);
            border: 1px solid rgba(107, 114, 128, 0.3);
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.25rem 0.65rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .status-badge.new {
            background: rgba(245, 158, 11, 0.15);
            color: var(--status-new);
        }

        .status-badge.resolved {
            background: rgba(34, 197, 94, 0.15);
            color: var(--status-resolved);
        }

        .status-badge.investigating {
            background: rgba(139, 92, 246, 0.15);
            color: var(--status-investigating);
        }

        .mitre-tag {
            font-family: 'Fira Code', monospace;
            font-size: 0.8rem;
            color: var(--accent-cyan);
            background: rgba(6, 182, 212, 0.1);
            padding: 0.15rem 0.5rem;
            border-radius: 4px;
        }

        /* ── Status Action Buttons ────────────────────────── */
        .action-select {
            background: var(--bg-secondary);
            border: 1px solid var(--border-color);
            color: var(--text-primary);
            padding: 0.3rem 0.5rem;
            border-radius: 6px;
            font-size: 0.8rem;
            font-family: inherit;
            cursor: pointer;
        }

        .action-select:focus {
            outline: none;
            border-color: var(--accent-blue);
        }

        /* ── Tickets Section ──────────────────────────────── */
        .ticket-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1.25rem 1.5rem;
            margin-bottom: 1rem;
            transition: border-color 0.2s ease;
        }

        .ticket-card:hover {
            border-color: var(--accent-purple);
        }

        .ticket-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.75rem;
        }

        .ticket-id {
            font-weight: 700;
            color: var(--accent-purple);
            font-size: 0.9rem;
        }

        .ticket-title {
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .ticket-meta {
            font-size: 0.85rem;
            color: var(--text-dim);
        }

        /* ── Responsive ───────────────────────────────────── */
        @media (max-width: 768px) {
            .main-content { padding: 1rem; }
            .stats-grid { grid-template-columns: 1fr 1fr; }
            .navbar { padding: 0 1rem; }
            .table-header { flex-direction: column; gap: 0.75rem; align-items: flex-start; }
            .table-filters { flex-wrap: wrap; }
            td, th { padding: 0.6rem 0.75rem; font-size: 0.8rem; }
        }

        /* ── Animations ───────────────────────────────────── */
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .animate-in {
            animation: fadeInUp 0.4s ease forwards;
        }

        .animate-in:nth-child(1) { animation-delay: 0s; }
        .animate-in:nth-child(2) { animation-delay: 0.05s; }
        .animate-in:nth-child(3) { animation-delay: 0.1s; }
        .animate-in:nth-child(4) { animation-delay: 0.15s; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="/" class="navbar-brand">
            <span class="shield">🛡️</span>
            <span>SIEM Toolkit</span>
        </a>
        <ul class="nav-links">
            <li><a href="/" id="nav-dashboard" class="active">Dashboard</a></li>
            <li><a href="/alerts" id="nav-alerts">Alerts</a></li>
            <li><a href="/tickets" id="nav-tickets">Tickets</a></li>
        </ul>
        <div class="nav-status">
            <span class="status-dot"></span>
            <span>Monitoring Active</span>
        </div>
    </nav>

    <main class="main-content">
        {{ content | safe }}
    </main>

    <script>
        // ── Active nav link ──────────────────────────────
        const currentPath = window.location.pathname;
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.classList.toggle('active', link.getAttribute('href') === currentPath);
        });

        // ── Alert status update ──────────────────────────
        function updateAlertStatus(alertId, newStatus) {
            fetch('/api/alerts/' + alertId + '/status', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: newStatus })
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                }
            })
            .catch(err => console.error('Error updating status:', err));
        }

        // ── Filter buttons ──────────────────────────────
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const filter = this.dataset.filter;
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');

                document.querySelectorAll('table tbody tr').forEach(row => {
                    if (filter === 'all') {
                        row.style.display = '';
                    } else {
                        const severity = row.dataset.severity;
                        row.style.display = severity === filter ? '' : 'none';
                    }
                });
            });
        });

        // ── Animate severity bars on load ────────────────
        window.addEventListener('load', function() {
            document.querySelectorAll('.severity-bar-fill').forEach(bar => {
                const width = bar.dataset.width;
                bar.style.width = width + '%';
            });
        });
    </script>
</body>
</html>
"""

DASHBOARD_CONTENT = """
<div class="page-header">
    <h1>📊 Security Dashboard</h1>
    <p>Real-time security monitoring and threat detection overview</p>
</div>

<div class="stats-grid">
    <div class="stat-card animate-in">
        <div class="stat-label">Total Alerts</div>
        <div class="stat-value" style="color: var(--accent-blue);">{{ stats.total }}</div>
        <div class="stat-subtitle">Across all severity levels</div>
    </div>
    <div class="stat-card animate-in">
        <div class="stat-label">Critical</div>
        <div class="stat-value" style="color: var(--severity-critical);">{{ stats.by_severity.CRITICAL | default(0) }}</div>
        <div class="stat-subtitle">Require immediate attention</div>
    </div>
    <div class="stat-card animate-in">
        <div class="stat-label">Events Processed</div>
        <div class="stat-value" style="color: var(--accent-cyan);">{{ total_events }}</div>
        <div class="stat-subtitle">Total log entries parsed</div>
    </div>
    <div class="stat-card animate-in">
        <div class="stat-label">Correlations</div>
        <div class="stat-value" style="color: var(--accent-purple);">{{ total_correlations }}</div>
        <div class="stat-subtitle">Related event chains</div>
    </div>
</div>

<div class="severity-chart">
    <h2>Severity Distribution</h2>
    <div class="severity-bars">
        {% for sev_name, sev_class in [('CRITICAL','critical'),('HIGH','high'),('MEDIUM','medium'),('LOW','low'),('INFO','info')] %}
        {% set count = stats.by_severity.get(sev_name, 0) %}
        {% set pct = (count / stats.total * 100) if stats.total > 0 else 0 %}
        <div class="severity-bar-row">
            <span class="severity-bar-label {{ sev_class }}">{{ sev_name }}</span>
            <div class="severity-bar-track">
                <div class="severity-bar-fill {{ sev_class }}" data-width="{{ pct | int }}" style="width: 0%;">
                    {% if pct > 8 %}{{ count }}{% endif %}
                </div>
            </div>
            <span class="severity-bar-count">{{ count }}</span>
        </div>
        {% endfor %}
    </div>
</div>

<div class="table-container">
    <div class="table-header">
        <h2>🚨 Recent Alerts</h2>
        <div class="table-filters">
            <button class="filter-btn active" data-filter="all">All</button>
            <button class="filter-btn" data-filter="CRITICAL">Critical</button>
            <button class="filter-btn" data-filter="HIGH">High</button>
            <button class="filter-btn" data-filter="MEDIUM">Medium</button>
            <button class="filter-btn" data-filter="LOW">Low</button>
        </div>
    </div>
    <table>
        <thead>
            <tr>
                <th>Severity</th>
                <th>Rule</th>
                <th>Description</th>
                <th>MITRE</th>
                <th>Status</th>
                <th>Time</th>
            </tr>
        </thead>
        <tbody>
            {% for alert in alerts[:20] %}
            <tr data-severity="{{ alert.severity.value }}">
                <td><span class="severity-badge {{ alert.severity.value | lower }}">{{ alert.severity.value }}</span></td>
                <td style="font-weight: 600;">{{ alert.rule_name }}</td>
                <td>{{ alert.description[:60] }}{% if alert.description|length > 60 %}…{% endif %}</td>
                <td>{% if alert.mitre_technique %}<span class="mitre-tag">{{ alert.mitre_technique }}</span>{% else %}—{% endif %}</td>
                <td><span class="status-badge {{ alert.status.value | lower }}">{{ alert.status.value }}</span></td>
                <td style="color: var(--text-dim); font-size: 0.85rem;">{{ alert.timestamp.strftime('%H:%M:%S') if alert.timestamp else '—' }}</td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
</div>
"""

ALERTS_CONTENT = """
<div class="page-header">
    <h1>🚨 All Alerts</h1>
    <p>Complete alert history with filtering and status management</p>
</div>

<div class="table-container">
    <div class="table-header">
        <h2>Alerts ({{ alerts | length }})</h2>
        <div class="table-filters">
            <button class="filter-btn active" data-filter="all">All</button>
            <button class="filter-btn" data-filter="CRITICAL">Critical</button>
            <button class="filter-btn" data-filter="HIGH">High</button>
            <button class="filter-btn" data-filter="MEDIUM">Medium</button>
            <button class="filter-btn" data-filter="LOW">Low</button>
        </div>
    </div>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Severity</th>
                <th>Rule</th>
                <th>Description</th>
                <th>MITRE</th>
                <th>Events</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            {% for alert in alerts %}
            <tr data-severity="{{ alert.severity.value }}">
                <td style="font-family: monospace; font-size: 0.8rem; color: var(--text-dim);">{{ alert.id[:8] }}…</td>
                <td><span class="severity-badge {{ alert.severity.value | lower }}">{{ alert.severity.value }}</span></td>
                <td style="font-weight: 600;">{{ alert.rule_name }}</td>
                <td>{{ alert.description[:50] }}{% if alert.description|length > 50 %}…{% endif %}</td>
                <td>{% if alert.mitre_technique %}<span class="mitre-tag">{{ alert.mitre_technique }}</span>{% else %}—{% endif %}</td>
                <td style="text-align: center;">{{ alert.source_events | length if alert.source_events else alert.count }}</td>
                <td><span class="status-badge {{ alert.status.value | lower }}">{{ alert.status.value }}</span></td>
                <td>
                    <select class="action-select" onchange="updateAlertStatus('{{ alert.id }}', this.value)">
                        <option value="">— Change —</option>
                        <option value="ACKNOWLEDGED">Acknowledge</option>
                        <option value="INVESTIGATING">Investigate</option>
                        <option value="RESOLVED">Resolve</option>
                        <option value="FALSE_POSITIVE">False Positive</option>
                    </select>
                </td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
</div>
"""

TICKETS_CONTENT = """
<div class="page-header">
    <h1>🎫 Incident Tickets</h1>
    <p>Track and manage security incident tickets</p>
</div>

{% if tickets %}
    {% for ticket in tickets %}
    <div class="ticket-card animate-in">
        <div class="ticket-card-header">
            <span class="ticket-id">{{ ticket.id }}</span>
            <span class="severity-badge {{ ticket.severity.value | lower }}">{{ ticket.severity.value }}</span>
        </div>
        <div class="ticket-title">{{ ticket.title }}</div>
        <p style="color: var(--text-secondary); font-size: 0.9rem; margin-bottom: 0.75rem;">
            {{ ticket.description[:120] }}{% if ticket.description|length > 120 %}…{% endif %}
        </p>
        <div class="ticket-meta">
            <span>Status: <strong>{{ ticket.status }}</strong></span>
            &nbsp;•&nbsp;
            <span>Created: {{ ticket.created_at.strftime('%Y-%m-%d %H:%M') if ticket.created_at else '—' }}</span>
            &nbsp;•&nbsp;
            <span>Assigned: {{ ticket.assigned_to or 'Unassigned' }}</span>
        </div>
    </div>
    {% endfor %}
{% else %}
    <div class="table-container" style="padding: 3rem; text-align: center;">
        <p style="color: var(--text-dim); font-size: 1.1rem;">No tickets found. Run an analysis to generate incident tickets.</p>
    </div>
{% endif %}
"""

ERROR_404_HTML = """
<div class="page-header" style="text-align: center; padding-top: 4rem;">
    <h1>404 — Page Not Found</h1>
    <p>The requested resource could not be found.</p>
    <p style="margin-top: 1rem;"><a href="/" style="color: var(--accent-blue);">← Back to Dashboard</a></p>
</div>
"""

ERROR_500_HTML = """
<div class="page-header" style="text-align: center; padding-top: 4rem;">
    <h1>500 — Internal Server Error</h1>
    <p>Something went wrong. Please try again.</p>
    <p style="margin-top: 1rem;"><a href="/" style="color: var(--accent-blue);">← Back to Dashboard</a></p>
</div>
"""


# ─── App Factory ──────────────────────────────────────────────────────────────

def create_app(config: dict = None) -> Flask:
    """Create and configure the Flask dashboard application."""
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.json_encoder = SIEMJSONEncoder

    # Load config if not provided
    if config is None:
        config_path = Path("config/config.yaml")
        if config_path.exists():
            with open(config_path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f)
        else:
            config = {}

    # ── Initialize SIEM components and process sample data ────────────────
    with app.app_context():
        parser = LogParser()
        all_events = []

        sample_dir = Path("sample_logs")
        if sample_dir.exists():
            for log_file in sorted(sample_dir.iterdir()):
                if log_file.is_file():
                    try:
                        events = parser.parse_file(str(log_file))
                        all_events.extend(events)
                    except Exception as e:
                        logger.warning(f"Failed to parse {log_file}: {e}")

        # Rules engine
        rules_path = config.get("analysis", {}).get("rules_path", "config/rules.yaml")
        rules_engine = RulesEngine(rules_path)
        rules_engine.load_rules()
        alerts = rules_engine.evaluate(all_events)

        # Correlation
        correlator = LogCorrelator()
        time_window = config.get("analysis", {}).get("time_window", 300)
        correlations = correlator.correlate(all_events, time_window=time_window)

        # MITRE mapping
        mitre_path = "config/mitre_mapping.yaml"
        mapper = MitreMapper(mitre_path)
        for alert in alerts:
            mapper.map_alert(alert)

        # Alert management
        alert_mgr = AlertManager()
        for alert in alerts:
            alert_mgr.add_alert(alert)
        alert_mgr.deduplicate_alerts()

        # Ticketing
        tickets_dir = config.get("ticketing", {}).get("tickets_dir", "tickets/")
        ticket_mgr = TicketManager(tickets_dir)
        auto_severities = config.get("ticketing", {}).get(
            "auto_create_severities", ["CRITICAL", "HIGH"]
        )
        for alert in alerts:
            if alert.severity.value in auto_severities:
                try:
                    ticket_mgr.create_ticket(alert)
                except Exception:
                    pass

        # Store in app config for access in routes
        app.config["siem_alerts"] = alerts
        app.config["siem_events"] = all_events
        app.config["siem_correlations"] = correlations
        app.config["siem_alert_mgr"] = alert_mgr
        app.config["siem_ticket_mgr"] = ticket_mgr
        app.config["siem_stats"] = alert_mgr.get_statistics()

    # ── Jinja helpers ─────────────────────────────────────────────────────

    @app.template_filter('lower')
    def lower_filter(s):
        return str(s).lower() if s else ''

    # ── Routes ────────────────────────────────────────────────────────────

    @app.route("/")
    def index():
        """Main dashboard page."""
        stats = app.config["siem_stats"]
        alerts = app.config["siem_alerts"]
        total_events = len(app.config["siem_events"])
        total_correlations = len(app.config["siem_correlations"])

        from jinja2 import Template
        content_template = Template(DASHBOARD_CONTENT)
        content = content_template.render(
            stats=stats,
            alerts=alerts,
            total_events=total_events,
            total_correlations=total_correlations,
        )

        page_template = Template(DASHBOARD_HTML)
        return page_template.render(content=content)

    @app.route("/alerts")
    def alerts_page():
        """All alerts page with filtering."""
        alerts = app.config["siem_alerts"]

        # Optional query filters
        severity_filter = request.args.get("severity")
        status_filter = request.args.get("status")

        filtered = alerts
        if severity_filter:
            filtered = [a for a in filtered if a.severity.value == severity_filter.upper()]
        if status_filter:
            filtered = [a for a in filtered if a.status.value == status_filter.upper()]

        from jinja2 import Template
        content_template = Template(ALERTS_CONTENT)
        content = content_template.render(alerts=filtered)

        page_template = Template(DASHBOARD_HTML)
        return page_template.render(content=content)

    @app.route("/tickets")
    def tickets_page():
        """Tickets management page."""
        ticket_mgr = app.config["siem_ticket_mgr"]
        tickets = ticket_mgr.list_tickets(status=None)

        from jinja2 import Template
        content_template = Template(TICKETS_CONTENT)
        content = content_template.render(tickets=tickets)

        page_template = Template(DASHBOARD_HTML)
        return page_template.render(content=content)

    # ── API Routes ────────────────────────────────────────────────────────

    @app.route("/api/alerts")
    def api_alerts():
        """JSON API for alerts."""
        alerts = app.config["siem_alerts"]
        severity = request.args.get("severity")
        status = request.args.get("status")
        limit = request.args.get("limit", type=int)

        result = alerts
        if severity:
            result = [a for a in result if a.severity.value == severity.upper()]
        if status:
            result = [a for a in result if a.status.value == status.upper()]
        if limit:
            result = result[:limit]

        return json.dumps(
            {"alerts": result, "count": len(result)},
            cls=SIEMJSONEncoder,
        ), 200, {"Content-Type": "application/json"}

    @app.route("/api/stats")
    def api_stats():
        """JSON API for statistics."""
        stats = app.config["siem_stats"]
        return json.dumps(stats, cls=SIEMJSONEncoder), 200, {"Content-Type": "application/json"}

    @app.route("/api/alerts/<alert_id>/status", methods=["POST"])
    def api_update_alert_status(alert_id):
        """Update alert status via API."""
        data = request.get_json()
        if not data or "status" not in data:
            return jsonify({"error": "Missing 'status' field"}), 400

        new_status_str = data["status"]
        try:
            new_status = AlertStatus(new_status_str)
        except ValueError:
            return jsonify({"error": f"Invalid status: {new_status_str}"}), 400

        alert_mgr = app.config["siem_alert_mgr"]
        try:
            alert_mgr.update_status(alert_id, new_status)
            # Refresh stats
            app.config["siem_stats"] = alert_mgr.get_statistics()
            return jsonify({"success": True, "alert_id": alert_id, "new_status": new_status_str})
        except Exception as e:
            return jsonify({"error": str(e)}), 404

    @app.route("/api/tickets")
    def api_tickets():
        """JSON API for tickets."""
        ticket_mgr = app.config["siem_ticket_mgr"]
        status_filter = request.args.get("status")
        tickets = ticket_mgr.list_tickets(status=status_filter)
        return json.dumps(
            {"tickets": tickets, "count": len(tickets)},
            cls=SIEMJSONEncoder,
        ), 200, {"Content-Type": "application/json"}

    # ── Error Handlers ────────────────────────────────────────────────────

    @app.errorhandler(404)
    def page_not_found(e):
        from jinja2 import Template
        page_template = Template(DASHBOARD_HTML)
        return page_template.render(content=ERROR_404_HTML), 404

    @app.errorhandler(500)
    def internal_error(e):
        from jinja2 import Template
        page_template = Template(DASHBOARD_HTML)
        return page_template.render(content=ERROR_500_HTML), 500

    return app


# ─── Standalone Entrypoint ────────────────────────────────────────────────────

if __name__ == "__main__":
    console.print("[bold cyan]🛡️  SIEM Dashboard[/bold cyan] starting...")

    config_path = Path("config/config.yaml")
    if config_path.exists():
        with open(config_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f)
    else:
        config = {}

    dashboard_cfg = config.get("dashboard", {})
    host = dashboard_cfg.get("host", "0.0.0.0")
    port = dashboard_cfg.get("port", 5000)
    debug = dashboard_cfg.get("debug", False)

    console.print(f"  [dim]→ http://{host}:{port}[/dim]")

    app = create_app(config)
    app.run(host=host, port=port, debug=debug)
