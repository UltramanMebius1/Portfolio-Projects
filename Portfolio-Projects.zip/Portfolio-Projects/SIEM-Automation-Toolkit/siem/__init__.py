"""
SIEM Automation Toolkit - Core Data Models
==========================================

Provides the shared data models used across all SIEM modules including
log entries, alerts, correlated events, and incident tickets.

Author: Koventhan M
Version: 1.0.0
"""

from __future__ import annotations

__version__ = "1.0.0"

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, Dict, Any, List
from enum import Enum
import uuid


class Severity(Enum):
    """Severity levels for security events and alerts."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class AlertStatus(Enum):
    """Lifecycle status of a security alert."""
    NEW = "new"
    ACKNOWLEDGED = "acknowledged"
    INVESTIGATING = "investigating"
    RESOLVED = "resolved"
    FALSE_POSITIVE = "false_positive"


@dataclass
class LogEntry:
    """
    Represents a single parsed log event from any supported source.

    Attributes:
        timestamp: When the event occurred.
        source: The originating system or application.
        event_type: Categorized event type (e.g., 'failed_logon', 'process_creation').
        severity: The assessed severity level.
        message: Human-readable event description.
        raw_data: The original unparsed log line or block.
        metadata: Arbitrary key-value pairs for extended fields.
        source_file: Path to the log file this entry was parsed from.
        source_ip: Source IP address if applicable.
        dest_ip: Destination IP address if applicable.
        user: Username associated with the event.
        process: Process name or command line if applicable.
    """
    timestamp: datetime
    source: str
    event_type: str
    severity: Severity
    message: str
    raw_data: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    source_file: str = ""
    source_ip: str = ""
    dest_ip: str = ""
    user: str = ""
    process: str = ""


@dataclass
class Alert:
    """
    A security alert generated when one or more detection rules match.

    Attributes:
        id: Unique 8-character identifier.
        timestamp: When the alert was created.
        rule_name: Name of the detection rule that triggered this alert.
        severity: Alert severity level.
        description: Human-readable description of what was detected.
        source_events: The log entries that triggered this alert.
        mitre_technique: MITRE ATT&CK technique ID (e.g., T1110).
        mitre_tactic: MITRE ATT&CK tactic name (e.g., Credential Access).
        status: Current lifecycle status.
        metadata: Additional contextual data.
        count: Number of occurrences (for deduplicated alerts).
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: datetime = field(default_factory=datetime.now)
    rule_name: str = ""
    severity: Severity = Severity.INFO
    description: str = ""
    source_events: List[LogEntry] = field(default_factory=list)
    mitre_technique: str = ""
    mitre_tactic: str = ""
    status: AlertStatus = AlertStatus.NEW
    metadata: Dict[str, Any] = field(default_factory=dict)
    count: int = 1


@dataclass
class CorrelatedEvent:
    """
    A group of related log entries linked by correlation logic.

    Attributes:
        id: Unique 8-character identifier.
        events: The list of correlated log entries.
        correlation_type: Type of correlation (e.g., 'brute_force', 'lateral_movement').
        description: Human-readable description of the correlated activity.
        severity: Assessed severity of the correlated activity.
        confidence: Confidence score from 0.0 (low) to 1.0 (high).
        timestamp: When the correlation was identified.
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    events: List[LogEntry] = field(default_factory=list)
    correlation_type: str = ""
    description: str = ""
    severity: Severity = Severity.INFO
    confidence: float = 0.0
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class Ticket:
    """
    An incident response ticket created from one or more alerts.

    Attributes:
        id: Unique 8-character identifier.
        title: Short title summarizing the incident.
        description: Detailed description of the incident.
        severity: Ticket severity level.
        status: Current ticket status (open, in_progress, closed).
        created_at: Ticket creation timestamp.
        updated_at: Last modification timestamp.
        assigned_to: Analyst or team assigned to the ticket.
        alerts: List of associated alert IDs.
        comments: Timeline of comments and updates.
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    title: str = ""
    description: str = ""
    severity: Severity = Severity.INFO
    status: str = "open"
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    assigned_to: str = "unassigned"
    alerts: List[str] = field(default_factory=list)
    comments: List[Dict[str, Any]] = field(default_factory=list)


__all__ = [
    "Severity",
    "AlertStatus",
    "LogEntry",
    "Alert",
    "CorrelatedEvent",
    "Ticket",
    "__version__",
]
