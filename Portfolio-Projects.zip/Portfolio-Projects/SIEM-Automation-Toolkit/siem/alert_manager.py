"""
SIEM Automation Toolkit - Alert Manager
========================================

Manages the lifecycle of security alerts: storage, querying, deduplication,
status updates, statistics, and export to CSV/JSON.

Author: Koventhan M
"""

from __future__ import annotations

import csv
import json
import logging
from collections import defaultdict
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from siem import Alert, AlertStatus, LogEntry, Severity

logger = logging.getLogger(__name__)


class _SIEMJSONEncoder(json.JSONEncoder):
    """Custom JSON encoder that handles datetime, Enum, and dataclass objects."""

    def default(self, o: Any) -> Any:
        if isinstance(o, datetime):
            return o.isoformat()
        if isinstance(o, Enum):
            return o.value
        if isinstance(o, LogEntry):
            return {
                "timestamp": o.timestamp.isoformat(),
                "source": o.source,
                "event_type": o.event_type,
                "severity": o.severity.value,
                "message": o.message,
                "source_ip": o.source_ip,
                "dest_ip": o.dest_ip,
                "user": o.user,
                "process": o.process,
                "metadata": o.metadata,
            }
        return super().default(o)


class AlertManager:
    """
    In-memory alert store with querying, deduplication, and export.

    Alerts are stored in a plain list and indexed by ID for O(1) lookup.
    """

    def __init__(self) -> None:
        self._alerts: List[Alert] = []
        self._index: Dict[str, Alert] = {}

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def add_alert(self, alert: Alert) -> None:
        """
        Add a new alert to the store.

        Args:
            alert: The Alert object to add.
        """
        if alert.id in self._index:
            logger.warning("Alert '%s' already exists – updating", alert.id)
            self._index[alert.id] = alert
            self._alerts = [a if a.id != alert.id else alert for a in self._alerts]
            return

        self._alerts.append(alert)
        self._index[alert.id] = alert
        logger.info(
            "Alert added: id=%s rule='%s' severity=%s",
            alert.id,
            alert.rule_name,
            alert.severity.value,
        )

    def get_alerts(
        self,
        severity: Optional[Severity] = None,
        status: Optional[AlertStatus] = None,
        limit: Optional[int] = None,
    ) -> List[Alert]:
        """
        Retrieve alerts with optional filters.

        Args:
            severity: Filter by severity level.
            status: Filter by alert status.
            limit: Maximum number of alerts to return.

        Returns:
            Filtered (and optionally limited) list of alerts.
        """
        results = self._alerts

        if severity is not None:
            results = [a for a in results if a.severity == severity]
        if status is not None:
            results = [a for a in results if a.status == status]

        # Sort by timestamp descending (newest first)
        results = sorted(results, key=lambda a: a.timestamp, reverse=True)

        if limit is not None and limit > 0:
            results = results[:limit]

        return results

    def get_alert_by_id(self, alert_id: str) -> Optional[Alert]:
        """
        Retrieve a single alert by its ID.

        Args:
            alert_id: The unique alert identifier.

        Returns:
            The matching Alert or ``None``.
        """
        return self._index.get(alert_id)

    def update_status(self, alert_id: str, status: AlertStatus) -> bool:
        """
        Update the status of an existing alert.

        Args:
            alert_id: The alert to update.
            status: New status value.

        Returns:
            ``True`` if the alert was found and updated, ``False`` otherwise.
        """
        alert = self._index.get(alert_id)
        if alert is None:
            logger.warning("Alert '%s' not found for status update", alert_id)
            return False

        old_status = alert.status
        alert.status = status
        logger.info(
            "Alert '%s' status changed: %s -> %s",
            alert_id,
            old_status.value,
            status.value,
        )
        return True

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    def get_statistics(self) -> Dict[str, Any]:
        """
        Compute summary statistics over all stored alerts.

        Returns:
            Dictionary with keys: ``total``, ``by_severity``, ``by_status``,
            ``by_rule``, ``earliest``, ``latest``.
        """
        total = len(self._alerts)

        by_severity: Dict[str, int] = defaultdict(int)
        by_status: Dict[str, int] = defaultdict(int)
        by_rule: Dict[str, int] = defaultdict(int)

        timestamps: List[datetime] = []

        for alert in self._alerts:
            by_severity[alert.severity.value] += 1
            by_status[alert.status.value] += 1
            by_rule[alert.rule_name] += 1
            timestamps.append(alert.timestamp)

        return {
            "total": total,
            "by_severity": dict(by_severity),
            "by_status": dict(by_status),
            "by_rule": dict(by_rule),
            "earliest": min(timestamps).isoformat() if timestamps else None,
            "latest": max(timestamps).isoformat() if timestamps else None,
        }

    # ------------------------------------------------------------------
    # Deduplication
    # ------------------------------------------------------------------

    def deduplicate_alerts(self) -> int:
        """
        Merge alerts that share the same rule_name and severity within a
        5-minute window.  The ``count`` field of the surviving alert is
        incremented and the source events are combined.

        Returns:
            Number of duplicate alerts removed.
        """
        from datetime import timedelta

        if len(self._alerts) < 2:
            return 0

        # Sort by rule_name then timestamp
        sorted_alerts = sorted(self._alerts, key=lambda a: (a.rule_name, a.timestamp))

        merged: List[Alert] = []
        current = sorted_alerts[0]

        removed = 0
        for alert in sorted_alerts[1:]:
            if (
                alert.rule_name == current.rule_name
                and alert.severity == current.severity
                and abs((alert.timestamp - current.timestamp).total_seconds()) <= 300
            ):
                # Merge into current
                current.count += alert.count
                current.source_events.extend(alert.source_events)
                # Keep latest metadata
                current.metadata.update(alert.metadata)
                removed += 1
                logger.debug("Merged alert '%s' into '%s'", alert.id, current.id)
            else:
                merged.append(current)
                current = alert

        merged.append(current)

        self._alerts = merged
        self._index = {a.id: a for a in self._alerts}

        if removed:
            logger.info("Deduplication removed %d duplicate alert(s)", removed)
        return removed

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export_alerts(self, fmt: str, output_path: str | Path) -> None:
        """
        Export alerts to a file.

        Args:
            fmt: ``'csv'`` or ``'json'``.
            output_path: Destination file path.
        """
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        if fmt.lower() == "csv":
            self._export_csv(path)
        elif fmt.lower() == "json":
            self._export_json(path)
        else:
            logger.error("Unsupported export format '%s'. Use 'csv' or 'json'.", fmt)
            return

        logger.info("Exported %d alerts to '%s' (%s)", len(self._alerts), path, fmt)

    def _export_csv(self, path: Path) -> None:
        """Write alerts to a CSV file."""
        fieldnames = [
            "id",
            "timestamp",
            "rule_name",
            "severity",
            "description",
            "mitre_technique",
            "mitre_tactic",
            "status",
            "count",
            "source_events_count",
        ]
        with open(path, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for alert in self._alerts:
                writer.writerow(
                    {
                        "id": alert.id,
                        "timestamp": alert.timestamp.isoformat(),
                        "rule_name": alert.rule_name,
                        "severity": alert.severity.value,
                        "description": alert.description,
                        "mitre_technique": alert.mitre_technique,
                        "mitre_tactic": alert.mitre_tactic,
                        "status": alert.status.value,
                        "count": alert.count,
                        "source_events_count": len(alert.source_events),
                    }
                )

    def _export_json(self, path: Path) -> None:
        """Write alerts to a JSON file."""
        data = []
        for alert in self._alerts:
            data.append(
                {
                    "id": alert.id,
                    "timestamp": alert.timestamp.isoformat(),
                    "rule_name": alert.rule_name,
                    "severity": alert.severity.value,
                    "description": alert.description,
                    "mitre_technique": alert.mitre_technique,
                    "mitre_tactic": alert.mitre_tactic,
                    "status": alert.status.value,
                    "count": alert.count,
                    "source_events": [
                        {
                            "timestamp": e.timestamp.isoformat(),
                            "source": e.source,
                            "event_type": e.event_type,
                            "severity": e.severity.value,
                            "message": e.message,
                            "source_ip": e.source_ip,
                            "dest_ip": e.dest_ip,
                            "user": e.user,
                        }
                        for e in alert.source_events
                    ],
                    "metadata": alert.metadata,
                }
            )
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, cls=_SIEMJSONEncoder)

    # ------------------------------------------------------------------
    # Console display
    # ------------------------------------------------------------------

    def display_alerts(
        self,
        severity: Optional[Severity] = None,
        status: Optional[AlertStatus] = None,
        limit: int = 50,
    ) -> None:
        """
        Print alerts to the console using the *rich* library when available,
        falling back to plain-text output otherwise.

        Args:
            severity: Filter by severity.
            status: Filter by status.
            limit: Maximum number of alerts to display.
        """
        alerts = self.get_alerts(severity=severity, status=status, limit=limit)
        if not alerts:
            print("No alerts to display.")
            return

        try:
            self._display_rich(alerts)
        except ImportError:
            self._display_plain(alerts)

    @staticmethod
    def _display_rich(alerts: List[Alert]) -> None:
        """Display alerts in a rich table."""
        from rich.console import Console
        from rich.table import Table

        severity_colors = {
            Severity.CRITICAL: "bold red",
            Severity.HIGH: "red",
            Severity.MEDIUM: "yellow",
            Severity.LOW: "cyan",
            Severity.INFO: "green",
        }

        table = Table(title="Security Alerts", show_lines=True)
        table.add_column("ID", style="dim", width=10)
        table.add_column("Timestamp", width=20)
        table.add_column("Rule", width=30)
        table.add_column("Severity", width=10)
        table.add_column("Status", width=14)
        table.add_column("Description", width=50)
        table.add_column("MITRE", width=12)
        table.add_column("Count", width=6, justify="right")

        for alert in alerts:
            sev_style = severity_colors.get(alert.severity, "white")
            table.add_row(
                alert.id,
                alert.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                alert.rule_name,
                f"[{sev_style}]{alert.severity.value.upper()}[/{sev_style}]",
                alert.status.value,
                alert.description[:80],
                alert.mitre_technique,
                str(alert.count),
            )

        console = Console()
        console.print(table)

    @staticmethod
    def _display_plain(alerts: List[Alert]) -> None:
        """Fallback plain-text alert display."""
        header = (
            f"{'ID':<10} {'Timestamp':<20} {'Rule':<30} {'Severity':<10} "
            f"{'Status':<14} {'MITRE':<12} {'Count':>5}"
        )
        print("=" * len(header))
        print("SECURITY ALERTS")
        print("=" * len(header))
        print(header)
        print("-" * len(header))
        for alert in alerts:
            print(
                f"{alert.id:<10} "
                f"{alert.timestamp.strftime('%Y-%m-%d %H:%M:%S'):<20} "
                f"{alert.rule_name:<30} "
                f"{alert.severity.value.upper():<10} "
                f"{alert.status.value:<14} "
                f"{alert.mitre_technique:<12} "
                f"{alert.count:>5}"
            )
        print("=" * len(header))
