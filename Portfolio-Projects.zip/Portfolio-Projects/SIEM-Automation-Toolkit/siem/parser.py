"""
SIEM Automation Toolkit - Multi-Format Log Parser
==================================================

Parses log files from multiple sources into a unified LogEntry format.
Supports Windows Event Log XML, Syslog, Apache access logs, JSON logs,
and authentication logs with automatic format detection.

Author: Koventhan M
"""

from __future__ import annotations

import json
import logging
import re
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict, Any

from siem import LogEntry, Severity

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Windows Event ID to human-readable event type mapping
# ---------------------------------------------------------------------------
WINDOWS_EVENT_MAP: Dict[str, str] = {
    "4624": "successful_logon",
    "4625": "failed_logon",
    "4634": "logoff",
    "4648": "explicit_logon",
    "4672": "special_privileges_assigned",
    "4688": "process_creation",
    "4689": "process_termination",
    "4697": "service_installed",
    "4698": "scheduled_task_created",
    "4720": "user_account_created",
    "4722": "user_account_enabled",
    "4724": "password_reset_attempt",
    "4725": "user_account_disabled",
    "4726": "user_account_deleted",
    "4728": "member_added_to_security_group",
    "4732": "member_added_to_local_group",
    "4740": "account_locked_out",
    "4756": "member_added_to_universal_group",
    "4767": "account_unlocked",
    "1102": "audit_log_cleared",
    "7045": "service_installed",
    "4663": "object_access_attempt",
    "4657": "registry_value_modified",
    "5156": "network_connection_allowed",
    "5157": "network_connection_blocked",
}

# ---------------------------------------------------------------------------
# Severity mapping helpers
# ---------------------------------------------------------------------------
WINDOWS_LEVEL_MAP: Dict[str, Severity] = {
    "1": Severity.CRITICAL,
    "2": Severity.HIGH,
    "3": Severity.MEDIUM,
    "4": Severity.LOW,
    "5": Severity.INFO,
    "0": Severity.INFO,
    "critical": Severity.CRITICAL,
    "error": Severity.HIGH,
    "warning": Severity.MEDIUM,
    "information": Severity.LOW,
    "verbose": Severity.INFO,
}

# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------
SYSLOG_PATTERN = re.compile(
    r"^(?P<month>\w{3})\s+(?P<day>\d{1,2})\s+"
    r"(?P<time>\d{2}:\d{2}:\d{2})\s+"
    r"(?P<hostname>\S+)\s+"
    r"(?P<process>\S+?)(?:\[(?P<pid>\d+)\])?\s*:\s*"
    r"(?P<message>.*)$"
)

APACHE_COMBINED_PATTERN = re.compile(
    r'^(?P<ip>\S+)\s+\S+\s+(?P<user>\S+)\s+'
    r'\[(?P<timestamp>[^\]]+)\]\s+'
    r'"(?P<method>\S+)\s+(?P<url>\S+)\s+(?P<protocol>\S+)"\s+'
    r'(?P<status>\d{3})\s+(?P<size>\S+)'
    r'(?:\s+"(?P<referrer>[^"]*)")?\s*'
    r'(?:"(?P<useragent>[^"]*)")?'
)

SQL_INJECTION_PATTERNS = [
    re.compile(r"(?i)(?:union\s+select|select\s+.*\s+from)", re.IGNORECASE),
    re.compile(r"(?i)(?:drop\s+table|insert\s+into|update\s+\w+\s+set)", re.IGNORECASE),
    re.compile(r"(?i)(?:or\s+1\s*=\s*1|'\s*or\s*'|;\s*--)", re.IGNORECASE),
    re.compile(r"(?i)(?:exec\s*\(|xp_cmdshell|sp_executesql)", re.IGNORECASE),
    re.compile(r"(?i)(?:benchmark\s*\(|sleep\s*\(|waitfor\s+delay)", re.IGNORECASE),
]

DIRECTORY_TRAVERSAL_PATTERN = re.compile(r"\.\./|\.\.\\|%2e%2e%2f|%2e%2e/|\.%2e/", re.IGNORECASE)

AUTH_FAILURE_PATTERNS = [
    re.compile(r"(?i)(?:failed\s+password|authentication\s+failure|invalid\s+user)", re.IGNORECASE),
    re.compile(r"(?i)(?:pam_unix.*authentication\s+failure)", re.IGNORECASE),
    re.compile(r"(?i)(?:failed\s+login|login\s+failed)", re.IGNORECASE),
]

SUDO_PATTERN = re.compile(r"sudo\s*:", re.IGNORECASE)
SSH_PATTERN = re.compile(r"sshd\[", re.IGNORECASE)

IP_PATTERN = re.compile(
    r"(?:(?:from|src|source|SRC|rhost=)\s*)?(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})"
)

USER_PATTERN = re.compile(
    r"(?:user(?:name)?|acct|USER|for)\s*[=: ]\s*(\S+)", re.IGNORECASE
)


class LogParser:
    """
    Multi-format log parser with automatic format detection.

    Supported formats:
        - Windows Event Log XML
        - Standard Syslog (RFC 3164)
        - Apache combined access log
        - Newline-delimited JSON
        - Linux auth / secure log
    """

    # Namespace commonly found in Windows Event XML
    _WIN_NS = {"e": "http://schemas.microsoft.com/win/2004/08/events/event"}

    def __init__(self) -> None:
        self._parsers = {
            "xml": self._parse_windows_xml,
            "evtx": self._parse_windows_xml,
            "log": self._auto_detect_and_parse,
            "json": self._parse_json_file,
            "jsonl": self._parse_json_file,
            "syslog": self._parse_syslog_file,
            "auth": self._parse_auth_file,
            "access": self._parse_apache_file,
            "txt": self._auto_detect_and_parse,
        }

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def parse_file(self, file_path: str | Path) -> List[LogEntry]:
        """
        Parse a log file into a list of LogEntry objects.

        The format is auto-detected based on file extension and, when
        ambiguous, by inspecting the first non-empty lines of the file.

        Args:
            file_path: Path to the log file.

        Returns:
            List of parsed LogEntry objects.
        """
        path = Path(file_path)
        if not path.exists():
            logger.error("File not found: %s", path)
            return []

        ext = path.suffix.lstrip(".").lower()
        parser_fn = self._parsers.get(ext, self._auto_detect_and_parse)
        logger.info("Parsing file '%s' with detected extension '%s'", path.name, ext)

        try:
            entries = parser_fn(path)
            logger.info("Parsed %d log entries from '%s'", len(entries), path.name)
            return entries
        except Exception:
            logger.exception("Fatal error parsing '%s'", path)
            return []

    def parse_text(self, text: str, fmt: str = "auto") -> List[LogEntry]:
        """
        Parse raw log text supplied as a string.

        Args:
            text: The raw log content.
            fmt: One of 'windows_xml', 'syslog', 'apache', 'json', 'auth', or 'auto'.

        Returns:
            List of parsed LogEntry objects.
        """
        dispatch = {
            "windows_xml": self._parse_windows_xml_text,
            "syslog": self._parse_syslog_lines,
            "apache": self._parse_apache_lines,
            "json": self._parse_json_lines,
            "auth": self._parse_auth_lines,
        }
        if fmt != "auto" and fmt in dispatch:
            return dispatch[fmt](text.splitlines())

        return self._auto_detect_lines(text.splitlines())

    # ------------------------------------------------------------------
    # Format detection
    # ------------------------------------------------------------------

    def _auto_detect_and_parse(self, path: Path) -> List[LogEntry]:
        """Read the file and detect the format from content."""
        content = path.read_text(encoding="utf-8", errors="replace")
        lines = content.splitlines()
        return self._auto_detect_lines(lines, source_file=str(path))

    def _auto_detect_lines(
        self, lines: List[str], source_file: str = ""
    ) -> List[LogEntry]:
        """Heuristic format detection from the first non-blank lines."""
        sample = []
        for ln in lines:
            stripped = ln.strip()
            if stripped:
                sample.append(stripped)
            if len(sample) >= 10:
                break

        if not sample:
            return []

        first = sample[0]

        # XML?
        if first.startswith("<?xml") or first.startswith("<Event") or first.startswith("<Events"):
            logger.debug("Detected Windows XML format")
            return self._parse_windows_xml_text(lines, source_file)

        # JSON?
        if first.startswith("{"):
            logger.debug("Detected JSON format")
            return self._parse_json_lines(lines, source_file)

        # Apache combined?
        if APACHE_COMBINED_PATTERN.match(first):
            logger.debug("Detected Apache combined log format")
            return self._parse_apache_lines(lines, source_file)

        # Syslog / auth?
        if SYSLOG_PATTERN.match(first):
            # Distinguish auth from generic syslog
            auth_keywords = ("sshd", "pam_unix", "sudo", "login", "passwd", "auth")
            auth_count = sum(
                1 for s in sample if any(kw in s.lower() for kw in auth_keywords)
            )
            if auth_count > len(sample) * 0.4:
                logger.debug("Detected auth log format")
                return self._parse_auth_lines(lines, source_file)
            logger.debug("Detected syslog format")
            return self._parse_syslog_lines(lines, source_file)

        logger.warning("Could not detect format; falling back to syslog parser")
        return self._parse_syslog_lines(lines, source_file)

    # ------------------------------------------------------------------
    # Windows Event Log XML parser
    # ------------------------------------------------------------------

    def _parse_windows_xml(self, path: Path) -> List[LogEntry]:
        content = path.read_text(encoding="utf-8", errors="replace")
        return self._parse_windows_xml_text(content.splitlines(), source_file=str(path))

    def _parse_windows_xml_text(
        self, lines: List[str], source_file: str = ""
    ) -> List[LogEntry]:
        """Parse Windows Event Log XML (one or more <Event> elements)."""
        entries: List[LogEntry] = []
        xml_text = "\n".join(lines)

        # Wrap in root element if necessary
        if not xml_text.strip().startswith("<Events"):
            xml_text = f"<Events>{xml_text}</Events>"

        # Remove XML declaration if present (can cause issues when wrapped)
        xml_text = re.sub(r"<\?xml[^?]*\?>", "", xml_text)

        try:
            root = ET.fromstring(xml_text)
        except ET.ParseError:
            logger.warning("Failed to parse XML; attempting line-by-line extraction")
            return self._parse_windows_xml_fallback(lines, source_file)

        # Handle namespaced and non-namespaced XML
        events = root.findall(".//e:Event", self._WIN_NS)
        if not events:
            events = root.findall(".//Event")

        for event_elem in events:
            try:
                entry = self._parse_single_windows_event(event_elem, source_file)
                if entry:
                    entries.append(entry)
            except Exception:
                logger.debug("Skipping malformed Event element", exc_info=True)

        return entries

    def _parse_single_windows_event(
        self, event_elem: ET.Element, source_file: str
    ) -> Optional[LogEntry]:
        """Extract fields from a single <Event> XML element."""
        ns = self._WIN_NS

        def _find(parent: ET.Element, tag: str) -> Optional[ET.Element]:
            elem = parent.find(f"e:{tag}", ns)
            if elem is None:
                elem = parent.find(tag)
            return elem

        def _find_text(parent: ET.Element, tag: str) -> str:
            elem = _find(parent, tag)
            return (elem.text or "").strip() if elem is not None else ""

        system = _find(event_elem, "System")
        if system is None:
            return None

        # Provider
        provider_elem = _find(system, "Provider")
        provider = ""
        if provider_elem is not None:
            provider = provider_elem.get("Name", "") or _find_text(system, "Provider")

        # EventID
        event_id = _find_text(system, "EventID")

        # TimeCreated
        time_elem = _find(system, "TimeCreated")
        timestamp = datetime.now()
        if time_elem is not None:
            sys_time = time_elem.get("SystemTime", "")
            if sys_time:
                for fmt in (
                    "%Y-%m-%dT%H:%M:%S.%fZ",
                    "%Y-%m-%dT%H:%M:%SZ",
                    "%Y-%m-%d %H:%M:%S",
                ):
                    try:
                        timestamp = datetime.strptime(sys_time, fmt)
                        break
                    except ValueError:
                        continue

        # Level
        level_text = _find_text(system, "Level")
        severity = WINDOWS_LEVEL_MAP.get(level_text.lower(), Severity.INFO)

        # Computer
        computer = _find_text(system, "Computer")

        # Security UserID
        security_elem = _find(system, "Security")
        user_id = ""
        if security_elem is not None:
            user_id = security_elem.get("UserID", "")

        # EventData
        event_data: Dict[str, Any] = {}
        ed = _find(event_elem, "EventData")
        if ed is not None:
            for data_elem in ed:
                tag = data_elem.tag.split("}")[-1] if "}" in data_elem.tag else data_elem.tag
                name = data_elem.get("Name", tag)
                event_data[name] = (data_elem.text or "").strip()

        event_type = WINDOWS_EVENT_MAP.get(event_id, f"windows_event_{event_id}")

        # Determine severity boost for critical event IDs
        critical_events = {"1102", "4720", "4726", "7045"}
        high_events = {"4625", "4672", "4688", "4697", "4698"}
        if event_id in critical_events and severity.value not in ("critical",):
            severity = Severity.CRITICAL
        elif event_id in high_events and severity == Severity.INFO:
            severity = Severity.HIGH

        # Extract IPs from event data
        source_ip = event_data.get("IpAddress", event_data.get("SourceAddress", ""))
        dest_ip = event_data.get("DestAddress", event_data.get("DestinationAddress", ""))
        user = event_data.get("TargetUserName", event_data.get("SubjectUserName", user_id))
        process_name = event_data.get("NewProcessName", event_data.get("ProcessName", ""))

        message_parts = [f"EventID={event_id}", f"Provider={provider}"]
        if user:
            message_parts.append(f"User={user}")
        if source_ip and source_ip != "-":
            message_parts.append(f"SourceIP={source_ip}")
        message = f"[{event_type}] {', '.join(message_parts)}"

        return LogEntry(
            timestamp=timestamp,
            source=computer or provider,
            event_type=event_type,
            severity=severity,
            message=message,
            raw_data=ET.tostring(event_elem, encoding="unicode"),
            metadata=event_data,
            source_file=source_file,
            source_ip=source_ip if source_ip != "-" else "",
            dest_ip=dest_ip if dest_ip != "-" else "",
            user=user,
            process=process_name,
        )

    def _parse_windows_xml_fallback(
        self, lines: List[str], source_file: str
    ) -> List[LogEntry]:
        """Fallback: try to extract individual <Event>...</Event> blocks."""
        entries: List[LogEntry] = []
        buffer: List[str] = []
        inside = False

        for line in lines:
            if "<Event" in line:
                inside = True
                buffer = [line]
            elif inside:
                buffer.append(line)
                if "</Event>" in line:
                    inside = False
                    try:
                        elem = ET.fromstring("\n".join(buffer))
                        entry = self._parse_single_windows_event(elem, source_file)
                        if entry:
                            entries.append(entry)
                    except ET.ParseError:
                        logger.debug("Skipping malformed Event block")
                    buffer = []
        return entries

    # ------------------------------------------------------------------
    # Syslog parser
    # ------------------------------------------------------------------

    def _parse_syslog_file(self, path: Path) -> List[LogEntry]:
        content = path.read_text(encoding="utf-8", errors="replace")
        return self._parse_syslog_lines(content.splitlines(), source_file=str(path))

    def _parse_syslog_lines(
        self, lines: List[str], source_file: str = ""
    ) -> List[LogEntry]:
        entries: List[LogEntry] = []
        current_year = datetime.now().year

        for line_no, raw_line in enumerate(lines, start=1):
            raw_line = raw_line.strip()
            if not raw_line:
                continue
            match = SYSLOG_PATTERN.match(raw_line)
            if not match:
                logger.debug("Syslog: skipping malformed line %d", line_no)
                continue

            try:
                ts_str = f"{match.group('month')} {match.group('day')} {match.group('time')}"
                timestamp = datetime.strptime(ts_str, "%b %d %H:%M:%S").replace(year=current_year)
            except ValueError:
                timestamp = datetime.now()

            hostname = match.group("hostname")
            process = match.group("process") or ""
            message = match.group("message") or ""

            severity, event_type = self._classify_syslog(message, process)

            # Extract IP
            ip_match = IP_PATTERN.search(message)
            source_ip = ip_match.group(1) if ip_match else ""

            # Extract user
            user_match = USER_PATTERN.search(message)
            user = user_match.group(1) if user_match else ""

            entries.append(
                LogEntry(
                    timestamp=timestamp,
                    source=hostname,
                    event_type=event_type,
                    severity=severity,
                    message=message,
                    raw_data=raw_line,
                    metadata={"process": process, "pid": match.group("pid") or ""},
                    source_file=source_file,
                    source_ip=source_ip,
                    user=user,
                    process=process,
                )
            )
        return entries

    @staticmethod
    def _classify_syslog(message: str, process: str) -> tuple[Severity, str]:
        """Classify a syslog message into severity and event type."""
        msg_lower = message.lower()
        proc_lower = process.lower()

        # Auth failures
        for pat in AUTH_FAILURE_PATTERNS:
            if pat.search(message):
                return Severity.HIGH, "auth_failure"

        # Sudo
        if SUDO_PATTERN.search(message):
            if "incorrect password" in msg_lower:
                return Severity.HIGH, "sudo_failure"
            if "command" in msg_lower:
                return Severity.MEDIUM, "sudo_command"
            return Severity.MEDIUM, "sudo_event"

        # SSH
        if SSH_PATTERN.search(process) or "sshd" in proc_lower:
            if "accepted" in msg_lower:
                return Severity.LOW, "ssh_login_success"
            if "failed" in msg_lower or "invalid" in msg_lower:
                return Severity.HIGH, "ssh_login_failure"
            if "disconnected" in msg_lower or "closed" in msg_lower:
                return Severity.INFO, "ssh_disconnect"
            return Severity.LOW, "ssh_event"

        # Kernel / firewall
        if proc_lower.startswith("kernel") or "iptables" in msg_lower:
            if "drop" in msg_lower or "denied" in msg_lower or "blocked" in msg_lower:
                return Severity.MEDIUM, "firewall_block"
            return Severity.LOW, "kernel_event"

        # Generic error / warning keywords
        if any(kw in msg_lower for kw in ("error", "fail", "crit")):
            return Severity.MEDIUM, "system_error"
        if "warn" in msg_lower:
            return Severity.LOW, "system_warning"

        return Severity.INFO, "syslog_event"

    # ------------------------------------------------------------------
    # Apache access log parser
    # ------------------------------------------------------------------

    def _parse_apache_file(self, path: Path) -> List[LogEntry]:
        content = path.read_text(encoding="utf-8", errors="replace")
        return self._parse_apache_lines(content.splitlines(), source_file=str(path))

    def _parse_apache_lines(
        self, lines: List[str], source_file: str = ""
    ) -> List[LogEntry]:
        entries: List[LogEntry] = []

        for line_no, raw_line in enumerate(lines, start=1):
            raw_line = raw_line.strip()
            if not raw_line:
                continue
            match = APACHE_COMBINED_PATTERN.match(raw_line)
            if not match:
                logger.debug("Apache: skipping malformed line %d", line_no)
                continue

            ip = match.group("ip")
            user = match.group("user")
            ts_str = match.group("timestamp")
            method = match.group("method")
            url = match.group("url")
            protocol = match.group("protocol")
            status = int(match.group("status"))
            size = match.group("size")
            referrer = match.group("referrer") or ""
            useragent = match.group("useragent") or ""

            # Parse timestamp: 10/Oct/2023:13:55:36 -0700
            try:
                timestamp = datetime.strptime(ts_str.split()[0], "%d/%b/%Y:%H:%M:%S")
            except ValueError:
                timestamp = datetime.now()

            severity, event_type, extra_msg = self._classify_apache(
                status, method, url, useragent
            )

            message = f"{method} {url} -> {status}"
            if extra_msg:
                message += f" [{extra_msg}]"

            if user == "-":
                user = ""

            entries.append(
                LogEntry(
                    timestamp=timestamp,
                    source="apache",
                    event_type=event_type,
                    severity=severity,
                    message=message,
                    raw_data=raw_line,
                    metadata={
                        "method": method,
                        "url": url,
                        "protocol": protocol,
                        "status_code": status,
                        "size": size,
                        "referrer": referrer,
                        "user_agent": useragent,
                    },
                    source_file=source_file,
                    source_ip=ip,
                    user=user,
                )
            )
        return entries

    @staticmethod
    def _classify_apache(
        status: int, method: str, url: str, useragent: str
    ) -> tuple[Severity, str, str]:
        """Classify an Apache log line into severity, event type, extra description."""
        # SQL injection in URL
        for sqli_pat in SQL_INJECTION_PATTERNS:
            if sqli_pat.search(url):
                return Severity.CRITICAL, "sql_injection_attempt", "SQL injection pattern detected"

        # Directory traversal
        if DIRECTORY_TRAVERSAL_PATTERN.search(url):
            return Severity.HIGH, "directory_traversal", "Directory traversal attempt"

        # Status-code based
        if status == 403:
            return Severity.MEDIUM, "http_forbidden", "Access forbidden"
        if status == 401:
            return Severity.MEDIUM, "http_unauthorized", "Authentication required"
        if status == 404:
            return Severity.LOW, "http_not_found", "Resource not found (possible scan)"
        if status >= 500:
            return Severity.HIGH, "http_server_error", f"Server error {status}"
        if status >= 400:
            return Severity.LOW, "http_client_error", f"Client error {status}"

        # Suspicious user-agents
        suspicious_uas = ("nikto", "sqlmap", "nmap", "dirbuster", "gobuster", "hydra", "wpscan")
        ua_lower = useragent.lower()
        if any(tool in ua_lower for tool in suspicious_uas):
            return Severity.HIGH, "suspicious_user_agent", f"Known attack tool user-agent"

        return Severity.INFO, "http_access", ""

    # ------------------------------------------------------------------
    # JSON log parser
    # ------------------------------------------------------------------

    def _parse_json_file(self, path: Path) -> List[LogEntry]:
        content = path.read_text(encoding="utf-8", errors="replace")
        return self._parse_json_lines(content.splitlines(), source_file=str(path))

    def _parse_json_lines(
        self, lines: List[str], source_file: str = ""
    ) -> List[LogEntry]:
        entries: List[LogEntry] = []

        for line_no, raw_line in enumerate(lines, start=1):
            raw_line = raw_line.strip()
            if not raw_line:
                continue
            try:
                data = json.loads(raw_line)
            except json.JSONDecodeError:
                logger.debug("JSON: skipping malformed line %d", line_no)
                continue

            if not isinstance(data, dict):
                logger.debug("JSON: line %d is not an object, skipping", line_no)
                continue

            # Flexible timestamp extraction
            timestamp = datetime.now()
            for ts_key in ("timestamp", "@timestamp", "time", "datetime", "date", "ts"):
                ts_val = data.get(ts_key)
                if ts_val:
                    timestamp = self._parse_flexible_timestamp(str(ts_val))
                    break

            # Source
            source = str(
                data.get("source", data.get("hostname", data.get("host", "unknown")))
            )

            # Event type
            event_type = str(
                data.get("event_type", data.get("event", data.get("action", "json_event")))
            )

            # Severity
            sev_str = str(
                data.get("severity", data.get("level", data.get("priority", "info")))
            ).lower()
            severity = {
                "critical": Severity.CRITICAL,
                "crit": Severity.CRITICAL,
                "high": Severity.HIGH,
                "error": Severity.HIGH,
                "err": Severity.HIGH,
                "medium": Severity.MEDIUM,
                "warning": Severity.MEDIUM,
                "warn": Severity.MEDIUM,
                "low": Severity.LOW,
                "notice": Severity.LOW,
                "info": Severity.INFO,
                "information": Severity.INFO,
                "debug": Severity.INFO,
            }.get(sev_str, Severity.INFO)

            message = str(data.get("message", data.get("msg", json.dumps(data))))

            source_ip = str(data.get("source_ip", data.get("src_ip", data.get("ip", ""))))
            dest_ip = str(data.get("dest_ip", data.get("dst_ip", data.get("destination_ip", ""))))
            user = str(data.get("user", data.get("username", data.get("account", ""))))
            process = str(data.get("process", data.get("program", data.get("application", ""))))

            entries.append(
                LogEntry(
                    timestamp=timestamp,
                    source=source,
                    event_type=event_type,
                    severity=severity,
                    message=message,
                    raw_data=raw_line,
                    metadata=data,
                    source_file=source_file,
                    source_ip=source_ip,
                    dest_ip=dest_ip,
                    user=user,
                    process=process,
                )
            )
        return entries

    # ------------------------------------------------------------------
    # Auth log parser
    # ------------------------------------------------------------------

    def _parse_auth_file(self, path: Path) -> List[LogEntry]:
        content = path.read_text(encoding="utf-8", errors="replace")
        return self._parse_auth_lines(content.splitlines(), source_file=str(path))

    def _parse_auth_lines(
        self, lines: List[str], source_file: str = ""
    ) -> List[LogEntry]:
        """Parse authentication-focused logs (similar to syslog with auth classification)."""
        entries: List[LogEntry] = []
        current_year = datetime.now().year

        for line_no, raw_line in enumerate(lines, start=1):
            raw_line = raw_line.strip()
            if not raw_line:
                continue

            match = SYSLOG_PATTERN.match(raw_line)
            if not match:
                logger.debug("Auth: skipping malformed line %d", line_no)
                continue

            try:
                ts_str = f"{match.group('month')} {match.group('day')} {match.group('time')}"
                timestamp = datetime.strptime(ts_str, "%b %d %H:%M:%S").replace(year=current_year)
            except ValueError:
                timestamp = datetime.now()

            hostname = match.group("hostname")
            process = match.group("process") or ""
            message = match.group("message") or ""

            severity, event_type = self._classify_auth(message, process)

            ip_match = IP_PATTERN.search(message)
            source_ip = ip_match.group(1) if ip_match else ""

            user_match = USER_PATTERN.search(message)
            user = user_match.group(1) if user_match else ""

            entries.append(
                LogEntry(
                    timestamp=timestamp,
                    source=hostname,
                    event_type=event_type,
                    severity=severity,
                    message=message,
                    raw_data=raw_line,
                    metadata={"process": process, "pid": match.group("pid") or ""},
                    source_file=source_file,
                    source_ip=source_ip,
                    user=user,
                    process=process,
                )
            )
        return entries

    @staticmethod
    def _classify_auth(message: str, process: str) -> tuple[Severity, str]:
        """Classify an auth log line."""
        msg_lower = message.lower()

        # Failed auth
        for pat in AUTH_FAILURE_PATTERNS:
            if pat.search(message):
                return Severity.HIGH, "auth_failure"

        # Successful auth
        if "accepted password" in msg_lower or "accepted publickey" in msg_lower:
            return Severity.LOW, "auth_success"

        # Account changes
        if "useradd" in msg_lower or "new user" in msg_lower:
            return Severity.MEDIUM, "user_created"
        if "userdel" in msg_lower or "delete user" in msg_lower:
            return Severity.MEDIUM, "user_deleted"
        if "password changed" in msg_lower or "passwd" in process.lower():
            return Severity.MEDIUM, "password_change"
        if "usermod" in msg_lower or "group changed" in msg_lower:
            return Severity.MEDIUM, "user_modified"

        # Sudo
        if SUDO_PATTERN.search(message):
            if "incorrect password" in msg_lower or "authentication failure" in msg_lower:
                return Severity.HIGH, "sudo_failure"
            return Severity.MEDIUM, "sudo_command"

        # Session events
        if "session opened" in msg_lower:
            return Severity.INFO, "session_open"
        if "session closed" in msg_lower:
            return Severity.INFO, "session_close"

        # PAM
        if "pam_" in msg_lower:
            return Severity.LOW, "pam_event"

        return Severity.INFO, "auth_event"

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_flexible_timestamp(ts_str: str) -> datetime:
        """Try multiple timestamp formats and return a datetime."""
        formats = [
            "%Y-%m-%dT%H:%M:%S.%fZ",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S.%f%z",
            "%Y-%m-%dT%H:%M:%S%z",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M:%S.%f",
            "%Y-%m-%d %H:%M:%S",
            "%d/%b/%Y:%H:%M:%S",
            "%b %d %H:%M:%S",
        ]
        for fmt in formats:
            try:
                return datetime.strptime(ts_str, fmt)
            except ValueError:
                continue

        # Try Unix epoch
        try:
            epoch = float(ts_str)
            return datetime.fromtimestamp(epoch)
        except (ValueError, OSError):
            pass

        logger.debug("Could not parse timestamp '%s', using current time", ts_str)
        return datetime.now()
