"""
SIEM Automation Toolkit - Detection Rules Engine
=================================================

Evaluates parsed log entries against a set of YAML-defined detection rules.
Supports threshold-based alerting, pattern matching, compound conditions,
and time-window aggregation.

Author: Koventhan M
"""

from __future__ import annotations

import logging
import re
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

import yaml

from siem import Alert, AlertStatus, LogEntry, Severity

logger = logging.getLogger(__name__)


class RulesEngine:
    """
    Detection rules engine that loads YAML rules and evaluates log events.

    Each rule defines conditions (with operators), optional thresholds,
    time windows, MITRE ATT&CK mappings, and compound logic (all/any).
    """

    # Supported comparison operators
    _OPERATORS: Dict[str, Callable[[Any, Any], bool]] = {
        "equals": lambda a, b: str(a).lower() == str(b).lower(),
        "not_equals": lambda a, b: str(a).lower() != str(b).lower(),
        "contains": lambda a, b: str(b).lower() in str(a).lower(),
        "regex": lambda a, b: bool(re.search(str(b), str(a), re.IGNORECASE)),
        "gt": lambda a, b: _to_num(a) > _to_num(b),
        "lt": lambda a, b: _to_num(a) < _to_num(b),
        "gte": lambda a, b: _to_num(a) >= _to_num(b),
        "lte": lambda a, b: _to_num(a) <= _to_num(b),
        "in": lambda a, b: str(a).lower() in [str(v).lower() for v in (b if isinstance(b, list) else [b])],
        "not_in": lambda a, b: str(a).lower() not in [str(v).lower() for v in (b if isinstance(b, list) else [b])],
        "starts_with": lambda a, b: str(a).lower().startswith(str(b).lower()),
        "ends_with": lambda a, b: str(a).lower().endswith(str(b).lower()),
    }

    def __init__(self, rules_path: Optional[str | Path] = None) -> None:
        """
        Initialize the rules engine.

        Args:
            rules_path: Path to a YAML rules file.  If ``None``, an empty
                        ruleset is used and rules can be loaded later.
        """
        self.rules: List[Dict[str, Any]] = []
        if rules_path:
            self.load_rules(rules_path)

    # ------------------------------------------------------------------
    # Rule loading
    # ------------------------------------------------------------------

    def load_rules(self, rules_path: str | Path) -> None:
        """
        Load detection rules from a YAML file.

        The YAML must have a top-level ``rules`` key containing a list.

        Args:
            rules_path: Path to the YAML rules file.
        """
        path = Path(rules_path)
        if not path.exists():
            logger.error("Rules file not found: %s", path)
            return

        try:
            with open(path, "r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or {}
        except yaml.YAMLError:
            logger.exception("Failed to parse YAML rules file: %s", path)
            return

        raw_rules = data.get("rules", [])
        loaded = 0
        for rule in raw_rules:
            if not isinstance(rule, dict):
                logger.warning("Skipping non-dict rule entry")
                continue
            if not rule.get("enabled", True):
                logger.debug("Skipping disabled rule '%s'", rule.get("name", "?"))
                continue
            self.rules.append(self._normalize_rule(rule))
            loaded += 1

        logger.info("Loaded %d enabled rules from '%s'", loaded, path.name)

    def add_rule(self, rule: Dict[str, Any]) -> None:
        """
        Programmatically add a single rule dictionary.

        Args:
            rule: Rule dictionary following the same schema as the YAML format.
        """
        self.rules.append(self._normalize_rule(rule))
        logger.info("Added rule '%s'", rule.get("name", "unnamed"))

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def evaluate(self, events: List[LogEntry]) -> List[Alert]:
        """
        Evaluate all loaded rules against a list of log entries.

        Returns a list of :class:`Alert` objects for each rule match.

        Args:
            events: Parsed log entries to evaluate.

        Returns:
            List of generated alerts.
        """
        if not self.rules:
            logger.warning("No rules loaded – nothing to evaluate")
            return []

        alerts: List[Alert] = []
        logger.info("Evaluating %d rules against %d events", len(self.rules), len(events))

        for rule in self.rules:
            try:
                rule_alerts = self._evaluate_rule(rule, events)
                alerts.extend(rule_alerts)
                if rule_alerts:
                    logger.info(
                        "Rule '%s' generated %d alert(s)", rule["name"], len(rule_alerts)
                    )
            except Exception:
                logger.exception("Error evaluating rule '%s'", rule.get("name", "?"))

        logger.info("Total alerts generated: %d", len(alerts))
        return alerts

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _evaluate_rule(
        self, rule: Dict[str, Any], events: List[LogEntry]
    ) -> List[Alert]:
        """Evaluate a single rule against events."""
        threshold: int = rule.get("threshold", 1)
        time_window: int = rule.get("time_window", 0)  # seconds
        group_by: Optional[str] = rule.get("group_by")

        # Phase 1 – filter events matching the rule conditions
        matching: List[LogEntry] = []
        for event in events:
            if self._event_matches(rule, event):
                matching.append(event)

        if not matching:
            return []

        logger.debug(
            "Rule '%s': %d events match conditions (threshold=%d, window=%ds)",
            rule["name"],
            len(matching),
            threshold,
            time_window,
        )

        # Phase 2 – group and apply threshold + time window
        if threshold <= 1 and not time_window:
            # Simple pattern rule – one alert per matching event
            return [self._create_alert(rule, [evt]) for evt in matching]

        # Group events for threshold evaluation
        groups: Dict[str, List[LogEntry]] = defaultdict(list)
        for evt in matching:
            key = self._get_group_key(evt, group_by) if group_by else "__all__"
            groups[key].append(evt)

        alerts: List[Alert] = []
        for group_key, group_events in groups.items():
            # Sort by timestamp
            group_events.sort(key=lambda e: e.timestamp)

            if time_window > 0:
                # Sliding window threshold
                window_alerts = self._sliding_window_threshold(
                    rule, group_events, threshold, time_window
                )
                alerts.extend(window_alerts)
            else:
                # Simple count threshold (no time constraint)
                if len(group_events) >= threshold:
                    alerts.append(self._create_alert(rule, group_events))

        return alerts

    def _sliding_window_threshold(
        self,
        rule: Dict[str, Any],
        events: List[LogEntry],
        threshold: int,
        time_window: int,
    ) -> List[Alert]:
        """Apply a sliding-window threshold check."""
        alerts: List[Alert] = []
        window_delta = timedelta(seconds=time_window)

        i = 0
        while i < len(events):
            window_start = events[i].timestamp
            window_end = window_start + window_delta

            window_events = [
                e for e in events[i:] if e.timestamp <= window_end
            ]

            if len(window_events) >= threshold:
                alerts.append(self._create_alert(rule, window_events))
                # Skip past the window to avoid duplicate alerts
                i += len(window_events)
            else:
                i += 1

        return alerts

    def _event_matches(self, rule: Dict[str, Any], event: LogEntry) -> bool:
        """Check whether a single event matches the rule conditions."""
        conditions = rule.get("conditions", [])
        if not conditions:
            return False

        logic = rule.get("logic", "all")  # 'all' or 'any'
        results: List[bool] = []

        for cond in conditions:
            field_name: str = cond.get("field", "")
            operator: str = cond.get("operator", "equals")
            value = cond.get("value")

            event_value = self._extract_field(event, field_name)
            op_fn = self._OPERATORS.get(operator)
            if op_fn is None:
                logger.warning("Unknown operator '%s' in rule '%s'", operator, rule["name"])
                results.append(False)
                continue

            try:
                results.append(op_fn(event_value, value))
            except Exception:
                results.append(False)

        if logic == "any":
            return any(results)
        return all(results)  # default: 'all'

    @staticmethod
    def _extract_field(event: LogEntry, field_name: str) -> Any:
        """
        Extract a field value from a LogEntry.

        Supports direct attributes and dotted paths into ``metadata``.
        """
        # Direct attribute
        if hasattr(event, field_name):
            val = getattr(event, field_name)
            # Enum -> value string
            if isinstance(val, Severity):
                return val.value
            return val

        # Metadata dotted path (e.g., 'metadata.status_code')
        parts = field_name.split(".")
        if parts[0] == "metadata" and len(parts) > 1:
            return event.metadata.get(parts[1], "")

        # Fallback – try metadata directly
        return event.metadata.get(field_name, "")

    @staticmethod
    def _get_group_key(event: LogEntry, group_by: Optional[str]) -> str:
        """Build a grouping key for threshold rules."""
        if group_by is None:
            return "__all__"

        fields = [f.strip() for f in group_by.split(",")]
        parts: List[str] = []
        for field_name in fields:
            if hasattr(event, field_name):
                parts.append(str(getattr(event, field_name)))
            else:
                parts.append(str(event.metadata.get(field_name, "")))
        return "|".join(parts)

    def _create_alert(
        self, rule: Dict[str, Any], source_events: List[LogEntry]
    ) -> Alert:
        """Create an Alert from a matched rule and its source events."""
        severity = _parse_severity(rule.get("severity", "info"))

        description = rule.get("description", rule.get("name", "Detection rule matched"))
        if len(source_events) > 1:
            description += f" ({len(source_events)} events)"

        return Alert(
            rule_name=rule.get("name", "unknown"),
            severity=severity,
            description=description,
            source_events=source_events,
            mitre_technique=rule.get("mitre_technique", ""),
            mitre_tactic=rule.get("mitre_tactic", ""),
            status=AlertStatus.NEW,
            metadata={
                "rule_id": rule.get("id", ""),
                "group_by": rule.get("group_by", ""),
                "threshold": rule.get("threshold", 1),
                "time_window": rule.get("time_window", 0),
            },
            count=len(source_events),
        )

    @staticmethod
    def _normalize_rule(rule: Dict[str, Any]) -> Dict[str, Any]:
        """Fill in defaults for missing optional rule fields."""
        defaults: Dict[str, Any] = {
            "id": "",
            "name": "unnamed_rule",
            "description": "",
            "severity": "info",
            "conditions": [],
            "threshold": 1,
            "time_window": 0,
            "group_by": None,
            "logic": "all",
            "mitre_technique": "",
            "mitre_tactic": "",
            "enabled": True,
        }
        merged = {**defaults, **rule}

        # Ensure conditions is a list of dicts
        if not isinstance(merged["conditions"], list):
            merged["conditions"] = [merged["conditions"]]

        return merged


# -----------------------------------------------------------------------
# Module-level helpers
# -----------------------------------------------------------------------

def _to_num(val: Any) -> float:
    """Coerce a value to a float for numeric comparisons."""
    try:
        return float(val)
    except (TypeError, ValueError):
        return 0.0


def _parse_severity(sev_str: str) -> Severity:
    """Convert a string to a Severity enum member."""
    mapping = {
        "critical": Severity.CRITICAL,
        "high": Severity.HIGH,
        "medium": Severity.MEDIUM,
        "low": Severity.LOW,
        "info": Severity.INFO,
    }
    return mapping.get(str(sev_str).lower(), Severity.INFO)
