# 🔍 Digital Forensics Investigation Toolkit

[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)](LICENSE)

Professional digital forensics investigation toolkit performing memory analysis, disk forensics, log timeline reconstruction, registry analysis, and automated evidence reporting. Simulates DFIR workflows used by incident response teams.

## ✨ Features
- **Memory Forensics** — Process analysis, network connections, DLL injection detection
- **Disk Forensics** — File system analysis, deleted file recovery simulation, hash verification
- **Timeline Analysis** — Chronological event reconstruction from multiple evidence sources
- **Registry Forensics** — Persistence mechanisms, user activity, USB history
- **Evidence Management** — Chain of custody, evidence tagging, integrity verification
- **Investigation Reports** — Professional PDF/HTML forensic reports
- **Flask Dashboard** — Web UI for evidence management and analysis

## 🚀 Quick Start
```bash
pip install -r requirements.txt
python app.py
# Visit http://localhost:5004
```
## 📜 License
MIT License — **Koventhan M**
