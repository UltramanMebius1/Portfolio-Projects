"""
Digital Forensics Investigation Toolkit — Complete Flask Application
Memory forensics, disk analysis, timeline reconstruction, registry analysis, evidence reporting.
"""

import os, json, random, hashlib
from datetime import datetime, timedelta
from flask import Flask, render_template_string, request, redirect, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = "dfir-toolkit-secret"
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'dfir.db')}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)


# ── Models ─────────────────────────────────────────────────────────────────

class Case(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(300), nullable=False)
    case_number = db.Column(db.String(20), unique=True)
    description = db.Column(db.Text)
    status = db.Column(db.String(30), default="open")
    severity = db.Column(db.String(20), default="high")
    investigator = db.Column(db.String(100), default="SOC Analyst")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)
    findings = db.Column(db.Text)  # JSON
    evidence = db.relationship("Evidence", backref="case", lazy=True)


class Evidence(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    evidence_type = db.Column(db.String(50))  # memory, disk, log, registry, network
    description = db.Column(db.Text)
    hash_md5 = db.Column(db.String(32))
    hash_sha256 = db.Column(db.String(64))
    source_host = db.Column(db.String(100))
    collected_at = db.Column(db.DateTime, default=datetime.utcnow)
    collected_by = db.Column(db.String(100))
    chain_of_custody = db.Column(db.Text)  # JSON
    analysis_results = db.Column(db.Text)  # JSON
    case_id = db.Column(db.Integer, db.ForeignKey("case.id"))


# ── Forensic Analyzers ────────────────────────────────────────────────────

class MemoryForensics:
    """Simulates Volatility-style memory forensics analysis."""

    @staticmethod
    def analyze(hostname="COMPROMISED-WS01"):
        processes = [
            {"pid": 4, "name": "System", "ppid": 0, "user": "SYSTEM", "suspicious": False},
            {"pid": 612, "name": "smss.exe", "ppid": 4, "user": "SYSTEM", "suspicious": False},
            {"pid": 788, "name": "csrss.exe", "ppid": 612, "user": "SYSTEM", "suspicious": False},
            {"pid": 832, "name": "wininit.exe", "ppid": 612, "user": "SYSTEM", "suspicious": False},
            {"pid": 892, "name": "services.exe", "ppid": 832, "user": "SYSTEM", "suspicious": False},
            {"pid": 904, "name": "lsass.exe", "ppid": 832, "user": "SYSTEM", "suspicious": False},
            {"pid": 1204, "name": "svchost.exe", "ppid": 892, "user": "SYSTEM", "suspicious": False},
            {"pid": 2344, "name": "explorer.exe", "ppid": 2180, "user": "victim_user", "suspicious": False},
            {"pid": 3456, "name": "chrome.exe", "ppid": 2344, "user": "victim_user", "suspicious": False},
            # SUSPICIOUS
            {"pid": 6672, "name": "svchost.exe", "ppid": 2344, "user": "victim_user", "suspicious": True,
             "reason": "svchost.exe spawned by explorer.exe (should be services.exe)"},
            {"pid": 7890, "name": "mimikatz.exe", "ppid": 2344, "user": "victim_user", "suspicious": True,
             "reason": "Known credential dumping tool detected in memory"},
            {"pid": 8123, "name": "powershell.exe", "ppid": 6672, "user": "victim_user", "suspicious": True,
             "reason": "PowerShell spawned by suspicious svchost — possible C2"},
            {"pid": 9001, "name": "cmd.exe", "ppid": 8123, "user": "SYSTEM", "suspicious": True,
             "reason": "cmd.exe running as SYSTEM from PowerShell — privilege escalation"},
        ]

        network_connections = [
            {"pid": 3456, "process": "chrome.exe", "local": "10.0.2.50:52341", "remote": "142.250.80.46:443", "state": "ESTABLISHED", "suspicious": False},
            {"pid": 6672, "process": "svchost.exe", "local": "10.0.2.50:49821", "remote": "185.220.101.34:443", "state": "ESTABLISHED", "suspicious": True,
             "reason": "Connection to known C2 IP address"},
            {"pid": 8123, "process": "powershell.exe", "local": "10.0.2.50:50123", "remote": "91.219.237.8:4444", "state": "ESTABLISHED", "suspicious": True,
             "reason": "Reverse shell connection on non-standard port"},
        ]

        dll_injections = [
            {"pid": 904, "process": "lsass.exe", "dll": "C:\\Temp\\evil.dll", "suspicious": True,
             "reason": "Unknown DLL loaded into LSASS — credential theft indicator"},
            {"pid": 6672, "process": "svchost.exe", "dll": "C:\\Users\\Public\\beacon.dll", "suspicious": True,
             "reason": "Cobalt Strike beacon DLL detected"},
        ]

        return {
            "hostname": hostname,
            "analysis_type": "Memory Forensics",
            "processes": processes,
            "network_connections": network_connections,
            "dll_injections": dll_injections,
            "suspicious_count": sum(1 for p in processes if p.get("suspicious")),
            "malicious_connections": sum(1 for n in network_connections if n.get("suspicious")),
        }


class DiskForensics:
    """Simulates disk forensics analysis."""

    @staticmethod
    def analyze():
        suspicious_files = [
            {"path": "C:\\Users\\victim_user\\AppData\\Local\\Temp\\mimikatz.exe", "size": 1309696,
             "md5": "e3b0c44298fc1c149afbf4c8996fb924", "created": "2024-03-15 14:23:01",
             "modified": "2024-03-15 14:23:01", "accessed": "2024-03-15 14:25:33",
             "verdict": "malicious", "description": "Mimikatz credential dumping tool"},
            {"path": "C:\\Users\\Public\\beacon.dll", "size": 307200,
             "md5": "a1b2c3d4e5f6789012345678abcdef01", "created": "2024-03-15 14:20:00",
             "modified": "2024-03-15 14:20:00", "accessed": "2024-03-15 14:25:00",
             "verdict": "malicious", "description": "Cobalt Strike beacon payload"},
            {"path": "C:\\Temp\\evil.dll", "size": 204800,
             "md5": "deadbeef12345678abcdef0123456789", "created": "2024-03-15 14:18:00",
             "modified": "2024-03-15 14:18:00", "accessed": "2024-03-15 14:23:00",
             "verdict": "malicious", "description": "Injected DLL for LSASS credential theft"},
            {"path": "C:\\Users\\victim_user\\Downloads\\invoice_march.exe", "size": 512000,
             "md5": "cafebabe98765432abcdef0123456789", "created": "2024-03-15 14:10:00",
             "modified": "2024-03-15 14:10:00", "accessed": "2024-03-15 14:15:00",
             "verdict": "malicious", "description": "Initial access — disguised as invoice PDF"},
        ]

        deleted_files = [
            {"path": "C:\\Users\\victim_user\\AppData\\Local\\Temp\\pwdump.exe",
             "description": "Deleted credential harvesting tool — recovered from MFT"},
            {"path": "C:\\Users\\victim_user\\Desktop\\credentials.txt",
             "description": "Deleted file containing harvested credentials"},
            {"path": "C:\\Windows\\Temp\\cleanup.bat",
             "description": "Deleted batch script used for evidence destruction"},
        ]

        return {
            "analysis_type": "Disk Forensics",
            "suspicious_files": suspicious_files,
            "deleted_files": deleted_files,
            "total_suspicious": len(suspicious_files),
            "total_recovered": len(deleted_files),
        }


class RegistryForensics:
    """Simulates Windows registry forensic analysis."""

    @staticmethod
    def analyze():
        persistence = [
            {"key": r"HKCU\Software\Microsoft\Windows\CurrentVersion\Run\SystemUpdate",
             "value": r"C:\Users\Public\beacon.dll",
             "suspicious": True, "description": "Malicious persistence — Cobalt Strike beacon"},
            {"key": r"HKLM\Software\Microsoft\Windows\CurrentVersion\Run\WindowsSecurity",
             "value": r"C:\Temp\evil.dll",
             "suspicious": True, "description": "Malicious DLL persistence"},
            {"key": r"HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU",
             "value": "cmd /c whoami",
             "suspicious": True, "description": "Suspicious Run dialog command history"},
        ]

        usb_history = [
            {"device": "USB Mass Storage - Kingston DT 101", "serial": "AA00000012345",
             "first_connected": "2024-03-14 09:15:00", "last_connected": "2024-03-15 14:05:00",
             "suspicious": True, "description": "USB device connected shortly before attack — possible initial access"},
        ]

        user_activity = [
            {"timestamp": "2024-03-15 14:10:00", "activity": "Downloaded invoice_march.exe from browser"},
            {"timestamp": "2024-03-15 14:15:00", "activity": "Executed invoice_march.exe — initial compromise"},
            {"timestamp": "2024-03-15 14:18:00", "activity": "evil.dll dropped to C:\\Temp"},
            {"timestamp": "2024-03-15 14:20:00", "activity": "beacon.dll dropped to C:\\Users\\Public"},
            {"timestamp": "2024-03-15 14:23:00", "activity": "mimikatz.exe executed — credential dumping"},
            {"timestamp": "2024-03-15 14:25:00", "activity": "C2 connection established to 185.220.101.34"},
            {"timestamp": "2024-03-15 14:30:00", "activity": "Lateral movement attempt to DC01"},
        ]

        return {
            "analysis_type": "Registry Forensics",
            "persistence_mechanisms": persistence,
            "usb_history": usb_history,
            "user_activity_timeline": user_activity,
        }


class TimelineAnalyzer:
    """Builds comprehensive investigation timeline from all evidence sources."""

    @staticmethod
    def build_timeline(memory_data, disk_data, registry_data):
        events = []

        # Registry user activity
        for ua in registry_data.get("user_activity_timeline", []):
            events.append({
                "timestamp": ua["timestamp"],
                "source": "Registry",
                "event": ua["activity"],
                "severity": "high",
            })

        # Disk file creation
        for f in disk_data.get("suspicious_files", []):
            events.append({
                "timestamp": f["created"],
                "source": "Disk",
                "event": f"File created: {f['path']} — {f['description']}",
                "severity": "critical",
            })

        # Memory suspicious processes
        for p in memory_data.get("processes", []):
            if p.get("suspicious"):
                events.append({
                    "timestamp": "2024-03-15 14:20:00",
                    "source": "Memory",
                    "event": f"Suspicious process: {p['name']} (PID {p['pid']}) — {p.get('reason', '')}",
                    "severity": "critical",
                })

        # Network connections
        for n in memory_data.get("network_connections", []):
            if n.get("suspicious"):
                events.append({
                    "timestamp": "2024-03-15 14:25:00",
                    "source": "Network",
                    "event": f"Suspicious connection: {n['process']} → {n['remote']} — {n.get('reason', '')}",
                    "severity": "critical",
                })

        events.sort(key=lambda x: x["timestamp"])
        return events


# ── Routes ─────────────────────────────────────────────────────────────────

TMPL = """
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Digital Forensics Investigation</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#080c18;--bg2:#0e1526;--card:#141e38;--text:#dde4ef;--dim:#6e7d95;--blue:#4a8ef7;--purple:#9266f5;--red:#ef4444;--orange:#f59e0b;--green:#22c55e;--border:#1e2d4a;--cyan:#06b6d4}
body{font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:var(--text)}
.header{background:linear-gradient(135deg,#141e38,#0b1020);border-bottom:1px solid var(--border);padding:16px 32px;display:flex;align-items:center;justify-content:space-between}
.header h1{font-size:1.4rem;background:linear-gradient(135deg,#06b6d4,#9266f5);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav{background:var(--bg2);border-bottom:1px solid var(--border);display:flex;padding:0 32px}
.nav a{color:var(--dim);text-decoration:none;padding:12px 18px;font-size:.85rem;font-weight:500;border-bottom:2px solid transparent;transition:.2s}
.nav a:hover,.nav a.active{color:var(--cyan);border-bottom-color:var(--cyan)}
.container{max-width:1400px;margin:0 auto;padding:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:24px}
.stat{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:20px}
.stat .label{font-size:.7rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}
.stat .val{font-size:1.8rem;font-weight:700}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:24px}
.card h2{font-size:1.1rem;margin-bottom:16px}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:10px;font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:var(--dim);border-bottom:1px solid var(--border)}
td{padding:10px;border-bottom:1px solid var(--border);font-size:.85rem}
tr:hover{background:rgba(6,182,212,.04)}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:600;text-transform:uppercase}
.badge.critical,.badge.malicious{background:rgba(239,68,68,.12);color:var(--red);border:1px solid rgba(239,68,68,.25)}
.badge.high{background:rgba(245,158,11,.12);color:var(--orange);border:1px solid rgba(245,158,11,.25)}
.badge.medium{background:rgba(6,182,212,.12);color:var(--cyan);border:1px solid rgba(6,182,212,.25)}
.badge.low{background:rgba(34,197,94,.12);color:var(--green);border:1px solid rgba(34,197,94,.25)}
.btn{padding:8px 16px;border-radius:8px;border:none;cursor:pointer;font-size:.85rem;font-weight:500;transition:.2s;text-decoration:none;display:inline-block;margin:2px}
.btn-cyan{background:var(--cyan);color:#fff}.btn-red{background:var(--red);color:#fff}
.btn-blue{background:var(--blue);color:#fff}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px}@media(max-width:768px){.two-col{grid-template-columns:1fr}}
.timeline-item{display:flex;gap:16px;padding:12px 0;border-left:3px solid var(--border);padding-left:20px;position:relative}
.timeline-item::before{content:'';width:10px;height:10px;border-radius:50%;position:absolute;left:-7px;top:16px}
.timeline-item.critical::before{background:var(--red)}.timeline-item.high::before{background:var(--orange)}
.timeline-item .ts{font-size:.75rem;color:var(--dim);min-width:140px}
.timeline-item .ev{flex:1}.timeline-item .ev .src{font-size:.7rem;color:var(--cyan)}
.flash{padding:12px;border-radius:8px;margin-bottom:16px;background:rgba(6,182,212,.12);border:1px solid rgba(6,182,212,.3);color:var(--cyan);font-size:.85rem}
.susp{background:rgba(239,68,68,.05);border-left:3px solid var(--red);padding:8px 12px;margin:4px 0;border-radius:4px;font-size:.85rem}
</style></head><body>
<div class="header"><h1>🔍 Digital Forensics Investigation Toolkit</h1></div>
<div class="nav">
    <a href="/" class="{{ 'active' if page=='dash' }}">Dashboard</a>
    <a href="/memory" class="{{ 'active' if page=='memory' }}">Memory</a>
    <a href="/disk" class="{{ 'active' if page=='disk' }}">Disk</a>
    <a href="/registry" class="{{ 'active' if page=='registry' }}">Registry</a>
    <a href="/timeline" class="{{ 'active' if page=='timeline' }}">Timeline</a>
</div>
<div class="container">{% if flash %}<div class="flash">{{ flash }}</div>{% endif %}{% block c %}{% endblock %}</div>
</body></html>
"""

# Store analysis results
analysis_cache = {}

def run_analysis():
    if not analysis_cache:
        analysis_cache["memory"] = MemoryForensics.analyze()
        analysis_cache["disk"] = DiskForensics.analyze()
        analysis_cache["registry"] = RegistryForensics.analyze()
        analysis_cache["timeline"] = TimelineAnalyzer.build_timeline(
            analysis_cache["memory"], analysis_cache["disk"], analysis_cache["registry"]
        )

@app.route("/")
def dashboard():
    run_analysis()
    m, d, r = analysis_cache["memory"], analysis_cache["disk"], analysis_cache["registry"]
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="grid">
    <div class="stat"><div class="label">Suspicious Processes</div><div class="val" style="color:var(--red)">{{ m.suspicious_count }}</div></div>
    <div class="stat"><div class="label">Malicious Files</div><div class="val" style="color:var(--red)">{{ d.total_suspicious }}</div></div>
    <div class="stat"><div class="label">C2 Connections</div><div class="val" style="color:var(--orange)">{{ m.malicious_connections }}</div></div>
    <div class="stat"><div class="label">Recovered Files</div><div class="val" style="color:var(--cyan)">{{ d.total_recovered }}</div></div>
    <div class="stat"><div class="label">Persistence Keys</div><div class="val" style="color:var(--purple)">{{ r.persistence_mechanisms|length }}</div></div>
    <div class="stat"><div class="label">Timeline Events</div><div class="val" style="color:var(--blue)">{{ tl|length }}</div></div>
</div>
<div class="card">
    <h2>⚡ Quick Links</h2>
    <a href="/memory" class="btn btn-cyan">🧠 Memory Analysis</a>
    <a href="/disk" class="btn btn-blue">💾 Disk Forensics</a>
    <a href="/registry" class="btn btn-blue">🗂️ Registry</a>
    <a href="/timeline" class="btn btn-red">📐 Full Timeline</a>
</div>
<div class="card">
    <h2>📐 Investigation Summary</h2>
    <p style="color:var(--dim);line-height:1.8">
    <strong>Case:</strong> Compromised Workstation — Initial Access via Phishing<br>
    <strong>Host:</strong> {{ m.hostname }}<br>
    <strong>Analyst:</strong> SOC Analyst (Koventhan M)<br>
    <strong>Status:</strong> <span class="badge critical">Active Investigation</span><br><br>
    <strong>Summary:</strong> Victim received a phishing email with a malicious executable disguised as an invoice.
    Upon execution, the malware dropped a Cobalt Strike beacon, established C2 communication,
    dumped credentials using mimikatz, and attempted lateral movement to the Domain Controller.
    Multiple persistence mechanisms were installed via registry run keys.
    </p>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="dash", flash=request.args.get("msg"),
                                    m=m, d=d, r=r, tl=analysis_cache["timeline"])


@app.route("/memory")
def memory_page():
    run_analysis()
    m = analysis_cache["memory"]
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>🧠 Process List ({{ m.processes|length }})</h2>
    <table><thead><tr><th>PID</th><th>Name</th><th>PPID</th><th>User</th><th>Suspicious</th><th>Reason</th></tr></thead><tbody>
    {% for p in m.processes %}
    <tr style="{{ 'background:rgba(239,68,68,.05)' if p.suspicious else '' }}">
        <td>{{ p.pid }}</td><td style="{{ 'color:var(--red);font-weight:600' if p.suspicious else '' }}">{{ p.name }}</td>
        <td>{{ p.ppid }}</td><td>{{ p.user }}</td>
        <td>{{ '🔴' if p.suspicious else '🟢' }}</td>
        <td style="font-size:.8rem">{{ p.get('reason','') }}</td>
    </tr>{% endfor %}</tbody></table>
</div>
<div class="two-col">
    <div class="card">
        <h2>🌐 Network Connections</h2>
        <table><thead><tr><th>PID</th><th>Process</th><th>Remote</th><th>State</th><th>Suspicious</th></tr></thead><tbody>
        {% for n in m.network_connections %}
        <tr style="{{ 'background:rgba(239,68,68,.05)' if n.suspicious else '' }}">
            <td>{{ n.pid }}</td><td>{{ n.process }}</td>
            <td style="font-family:monospace;font-size:.8rem">{{ n.remote }}</td>
            <td>{{ n.state }}</td><td>{{ '🔴 ' + n.get('reason','') if n.suspicious else '🟢' }}</td>
        </tr>{% endfor %}</tbody></table>
    </div>
    <div class="card">
        <h2>💉 DLL Injections</h2>
        {% for d in m.dll_injections %}
        <div class="susp">
            <strong>PID {{ d.pid }} ({{ d.process }})</strong> — {{ d.dll }}<br>
            <span style="font-size:.8rem;color:var(--red)">{{ d.reason }}</span>
        </div>{% endfor %}
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="memory", flash=None, m=m)


@app.route("/disk")
def disk_page():
    run_analysis()
    d = analysis_cache["disk"]
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>💾 Suspicious Files ({{ d.suspicious_files|length }})</h2>
    <table><thead><tr><th>Path</th><th>Size</th><th>MD5</th><th>Created</th><th>Verdict</th><th>Description</th></tr></thead><tbody>
    {% for f in d.suspicious_files %}
    <tr>
        <td style="font-family:monospace;font-size:.75rem">{{ f.path }}</td>
        <td>{{ "%.1f"|format(f.size/1024) }} KB</td>
        <td style="font-family:monospace;font-size:.7rem">{{ f.md5[:16] }}...</td>
        <td style="font-size:.75rem">{{ f.created }}</td>
        <td><span class="badge {{ f.verdict }}">{{ f.verdict }}</span></td>
        <td style="font-size:.8rem">{{ f.description }}</td>
    </tr>{% endfor %}</tbody></table>
</div>
<div class="card">
    <h2>🗑️ Recovered Deleted Files ({{ d.deleted_files|length }})</h2>
    {% for f in d.deleted_files %}
    <div class="susp">
        <strong>{{ f.path }}</strong><br>
        <span style="font-size:.8rem;color:var(--dim)">{{ f.description }}</span>
    </div>{% endfor %}
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="disk", flash=None, d=d)


@app.route("/registry")
def registry_page():
    run_analysis()
    r = analysis_cache["registry"]
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>🔑 Persistence Mechanisms</h2>
    <table><thead><tr><th>Registry Key</th><th>Value</th><th>Description</th></tr></thead><tbody>
    {% for p in r.persistence_mechanisms %}
    <tr style="background:rgba(239,68,68,.05)">
        <td style="font-family:monospace;font-size:.75rem">{{ p.key }}</td>
        <td style="font-family:monospace;font-size:.75rem;color:var(--red)">{{ p.value }}</td>
        <td style="font-size:.8rem">{{ p.description }}</td>
    </tr>{% endfor %}</tbody></table>
</div>
<div class="two-col">
    <div class="card">
        <h2>🔌 USB History</h2>
        {% for u in r.usb_history %}
        <div class="susp">
            <strong>{{ u.device }}</strong> (S/N: {{ u.serial }})<br>
            <span style="font-size:.8rem">First: {{ u.first_connected }} | Last: {{ u.last_connected }}</span><br>
            <span style="font-size:.8rem;color:var(--red)">{{ u.description }}</span>
        </div>{% endfor %}
    </div>
    <div class="card">
        <h2>👤 User Activity</h2>
        {% for a in r.user_activity_timeline %}
        <div style="padding:6px 0;border-bottom:1px solid var(--border)">
            <span style="font-size:.75rem;color:var(--dim)">{{ a.timestamp }}</span>
            <span style="font-size:.85rem;margin-left:8px">{{ a.activity }}</span>
        </div>{% endfor %}
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="registry", flash=None, r=r)


@app.route("/timeline")
def timeline_page():
    run_analysis()
    tl = analysis_cache["timeline"]
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>📐 Complete Investigation Timeline ({{ tl|length }} events)</h2>
    {% for e in tl %}
    <div class="timeline-item {{ e.severity }}">
        <div class="ts">{{ e.timestamp }}</div>
        <div class="ev">
            <div class="src">{{ e.source }}</div>
            <div>{{ e.event }}</div>
            <span class="badge {{ e.severity }}">{{ e.severity }}</span>
        </div>
    </div>{% endfor %}
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="timeline", flash=None, tl=tl)


@app.route("/api/timeline")
def api_timeline():
    run_analysis()
    return jsonify(analysis_cache["timeline"])


with app.app_context():
    db.create_all()

if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("  🔍 Digital Forensics Investigation Toolkit")
    print("  Starting on http://localhost:5004")
    print("=" * 60 + "\n")
    app.run(debug=True, port=5004)
