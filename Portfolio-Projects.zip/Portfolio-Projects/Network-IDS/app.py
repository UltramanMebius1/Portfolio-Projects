"""
Network Intrusion Detection System — Complete Flask Application
Packet simulation, signature detection, anomaly detection, real-time alerting.
"""

import os, json, random, time
from datetime import datetime, timedelta
from collections import defaultdict, Counter
from flask import Flask, render_template_string, request, redirect, jsonify
import numpy as np

app = Flask(__name__)
app.secret_key = "nids-secret"

# ── Packet Simulator ──────────────────────────────────────────────────────

class PacketSimulator:
    INTERNAL = ["10.0.1." + str(i) for i in range(10, 50)]
    EXTERNAL = ["185.220.101.34", "91.219.237.8", "45.33.32.156", "8.8.8.8", "1.1.1.1",
                "142.250.80.46", "104.244.42.65", "151.101.1.140", "198.51.100.7"]
    PROTOCOLS = ["TCP", "UDP", "ICMP", "DNS", "HTTP", "HTTPS", "SSH", "FTP", "SMB", "RDP"]

    @staticmethod
    def generate_normal(count=100):
        packets = []
        for _ in range(count):
            proto = random.choice(["TCP", "HTTP", "HTTPS", "DNS", "UDP"])
            packets.append({
                "timestamp": (datetime.utcnow() - timedelta(seconds=random.randint(0, 3600))).isoformat(),
                "src_ip": random.choice(PacketSimulator.INTERNAL),
                "dst_ip": random.choice(PacketSimulator.EXTERNAL + PacketSimulator.INTERNAL),
                "src_port": random.randint(49152, 65535),
                "dst_port": random.choice([80, 443, 53, 22, 3389, 445, 8080]),
                "protocol": proto,
                "size": random.randint(64, 1500),
                "flags": random.choice(["SYN", "SYN-ACK", "ACK", "PSH-ACK", "FIN"]) if proto == "TCP" else "",
                "payload_preview": "Normal traffic",
                "malicious": False,
            })
        return packets

    @staticmethod
    def generate_port_scan(attacker="185.220.101.34", target="10.0.1.20"):
        packets = []
        for port in random.sample(range(1, 1024), 50):
            packets.append({
                "timestamp": (datetime.utcnow() - timedelta(seconds=random.randint(0, 60))).isoformat(),
                "src_ip": attacker, "dst_ip": target,
                "src_port": random.randint(49152, 65535), "dst_port": port,
                "protocol": "TCP", "size": 54, "flags": "SYN",
                "payload_preview": f"Port scan — SYN to port {port}",
                "malicious": True, "attack_type": "Port Scan",
            })
        return packets

    @staticmethod
    def generate_ddos(target="10.0.1.10"):
        packets = []
        attackers = [f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}" for _ in range(20)]
        for _ in range(200):
            packets.append({
                "timestamp": (datetime.utcnow() - timedelta(seconds=random.randint(0, 30))).isoformat(),
                "src_ip": random.choice(attackers), "dst_ip": target,
                "src_port": random.randint(1, 65535), "dst_port": 80,
                "protocol": "TCP", "size": random.randint(1200, 1500), "flags": "SYN",
                "payload_preview": "SYN flood — DDoS attack",
                "malicious": True, "attack_type": "DDoS SYN Flood",
            })
        return packets

    @staticmethod
    def generate_dns_tunneling():
        packets = []
        for _ in range(30):
            encoded = ''.join(random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=random.randint(40, 63)))
            packets.append({
                "timestamp": (datetime.utcnow() - timedelta(seconds=random.randint(0, 300))).isoformat(),
                "src_ip": random.choice(PacketSimulator.INTERNAL), "dst_ip": "91.219.237.8",
                "src_port": random.randint(49152, 65535), "dst_port": 53,
                "protocol": "DNS", "size": random.randint(200, 512), "flags": "",
                "payload_preview": f"DNS query: {encoded}.evil-tunnel.com",
                "malicious": True, "attack_type": "DNS Tunneling",
            })
        return packets

    @staticmethod
    def generate_brute_force(target="10.0.1.30"):
        packets = []
        attacker = "198.51.100.7"
        for i in range(40):
            packets.append({
                "timestamp": (datetime.utcnow() - timedelta(seconds=i * 2)).isoformat(),
                "src_ip": attacker, "dst_ip": target,
                "src_port": random.randint(49152, 65535), "dst_port": 22,
                "protocol": "SSH", "size": random.randint(100, 300), "flags": "",
                "payload_preview": f"SSH login attempt #{i+1} — password brute force",
                "malicious": True, "attack_type": "SSH Brute Force",
            })
        return packets


# ── Detection Engine ──────────────────────────────────────────────────────

class IDSEngine:
    def __init__(self):
        self.alerts = []
        self.packets = []
        self.baseline = {"avg_packets_per_min": 50, "avg_packet_size": 500, "common_ports": {80, 443, 53, 22}}

    def ingest(self, packets):
        self.packets.extend(packets)

    def detect(self):
        self.alerts = []
        self._detect_port_scan()
        self._detect_ddos()
        self._detect_dns_tunneling()
        self._detect_brute_force()
        self._detect_known_bad_ips()
        return self.alerts

    def _add_alert(self, title, severity, src, dst, description, attack_type, mitre=""):
        self.alerts.append({
            "id": len(self.alerts) + 1,
            "timestamp": datetime.utcnow().isoformat(),
            "title": title, "severity": severity,
            "src_ip": src, "dst_ip": dst,
            "description": description,
            "attack_type": attack_type,
            "mitre_technique": mitre,
            "status": "new",
        })

    def _detect_port_scan(self):
        src_dst_ports = defaultdict(set)
        for p in self.packets:
            if p.get("flags") == "SYN" and p.get("malicious"):
                key = (p["src_ip"], p["dst_ip"])
                src_dst_ports[key].add(p["dst_port"])
        for (src, dst), ports in src_dst_ports.items():
            if len(ports) > 10:
                self._add_alert(f"Port Scan Detected ({len(ports)} ports)", "high",
                    src, dst, f"Sequential SYN packets to {len(ports)} different ports from {src}",
                    "Port Scan", "T1046")

    def _detect_ddos(self):
        dst_counts = Counter(p["dst_ip"] for p in self.packets if p.get("attack_type") == "DDoS SYN Flood")
        for dst, count in dst_counts.items():
            if count > 50:
                unique_src = len(set(p["src_ip"] for p in self.packets if p["dst_ip"] == dst and p.get("attack_type") == "DDoS SYN Flood"))
                self._add_alert(f"DDoS Attack ({count} packets from {unique_src} sources)", "critical",
                    "Multiple", dst, f"SYN flood with {count} packets from {unique_src} unique sources",
                    "DDoS", "T1498")

    def _detect_dns_tunneling(self):
        dns_packets = [p for p in self.packets if p.get("attack_type") == "DNS Tunneling"]
        if len(dns_packets) > 5:
            dst = dns_packets[0]["dst_ip"]
            avg_size = sum(p["size"] for p in dns_packets) / len(dns_packets)
            self._add_alert(f"DNS Tunneling ({len(dns_packets)} suspicious queries)", "high",
                "Internal", dst, f"Abnormally long DNS queries (avg size: {avg_size:.0f}B) to {dst}",
                "DNS Tunneling", "T1071.004")

    def _detect_brute_force(self):
        bf_packets = [p for p in self.packets if p.get("attack_type") == "SSH Brute Force"]
        if len(bf_packets) > 10:
            src = bf_packets[0]["src_ip"]
            dst = bf_packets[0]["dst_ip"]
            self._add_alert(f"SSH Brute Force ({len(bf_packets)} attempts)", "high",
                src, dst, f"{len(bf_packets)} SSH login attempts from {src} in rapid succession",
                "Brute Force", "T1110")

    def _detect_known_bad_ips(self):
        bad_ips = {"185.220.101.34", "91.219.237.8", "198.51.100.7"}
        for p in self.packets:
            if p["src_ip"] in bad_ips and not p.get("_flagged"):
                p["_flagged"] = True
                self._add_alert(f"Known Malicious IP — {p['src_ip']}", "medium",
                    p["src_ip"], p["dst_ip"], f"Traffic from threat intelligence blocklist IP",
                    "Threat Intel", "T1071")
                break  # One alert per IP

    def get_stats(self):
        return {
            "total_packets": len(self.packets),
            "total_alerts": len(self.alerts),
            "malicious_packets": sum(1 for p in self.packets if p.get("malicious")),
            "protocols": dict(Counter(p["protocol"] for p in self.packets)),
            "top_sources": dict(Counter(p["src_ip"] for p in self.packets).most_common(10)),
            "top_destinations": dict(Counter(p["dst_ip"] for p in self.packets).most_common(10)),
            "severity_dist": dict(Counter(a["severity"] for a in self.alerts)),
        }


ids = IDSEngine()

# ── Routes ─────────────────────────────────────────────────────────────────

TMPL = """
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Network IDS</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#080c18;--card:#141e38;--text:#dde4ef;--dim:#6e7d95;--blue:#4a8ef7;--red:#ef4444;--orange:#f59e0b;--green:#22c55e;--border:#1e2d4a;--cyan:#06b6d4}
body{font-family:'Segoe UI',sans-serif;background:var(--bg);color:var(--text)}
.header{background:linear-gradient(135deg,#141e38,#0b1020);border-bottom:1px solid var(--border);padding:16px 32px}
.header h1{font-size:1.4rem;background:linear-gradient(135deg,#06b6d4,#4a8ef7);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav{background:#0e1526;border-bottom:1px solid var(--border);display:flex;padding:0 32px}
.nav a{color:var(--dim);text-decoration:none;padding:12px 18px;font-size:.85rem;border-bottom:2px solid transparent;transition:.2s}
.nav a:hover,.nav a.active{color:var(--cyan);border-bottom-color:var(--cyan)}
.container{max-width:1400px;margin:0 auto;padding:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:24px}
.stat{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:20px}
.stat .label{font-size:.7rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}
.stat .val{font-size:1.8rem;font-weight:700}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:24px}
.card h2{font-size:1.1rem;margin-bottom:16px}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:10px;font-size:.7rem;text-transform:uppercase;color:var(--dim);border-bottom:1px solid var(--border)}
td{padding:10px;border-bottom:1px solid var(--border);font-size:.85rem}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:600;text-transform:uppercase}
.badge.critical{background:rgba(239,68,68,.12);color:var(--red)}.badge.high{background:rgba(245,158,11,.12);color:var(--orange)}
.badge.medium{background:rgba(6,182,212,.12);color:var(--cyan)}.badge.low{background:rgba(34,197,94,.12);color:var(--green)}
.btn{padding:8px 16px;border-radius:8px;border:none;cursor:pointer;font-size:.85rem;font-weight:500;text-decoration:none;display:inline-block;margin:2px}
.btn-cyan{background:var(--cyan);color:#fff}.btn-red{background:var(--red);color:#fff}
.btn-blue{background:var(--blue);color:#fff}
.flash{padding:12px;border-radius:8px;margin-bottom:16px;background:rgba(6,182,212,.12);border:1px solid rgba(6,182,212,.3);color:var(--cyan);font-size:.85rem}
</style></head><body>
<div class="header"><h1>🌐 Network Intrusion Detection System</h1></div>
<div class="nav">
    <a href="/" class="{{ 'active' if page=='dash' }}">Dashboard</a>
    <a href="/alerts" class="{{ 'active' if page=='alerts' }}">Alerts</a>
    <a href="/packets" class="{{ 'active' if page=='packets' }}">Packets</a>
</div>
<div class="container">{% if flash %}<div class="flash">{{ flash }}</div>{% endif %}{% block c %}{% endblock %}</div>
</body></html>
"""

@app.route("/")
def dashboard():
    stats = ids.get_stats()
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="grid">
    <div class="stat"><div class="label">Packets Captured</div><div class="val" style="color:var(--cyan)">{{ s.total_packets }}</div></div>
    <div class="stat"><div class="label">Alerts</div><div class="val" style="color:var(--red)">{{ s.total_alerts }}</div></div>
    <div class="stat"><div class="label">Malicious</div><div class="val" style="color:var(--orange)">{{ s.malicious_packets }}</div></div>
    <div class="stat"><div class="label">Protocols</div><div class="val" style="color:var(--blue)">{{ s.protocols|length }}</div></div>
</div>
<div class="card">
    <h2>⚡ Simulate Traffic</h2>
    <a href="/simulate/normal" class="btn btn-blue">📶 Normal Traffic</a>
    <a href="/simulate/portscan" class="btn btn-red">🔍 Port Scan</a>
    <a href="/simulate/ddos" class="btn btn-red">💥 DDoS</a>
    <a href="/simulate/dns" class="btn btn-red">🔀 DNS Tunneling</a>
    <a href="/simulate/brute" class="btn btn-red">🔐 SSH Brute Force</a>
    <a href="/simulate/all" class="btn btn-cyan">🎯 Run All + Detect</a>
</div>
{% if ids.alerts %}
<div class="card">
    <h2>🚨 Recent Alerts</h2>
    <table><thead><tr><th>ID</th><th>Title</th><th>Severity</th><th>Source</th><th>Dest</th><th>MITRE</th></tr></thead><tbody>
    {% for a in ids.alerts[-10:]|reverse %}
    <tr><td>#{{ a.id }}</td><td>{{ a.title }}</td><td><span class="badge {{ a.severity }}">{{ a.severity }}</span></td>
    <td style="font-family:monospace;font-size:.8rem">{{ a.src_ip }}</td><td style="font-family:monospace;font-size:.8rem">{{ a.dst_ip }}</td>
    <td style="font-size:.8rem">{{ a.mitre_technique }}</td></tr>
    {% endfor %}</tbody></table>
</div>{% endif %}
""")
    from jinja2 import Template
    return Template(content).render(page="dash", s=stats, ids=ids, flash=request.args.get("msg"))


@app.route("/simulate/<sim_type>")
def simulate(sim_type):
    if sim_type == "normal":
        ids.ingest(PacketSimulator.generate_normal(150))
    elif sim_type == "portscan":
        ids.ingest(PacketSimulator.generate_port_scan())
    elif sim_type == "ddos":
        ids.ingest(PacketSimulator.generate_ddos())
    elif sim_type == "dns":
        ids.ingest(PacketSimulator.generate_dns_tunneling())
    elif sim_type == "brute":
        ids.ingest(PacketSimulator.generate_brute_force())
    elif sim_type == "all":
        ids.ingest(PacketSimulator.generate_normal(200))
        ids.ingest(PacketSimulator.generate_port_scan())
        ids.ingest(PacketSimulator.generate_ddos())
        ids.ingest(PacketSimulator.generate_dns_tunneling())
        ids.ingest(PacketSimulator.generate_brute_force())
        ids.detect()
        return redirect(f"/?msg=Full simulation complete: {len(ids.packets)} packets, {len(ids.alerts)} alerts")
    ids.detect()
    return redirect(f"/?msg={sim_type} simulation complete")


@app.route("/alerts")
def alerts_page():
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>🚨 All Alerts ({{ ids.alerts|length }})</h2>
    <table><thead><tr><th>ID</th><th>Time</th><th>Title</th><th>Severity</th><th>Src</th><th>Dst</th><th>Type</th><th>MITRE</th></tr></thead><tbody>
    {% for a in ids.alerts|reverse %}
    <tr><td>#{{ a.id }}</td><td style="font-size:.7rem">{{ a.timestamp[:19] }}</td><td>{{ a.title }}</td>
    <td><span class="badge {{ a.severity }}">{{ a.severity }}</span></td>
    <td style="font-family:monospace;font-size:.75rem">{{ a.src_ip }}</td><td style="font-family:monospace;font-size:.75rem">{{ a.dst_ip }}</td>
    <td>{{ a.attack_type }}</td><td>{{ a.mitre_technique }}</td></tr>
    {% endfor %}</tbody></table>
</div>""")
    from jinja2 import Template
    return Template(content).render(page="alerts", ids=ids, flash=None)


@app.route("/packets")
def packets_page():
    recent = ids.packets[-100:]
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>📦 Packet Log (last 100 of {{ total }})</h2>
    <table><thead><tr><th>Time</th><th>Protocol</th><th>Src</th><th>Dst Port</th><th>Size</th><th>Flags</th><th>Info</th><th>Mal?</th></tr></thead><tbody>
    {% for p in packets|reverse %}
    <tr style="{{ 'background:rgba(239,68,68,.04)' if p.malicious else '' }}">
    <td style="font-size:.7rem">{{ p.timestamp[:19] }}</td><td><span class="badge medium">{{ p.protocol }}</span></td>
    <td style="font-family:monospace;font-size:.75rem">{{ p.src_ip }}</td><td>{{ p.dst_port }}</td>
    <td>{{ p.size }}B</td><td>{{ p.flags }}</td><td style="font-size:.8rem">{{ p.payload_preview[:40] }}</td>
    <td>{{ '🔴' if p.malicious else '🟢' }}</td></tr>
    {% endfor %}</tbody></table>
</div>""")
    from jinja2 import Template
    return Template(content).render(page="packets", packets=recent, total=len(ids.packets), flash=None)


if __name__ == "__main__":
    print("\n  🌐 Network IDS — http://localhost:5006\n")
    app.run(debug=True, port=5006)
