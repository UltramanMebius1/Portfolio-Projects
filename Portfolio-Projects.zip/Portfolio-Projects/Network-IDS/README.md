# 🌐 Network Intrusion Detection System

[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)](LICENSE)

Python-based Network IDS with packet capture simulation, ML-based anomaly detection, protocol analysis, and real-time alerting dashboard. Uses signature and anomaly-based detection.

## ✨ Features
- Packet capture simulation with TCP/UDP/ICMP/DNS/HTTP protocols
- Signature-based detection for known attack patterns
- Statistical anomaly detection for traffic baselines
- Port scan, DDoS, DNS tunneling, brute force detection
- Real-time alert dashboard with severity classification
- PCAP-style packet logging

## 🚀 Quick Start
```bash
pip install -r requirements.txt
python app.py  # http://localhost:5006
```
## 📜 License — MIT — **Koventhan M**
