"""
AI Chatbot for University — Complete Flask Application
Retrieval-Augmented Generation (RAG) simulation, document index querying, and chat interface.
"""

import os
import re
from datetime import datetime
from flask import Flask, render_template_string, request, jsonify

app = Flask(__name__)
app.secret_key = "uni-chatbot-secret"

# ── Knowledge Base (Simulating Indexed Documents) ──────────────────────────

KNOWLEDGE_BASE = [
    {
        "id": "DOC-001",
        "title": "Admission Requirements & Eligibility",
        "content": "To apply for undergraduate engineering programs, candidates must have completed High School (10+2) with Physics, Chemistry, and Mathematics as core subjects, scoring a minimum aggregate of 60%. Applications are accepted online via the admissions portal from March 1st to July 31st each year. Entrance exams (UCEE) are conducted in early June.",
        "tags": ["admission", "eligibility", "dates", "engineering", "undergraduate"]
    },
    {
        "id": "DOC-002",
        "title": "Academic Grading System & GPA",
        "content": "The university operates on a 10-point cumulative grade point average (CGPA) system. Grades are awarded from O (Outstanding, 10 points) down to F (Fail, 0 points). To maintain good academic standing and avoid probation, undergraduate students must maintain a minimum CGPA of 5.0.",
        "tags": ["academics", "grading", "cgpa", "gpa", "probation"]
    },
    {
        "id": "DOC-003",
        "title": "Hostel Accommodation Rules & Fees",
        "content": "On-campus housing is available for all registered students. Hostel fees are $1,200 per semester for double occupancy and $1,800 for single occupancy. Rent includes 24/7 internet access, laundry facilities, and water. A meal plan is mandatory for freshman students, priced at $800 per semester. Curfew is enforced at 10:30 PM daily.",
        "tags": ["hostel", "accommodation", "fees", "curfew", "food", "housing"]
    },
    {
        "id": "DOC-004",
        "title": "Tuition Fees & Scholarship Options",
        "content": "Tuition fees for engineering programs are $4,500 per semester. Scholarships are available for meritorious students: the Dean's Merit Scholarship covers 50% tuition for students maintaining a CGPA above 9.0. Financial aid is also offered to students with family income under $30,000 annually.",
        "tags": ["tuition", "fees", "scholarships", "finance", "aid", "cost"]
    },
    {
        "id": "DOC-005",
        "title": "Library Code of Conduct & Hours",
        "content": "The Central Library is open daily from 8:00 AM to 11:00 PM, and 24 hours during final examination weeks. Undergraduate students can borrow up to 5 books for a duration of 14 days. A late fee of $1 per day per book is charged for overdue items. Absolute silence must be maintained in the study bays.",
        "tags": ["library", "conduct", "books", "borrowing", "fines"]
    }
]

# ── RAG Search & Response Engine ──────────────────────────────────────────

def query_kb(user_query):
    """Retrieve relevant document chunks matching user query keywords."""
    words = re.findall(r'\w+', user_query.lower())
    results = []

    for doc in KNOWLEDGE_BASE:
        score = 0
        # Check tag matches (higher weight)
        for w in words:
            if w in doc["tags"]:
                score += 3
            # Check content matches
            score += doc["content"].lower().count(w)
            score += doc["title"].lower().count(w) * 2

        if score > 0:
            results.append((doc, score))

    # Sort by relevance score
    results.sort(key=lambda x: x[1], reverse=True)
    return [r[0] for r in results]


def generate_response(user_query):
    """Simulate RAG generation using retrieved document context."""
    matched_docs = query_kb(user_query)

    if not matched_docs:
        return {
            "answer": "I'm sorry, I couldn't find any direct information in the university knowledge base regarding that query. Could you please rephrase or ask about admissions, grading, hostel rules, tuition fees, or library guidelines?",
            "sources": []
        }

    # Synthesize response based on top documents
    top_doc = matched_docs[0]
    ans = ""

    # Rule-based synthesis simulation
    q = user_query.lower()
    if "admission" in q or "apply" in q or "eligibility" in q:
        ans = "Based on the University Admission Guidelines: To apply for undergraduate engineering, you need at least 60% in Physics, Chemistry, and Math (10+2). Applications are open online from March 1st to July 31st. You must also clear the entrance exam (UCEE) in June."
    elif "hostel" in q or "room" in q or "dorm" in q or "curfew" in q:
        ans = "According to the Hostel Rules: On-campus double occupancy costs $1,200/semester, and single occupancy is $1,800/semester. A curfew is enforced at 10:30 PM. Freshmen must subscribe to the mandatory meal plan ($800/semester)."
    elif "tuition" in q or "fee" in q or "scholarship" in q or "cost" in q:
        ans = "Regarding Tuition and Financial Aid: Engineering tuition is $4,500/semester. If you maintain a CGPA above 9.0, you qualify for the Dean's Merit Scholarship (50% tuition waiver). Financial aid is available for annual family incomes under $30,000."
    elif "grade" in q or "cgpa" in q or "gpa" in q or "probation" in q:
        ans = "Academic Policy states: We use a 10-point CGPA system (O is 10, F is 0). To stay in good standing and avoid academic probation, you must maintain a CGPA of 5.0 or above."
    elif "library" in q or "book" in q or "conduct" in q:
        ans = "Library Regulations: The library is open 8 AM - 11 PM daily (24 hours during finals). You can borrow up to 5 books for 14 days. Fines are $1/day per overdue book."
    else:
        # Fallback to general summary of top match
        ans = f"Here is the context found in '{top_doc['title']}': {top_doc['content']}"

    return {
        "answer": ans,
        "sources": [d["title"] for d in matched_docs[:2]]
    }


# ── Templates ──────────────────────────────────────────────────────────────

TMPL = """
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>University AI RAG Chatbot</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0f172a;--bg2:#1e293b;--card:#334155;--text:#f8fafc;--dim:#94a3b8;--blue:#2563eb;--green:#10b981;--border:#475569}
body{font-family:'Segoe UI',sans-serif;background:var(--bg);color:var(--text)}
.header{background:linear-gradient(135deg,#1e293b,#0f172a);border-bottom:1px solid var(--border);padding:16px 32px;display:flex;align-items:center;justify-content:space-between}
.header h1{font-size:1.4rem;background:linear-gradient(135deg,#10b981,#3b82f6);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.container{max-width:1200px;margin:0 auto;padding:24px;display:grid;grid-template-columns:1fr 350px;gap:24px}
@media(max-width:768px){.container{grid-template-columns:1fr}}
.chat-window{background:var(--bg2);border:1px solid var(--border);border-radius:12px;height:550px;display:flex;flex-direction:column;overflow:hidden}
.chat-messages{flex:1;padding:20px;overflow-y:auto;display:flex;flex-direction:column;gap:12px}
.message{padding:10px 14px;border-radius:8px;max-width:75%;font-size:.9rem;line-height:1.4}
.message.user{background:var(--blue);align-self:flex-end}
.message.bot{background:var(--card);align-self:flex-start}
.message.bot .sources{font-size:.7rem;color:var(--dim);margin-top:6px;border-top:1px solid rgba(255,255,255,.1);padding-top:4px}
.chat-input-area{padding:16px;background:rgba(0,0,0,.2);border-top:1px solid var(--border);display:flex;gap:8px}
input[type=text]{flex:1;padding:10px 14px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text);font-size:.9rem}
.btn{padding:10px 20px;border-radius:8px;border:none;cursor:pointer;background:var(--green);color:#fff;font-weight:600}
.knowledge-panel{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:20px;overflow-y:auto;height:550px}
.doc-item{margin-bottom:16px;border-bottom:1px solid var(--border);padding-bottom:12px}
.doc-item h4{font-size:.85rem;color:var(--green);margin-bottom:4px}
.doc-item p{font-size:.75rem;color:var(--dim);line-height:1.4}
</style></head><body>
<div class="header"><h1>🤖 AI Chatbot for University (RAG)</h1><span style="color:var(--dim);font-size:.8rem">Admission & Rules Assistant</span></div>
<div class="container">
    <div class="chat-window">
        <div class="chat-messages" id="chat">
            <div class="message bot">
                Hello! I am your University AI Assistant. I use Retrieval-Augmented Generation (RAG) to query our rules and guidelines. Ask me about admissions, fees, hostel rules, library code, or GPA systems!
            </div>
        </div>
        <div class="chat-input-area">
            <input type="text" id="query-input" placeholder="Type your query (e.g. How much are the hostel fees?)..." onkeydown="if(event.key==='Enter')sendMessage()">
            <button class="btn" onclick="sendMessage()">Send</button>
        </div>
    </div>
    <div class="knowledge-panel">
        <h3>📚 Indexed Knowledge Base</h3>
        <p style="font-size:.75rem;color:var(--dim);margin-bottom:16px">Simulated search indexing files:</p>
        {% for d in kb %}
        <div class="doc-item">
            <h4>{{ d.title }}</h4>
            <p>{{ d.content }}</p>
        </div>
        {% endfor %}
    </div>
</div>
<script>
function sendMessage() {
    const input = document.getElementById("query-input");
    const val = input.value.strip ? input.value.strip() : input.value.trim();
    if(!val) return;
    
    // Add user message
    const chat = document.getElementById("chat");
    const userMsg = document.createElement("div");
    userMsg.className = "message user";
    userMsg.innerText = val;
    chat.appendChild(userMsg);
    
    input.value = "";
    chat.scrollTop = chat.scrollHeight;

    // Call API
    fetch("/api/chat", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({query: val})
    })
    .then(r => r.json())
    .then(data => {
        const botMsg = document.createElement("div");
        botMsg.className = "message bot";
        let srcText = "";
        if(data.sources && data.sources.length > 0) {
            srcText = "<div class='sources'>Sources: " + data.sources.join(", ") + "</div>";
        }
        botMsg.innerHTML = "<div>" + data.answer + "</div>" + srcText;
        chat.appendChild(botMsg);
        chat.scrollTop = chat.scrollHeight;
    });
}
</script>
</body></html>
"""

# ── Routes ─────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    from jinja2 import Template
    return Template(TMPL).render(kb=KNOWLEDGE_BASE)


@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json() or {}
    query = data.get("query", "")
    res = generate_response(query)
    return jsonify(res)


if __name__ == "__main__":
    print("\n  🤖 AI University Chatbot — http://localhost:5015\n")
    app.run(debug=True, port=5015)
