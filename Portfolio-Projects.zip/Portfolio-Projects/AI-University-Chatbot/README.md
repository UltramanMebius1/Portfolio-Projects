# 🤖 AI Chatbot for University (RAG-based)
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge)](https://python.org)

Intelligent University AI Chatbot simulating Retrieval-Augmented Generation (RAG) to query knowledge documents (PDF rules, admissions, hostel fees, course catalogs) with keyword search, TF-IDF cosine similarity approximation, and contextual completions.

## Features
- Simulated RAG pipeline loading knowledge base documents
- Exact keyword matching + TF-IDF cosine similarity approximation for document retrieval
- Dynamic contexts passed to simulated RAG generator for intelligent completions
- Interactive web chat interface with source document referencing
- Search explorer and knowledge index manager

## Quick Start
```bash
pip install -r requirements.txt
python app.py  # http://localhost:5015
```
## License — MIT — **Koventhan M**
