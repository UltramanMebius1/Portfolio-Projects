"""
Machine Learning module for Student Performance Prediction.
Implements Linear Regression, Random Forest, and Decision Tree models
using scikit-learn for training, prediction, and model comparison.
"""

import os
import json
import logging
import pickle
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

logger = logging.getLogger(__name__)

# Feature columns used for training
CATEGORICAL_FEATURES = ['gender', 'ethnicity', 'parental_education', 'lunch_type', 'test_prep']
NUMERICAL_FEATURES = ['math_score', 'reading_score', 'writing_score']
TARGET_COLUMN = 'average_score'

# Persistent encoders and scaler
_label_encoders = {}
_scaler = StandardScaler()
_models = {}


def _compute_average_score(df):
    """Compute the average score as the target variable."""
    df = df.copy()
    df[TARGET_COLUMN] = (df['math_score'] + df['reading_score'] + df['writing_score']) / 3.0
    return df


def _encode_features(df, fit=False):
    """Encode categorical features and scale numerical features."""
    global _label_encoders, _scaler
    df = df.copy()

    for col in CATEGORICAL_FEATURES:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")
        df[col] = df[col].astype(str).str.strip().str.lower()
        if fit:
            le = LabelEncoder()
            df[col + '_encoded'] = le.fit_transform(df[col])
            _label_encoders[col] = le
        else:
            le = _label_encoders.get(col)
            if le is None:
                raise ValueError(f"Encoder for '{col}' not found. Train the model first.")
            # Handle unseen labels gracefully
            known = set(le.classes_)
            df[col + '_encoded'] = df[col].apply(
                lambda x: le.transform([x])[0] if x in known else -1
            )

    feature_cols = [c + '_encoded' for c in CATEGORICAL_FEATURES] + NUMERICAL_FEATURES
    X = df[feature_cols].values

    if fit:
        X = _scaler.fit_transform(X)
    else:
        X = _scaler.transform(X)

    return X, feature_cols


def _get_model_instance(model_name):
    """Return a fresh sklearn model instance by name."""
    models = {
        'linear_regression': LinearRegression(),
        'random_forest': RandomForestRegressor(n_estimators=100, random_state=42, max_depth=10),
        'decision_tree': DecisionTreeRegressor(random_state=42, max_depth=8),
    }
    if model_name not in models:
        raise ValueError(f"Unknown model: {model_name}. Choose from {list(models.keys())}")
    return models[model_name]


def score_to_grade(score):
    """Convert a numerical score (0–100) to a letter grade."""
    if score >= 90:
        return 'A+'
    elif score >= 85:
        return 'A'
    elif score >= 80:
        return 'A-'
    elif score >= 75:
        return 'B+'
    elif score >= 70:
        return 'B'
    elif score >= 65:
        return 'B-'
    elif score >= 60:
        return 'C+'
    elif score >= 55:
        return 'C'
    elif score >= 50:
        return 'C-'
    elif score >= 45:
        return 'D'
    else:
        return 'F'


def train_all_models(csv_path=None, df=None):
    """
    Train all three models on the provided data.
    Returns a dict of model metrics.
    """
    global _models

    if df is None:
        if csv_path is None:
            raise ValueError("Provide either csv_path or a DataFrame.")
        df = pd.read_csv(csv_path)

    logger.info(f"Training on {len(df)} samples")

    # Clean column names
    df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')

    # Compute target
    df = _compute_average_score(df)

    # Encode
    X, feature_cols = _encode_features(df, fit=True)
    y = df[TARGET_COLUMN].values

    # Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    results = {}
    model_names = ['linear_regression', 'random_forest', 'decision_tree']

    for name in model_names:
        model = _get_model_instance(name)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        # Clamp predictions
        y_pred = np.clip(y_pred, 0, 100)

        r2 = r2_score(y_test, y_pred)
        mae = mean_absolute_error(y_test, y_pred)
        rmse = float(np.sqrt(mean_squared_error(y_test, y_pred)))

        # Feature importances
        if hasattr(model, 'feature_importances_'):
            importances = dict(zip(feature_cols, model.feature_importances_.tolist()))
        elif hasattr(model, 'coef_'):
            importances = dict(zip(feature_cols, np.abs(model.coef_).tolist()))
        else:
            importances = {}

        _models[name] = model

        results[name] = {
            'r2_score': float(r2),
            'mae': float(mae),
            'rmse': float(rmse),
            'training_samples': len(X_train),
            'test_samples': len(X_test),
            'feature_importances': importances,
            'predictions': y_pred.tolist(),
            'actuals': y_test.tolist(),
        }

        logger.info(f"{name}: R2={r2:.4f}, MAE={mae:.4f}, RMSE={rmse:.4f}")

    return results


def predict_single(input_data, model_name='random_forest'):
    """
    Predict for a single student.
    input_data: dict with keys matching feature columns.
    Returns predicted score and grade letter.
    """
    if model_name not in _models:
        raise ValueError(f"Model '{model_name}' not trained. Train models first.")

    df = pd.DataFrame([input_data])
    df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')

    X, _ = _encode_features(df, fit=False)
    model = _models[model_name]
    pred = model.predict(X)[0]
    pred = float(np.clip(pred, 0, 100))

    return {
        'predicted_score': round(pred, 2),
        'grade_letter': score_to_grade(pred),
        'model_used': model_name,
    }


def predict_batch(csv_path=None, df=None, model_name='random_forest'):
    """
    Predict for a batch of students from CSV or DataFrame.
    Returns list of prediction dicts.
    """
    if model_name not in _models:
        raise ValueError(f"Model '{model_name}' not trained. Train models first.")

    if df is None:
        if csv_path is None:
            raise ValueError("Provide either csv_path or a DataFrame.")
        df = pd.read_csv(csv_path)

    df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')

    X, _ = _encode_features(df, fit=False)
    model = _models[model_name]
    predictions = model.predict(X)
    predictions = np.clip(predictions, 0, 100)

    results = []
    for i, pred in enumerate(predictions):
        row = df.iloc[i]
        results.append({
            'name': row.get('name', f'Student_{i+1}'),
            'math_score': float(row['math_score']),
            'reading_score': float(row['reading_score']),
            'writing_score': float(row['writing_score']),
            'gender': str(row['gender']),
            'ethnicity': str(row['ethnicity']),
            'parental_education': str(row['parental_education']),
            'lunch_type': str(row['lunch_type']),
            'test_prep': str(row['test_prep']),
            'predicted_score': round(float(pred), 2),
            'grade_letter': score_to_grade(float(pred)),
            'model_used': model_name,
        })

    return results


def save_models(model_dir):
    """Persist trained models, encoders, and scaler to disk."""
    os.makedirs(model_dir, exist_ok=True)
    with open(os.path.join(model_dir, 'models.pkl'), 'wb') as f:
        pickle.dump(_models, f)
    with open(os.path.join(model_dir, 'encoders.pkl'), 'wb') as f:
        pickle.dump(_label_encoders, f)
    with open(os.path.join(model_dir, 'scaler.pkl'), 'wb') as f:
        pickle.dump(_scaler, f)
    logger.info("Models saved to %s", model_dir)


def load_models(model_dir):
    """Load persisted models from disk."""
    global _models, _label_encoders, _scaler
    models_path = os.path.join(model_dir, 'models.pkl')
    encoders_path = os.path.join(model_dir, 'encoders.pkl')
    scaler_path = os.path.join(model_dir, 'scaler.pkl')

    if not all(os.path.exists(p) for p in [models_path, encoders_path, scaler_path]):
        return False

    with open(models_path, 'rb') as f:
        _models = pickle.load(f)
    with open(encoders_path, 'rb') as f:
        _label_encoders = pickle.load(f)
    with open(scaler_path, 'rb') as f:
        _scaler = pickle.load(f)

    logger.info("Models loaded from %s", model_dir)
    return True


def get_dashboard_data(csv_path=None, df=None):
    """
    Generate dashboard statistics and chart data from the dataset.
    """
    if df is None:
        if csv_path is None:
            raise ValueError("Provide either csv_path or a DataFrame.")
        df = pd.read_csv(csv_path)

    df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')

    stats = {
        'total_students': len(df),
        'avg_math': round(df['math_score'].mean(), 2),
        'avg_reading': round(df['reading_score'].mean(), 2),
        'avg_writing': round(df['writing_score'].mean(), 2),
        'avg_overall': round(df[['math_score', 'reading_score', 'writing_score']].mean().mean(), 2),
    }

    # Score distributions (binned)
    bins = list(range(0, 110, 10))
    labels = [f'{b}-{b+9}' for b in bins[:-1]]
    distributions = {}
    for col in ['math_score', 'reading_score', 'writing_score']:
        counts, _ = np.histogram(df[col].dropna(), bins=bins)
        distributions[col] = {'labels': labels, 'data': counts.tolist()}

    # Gender distribution
    gender_counts = df['gender'].value_counts().to_dict()

    # Ethnicity distribution
    ethnicity_counts = df['ethnicity'].value_counts().to_dict()

    # Parental education distribution
    edu_counts = df['parental_education'].value_counts().to_dict()

    # Correlation matrix
    numeric_df = df[['math_score', 'reading_score', 'writing_score']]
    corr = numeric_df.corr().round(4)
    correlation = {
        'labels': corr.columns.tolist(),
        'data': corr.values.tolist(),
    }

    # Test prep impact
    if 'test_prep' in df.columns:
        prep_groups = df.groupby('test_prep')[['math_score', 'reading_score', 'writing_score']].mean().round(2)
        test_prep_impact = {
            'labels': prep_groups.index.tolist(),
            'math': prep_groups['math_score'].tolist(),
            'reading': prep_groups['reading_score'].tolist(),
            'writing': prep_groups['writing_score'].tolist(),
        }
    else:
        test_prep_impact = {}

    # Lunch type impact
    if 'lunch_type' in df.columns:
        lunch_groups = df.groupby('lunch_type')[['math_score', 'reading_score', 'writing_score']].mean().round(2)
        lunch_impact = {
            'labels': lunch_groups.index.tolist(),
            'math': lunch_groups['math_score'].tolist(),
            'reading': lunch_groups['reading_score'].tolist(),
            'writing': lunch_groups['writing_score'].tolist(),
        }
    else:
        lunch_impact = {}

    return {
        'stats': stats,
        'distributions': distributions,
        'gender_counts': gender_counts,
        'ethnicity_counts': ethnicity_counts,
        'education_counts': edu_counts,
        'correlation': correlation,
        'test_prep_impact': test_prep_impact,
        'lunch_impact': lunch_impact,
    }


def is_trained():
    """Check if models are trained and ready."""
    return len(_models) > 0


def get_available_models():
    """Return list of available trained model names."""
    return list(_models.keys())
