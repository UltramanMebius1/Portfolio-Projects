"""
Seed data generator for the Student Performance Prediction application.
Generates realistic student data using numpy and saves to CSV + populates the database.
"""

import os
import numpy as np
import pandas as pd
import logging

logger = logging.getLogger(__name__)

# Realistic data distributions
FIRST_NAMES_MALE = [
    'James', 'John', 'Robert', 'Michael', 'William', 'David', 'Richard', 'Joseph',
    'Thomas', 'Charles', 'Daniel', 'Matthew', 'Anthony', 'Mark', 'Donald', 'Steven',
    'Andrew', 'Joshua', 'Kenneth', 'Kevin', 'Brian', 'George', 'Timothy', 'Ronald',
    'Edward', 'Jason', 'Jeffrey', 'Ryan', 'Jacob', 'Nicholas', 'Ethan', 'Liam',
    'Noah', 'Mason', 'Lucas', 'Oliver', 'Aiden', 'Elijah', 'Benjamin', 'Logan',
]

FIRST_NAMES_FEMALE = [
    'Mary', 'Patricia', 'Jennifer', 'Linda', 'Barbara', 'Elizabeth', 'Susan',
    'Jessica', 'Sarah', 'Karen', 'Lisa', 'Nancy', 'Betty', 'Margaret', 'Sandra',
    'Ashley', 'Dorothy', 'Kimberly', 'Emily', 'Donna', 'Michelle', 'Carol',
    'Amanda', 'Melissa', 'Deborah', 'Stephanie', 'Rebecca', 'Sharon', 'Laura',
    'Cynthia', 'Emma', 'Olivia', 'Ava', 'Sophia', 'Isabella', 'Mia', 'Charlotte',
    'Amelia', 'Harper', 'Evelyn',
]

LAST_NAMES = [
    'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis',
    'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez', 'Wilson', 'Anderson',
    'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin', 'Lee', 'Perez', 'Thompson',
    'White', 'Harris', 'Sanchez', 'Clark', 'Ramirez', 'Lewis', 'Robinson',
    'Walker', 'Young', 'Allen', 'King', 'Wright', 'Scott', 'Torres', 'Nguyen',
    'Hill', 'Flores', 'Green', 'Adams', 'Nelson', 'Baker', 'Hall', 'Rivera',
    'Campbell', 'Mitchell', 'Carter', 'Roberts',
]

GENDERS = ['male', 'female']
ETHNICITIES = ['group A', 'group B', 'group C', 'group D', 'group E']
PARENTAL_EDUCATIONS = [
    "some high school", "high school", "some college",
    "associate's degree", "bachelor's degree", "master's degree"
]
LUNCH_TYPES = ['standard', 'free/reduced']
TEST_PREPS = ['completed', 'none']


def generate_student_data(n_students=500, random_seed=42):
    """
    Generate realistic student performance data.
    Scores are correlated and influenced by demographic factors.
    """
    np.random.seed(random_seed)

    data = []

    for i in range(n_students):
        # Demographics
        gender = np.random.choice(GENDERS, p=[0.48, 0.52])
        ethnicity = np.random.choice(ETHNICITIES, p=[0.12, 0.15, 0.32, 0.25, 0.16])
        parental_edu = np.random.choice(
            PARENTAL_EDUCATIONS,
            p=[0.12, 0.20, 0.22, 0.18, 0.16, 0.12]
        )
        lunch = np.random.choice(LUNCH_TYPES, p=[0.64, 0.36])
        test_prep = np.random.choice(TEST_PREPS, p=[0.35, 0.65])

        # Name
        if gender == 'male':
            first = np.random.choice(FIRST_NAMES_MALE)
        else:
            first = np.random.choice(FIRST_NAMES_FEMALE)
        last = np.random.choice(LAST_NAMES)
        name = f"{first} {last}"

        # Base ability score (latent factor)
        base = np.random.normal(65, 15)

        # Education level bonus
        edu_bonus = {
            "some high school": -5,
            "high school": -2,
            "some college": 0,
            "associate's degree": 3,
            "bachelor's degree": 6,
            "master's degree": 10,
        }
        base += edu_bonus.get(parental_edu, 0)

        # Lunch type effect (standard lunch correlates with higher scores)
        if lunch == 'standard':
            base += np.random.uniform(2, 6)
        else:
            base -= np.random.uniform(1, 4)

        # Test prep effect
        if test_prep == 'completed':
            base += np.random.uniform(3, 8)

        # Gender-based tendencies (slight statistical differences)
        if gender == 'female':
            reading_boost = np.random.uniform(2, 6)
            writing_boost = np.random.uniform(3, 7)
            math_penalty = np.random.uniform(0, 3)
        else:
            reading_boost = 0
            writing_boost = 0
            math_penalty = 0

        # Generate correlated scores
        noise_math = np.random.normal(0, 8)
        noise_reading = np.random.normal(0, 7)
        noise_writing = np.random.normal(0, 7)

        math_score = base - math_penalty + noise_math
        reading_score = base + reading_boost + noise_reading
        writing_score = base + writing_boost + noise_writing

        # Clamp to 0-100
        math_score = int(np.clip(round(math_score), 0, 100))
        reading_score = int(np.clip(round(reading_score), 0, 100))
        writing_score = int(np.clip(round(writing_score), 0, 100))

        data.append({
            'name': name,
            'gender': gender,
            'ethnicity': ethnicity,
            'parental_education': parental_edu,
            'lunch_type': lunch,
            'test_prep': test_prep,
            'math_score': math_score,
            'reading_score': reading_score,
            'writing_score': writing_score,
        })

    df = pd.DataFrame(data)
    return df


def save_to_csv(df, filepath):
    """Save DataFrame to CSV."""
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    df.to_csv(filepath, index=False)
    logger.info(f"Saved {len(df)} records to {filepath}")


def populate_database(df, db, Student):
    """Insert generated data into the database."""
    count = 0
    for _, row in df.iterrows():
        student = Student(
            name=row['name'],
            gender=row['gender'],
            ethnicity=row['ethnicity'],
            parental_education=row['parental_education'],
            lunch_type=row['lunch_type'],
            test_prep=row['test_prep'],
            math_score=row['math_score'],
            reading_score=row['reading_score'],
            writing_score=row['writing_score'],
        )
        db.session.add(student)
        count += 1

    db.session.commit()
    logger.info(f"Inserted {count} students into database")
    return count


def seed(app, db, Student, csv_path, force=False):
    """
    Main seed function. Generates data, saves CSV, populates DB.
    Skips if data already exists unless force=True.
    """
    with app.app_context():
        existing = Student.query.count()
        if existing > 0 and not force:
            logger.info(f"Database already has {existing} students. Skipping seed.")
            return False

        logger.info("Generating seed data...")
        df = generate_student_data(n_students=500)
        save_to_csv(df, csv_path)

        if force and existing > 0:
            Student.query.delete()
            db.session.commit()
            logger.info("Cleared existing student data.")

        populate_database(df, db, Student)
        logger.info("Seed complete.")
        return True


if __name__ == '__main__':
    # Standalone usage
    logging.basicConfig(level=logging.INFO)
    df = generate_student_data(500)
    output_path = os.path.join(os.path.dirname(__file__), 'data', 'sample_students.csv')
    save_to_csv(df, output_path)
    print(f"Generated {len(df)} students → {output_path}")
    print(df.describe())
