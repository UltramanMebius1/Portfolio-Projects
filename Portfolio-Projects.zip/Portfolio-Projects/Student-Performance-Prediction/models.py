"""
Database models for the Student Performance Prediction application.
Uses SQLAlchemy ORM with SQLite backend.
"""

from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class Student(db.Model):
    """Model for storing student data."""
    __tablename__ = 'students'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(100), nullable=False)
    gender = db.Column(db.String(10), nullable=False)
    ethnicity = db.Column(db.String(50), nullable=False)
    parental_education = db.Column(db.String(100), nullable=False)
    lunch_type = db.Column(db.String(20), nullable=False)
    test_prep = db.Column(db.String(20), nullable=False)
    math_score = db.Column(db.Float, nullable=False)
    reading_score = db.Column(db.Float, nullable=False)
    writing_score = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'gender': self.gender,
            'ethnicity': self.ethnicity,
            'parental_education': self.parental_education,
            'lunch_type': self.lunch_type,
            'test_prep': self.test_prep,
            'math_score': self.math_score,
            'reading_score': self.reading_score,
            'writing_score': self.writing_score,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f'<Student {self.name}>'


class Prediction(db.Model):
    """Model for storing prediction results."""
    __tablename__ = 'predictions'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    student_name = db.Column(db.String(100), nullable=True)
    gender = db.Column(db.String(10), nullable=False)
    ethnicity = db.Column(db.String(50), nullable=False)
    parental_education = db.Column(db.String(100), nullable=False)
    lunch_type = db.Column(db.String(20), nullable=False)
    test_prep = db.Column(db.String(20), nullable=False)
    math_score = db.Column(db.Float, nullable=False)
    reading_score = db.Column(db.Float, nullable=False)
    writing_score = db.Column(db.Float, nullable=False)
    predicted_grade = db.Column(db.Float, nullable=False)
    grade_letter = db.Column(db.String(5), nullable=False)
    model_used = db.Column(db.String(50), nullable=False)
    prediction_type = db.Column(db.String(20), default='single')  # single or batch
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'student_name': self.student_name,
            'gender': self.gender,
            'ethnicity': self.ethnicity,
            'parental_education': self.parental_education,
            'lunch_type': self.lunch_type,
            'test_prep': self.test_prep,
            'math_score': self.math_score,
            'reading_score': self.reading_score,
            'writing_score': self.writing_score,
            'predicted_grade': self.predicted_grade,
            'grade_letter': self.grade_letter,
            'model_used': self.model_used,
            'prediction_type': self.prediction_type,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f'<Prediction {self.student_name} - {self.grade_letter}>'


class ModelMetrics(db.Model):
    """Model for storing trained model metrics."""
    __tablename__ = 'model_metrics'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    model_name = db.Column(db.String(50), nullable=False, unique=True)
    r2_score = db.Column(db.Float, nullable=False)
    mae = db.Column(db.Float, nullable=False)
    rmse = db.Column(db.Float, nullable=False)
    training_samples = db.Column(db.Integer, nullable=False)
    feature_importances = db.Column(db.Text, nullable=True)  # JSON string
    trained_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        import json
        return {
            'id': self.id,
            'model_name': self.model_name,
            'r2_score': round(self.r2_score, 4),
            'mae': round(self.mae, 4),
            'rmse': round(self.rmse, 4),
            'training_samples': self.training_samples,
            'feature_importances': json.loads(self.feature_importances) if self.feature_importances else None,
            'trained_at': self.trained_at.isoformat() if self.trained_at else None
        }

    def __repr__(self):
        return f'<ModelMetrics {self.model_name} R2={self.r2_score:.4f}>'
