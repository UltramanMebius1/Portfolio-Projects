"""
Active Directory Attack & Defense Lab — Flask Dashboard
Web interface for AD environment visualization, attack execution, and defense auditing.
"""

import os
import json
from flask import Flask, render_template_string, request, redirect, url_for, jsonify
from ad_simulator import ADEnvironment
from attacks import ADAttackEngine
from defense import ADDefenseAdvisor
from bloodhound_analyzer import AttackPathAnalyzer

app = Flask(__name__)
app.secret_key = "ad-lab-secret-key"

# Initialize components
ad_env = ADEnvironment()
attack_engine = ADAttackEngine(ad_env)
defense_advisor = ADDefenseAdvisor(ad_env)
path_analyzer = AttackPathAnalyzer(ad_env)

BASE_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AD Attack & Defense Lab</title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        :root{--bg:#0b0f1a;--bg2:#121829;--card:#1a2038;--text:#e0e6ed;--dim:#7a8599;--blue:#4f8ff7;--purple:#9b6dff;--red:#f44;--orange:#ff8c42;--yellow:#ffd166;--green:#2ecc71;--border:#2a3352}
        body{font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:var(--text)}
        .header{background:linear-gradient(135deg,#1a2038,#0f1525);border-bottom:1px solid var(--border);padding:16px 32px;display:flex;align-items:center;justify-content:space-between}
        .header h1{font-size:1.4rem;background:linear-gradient(135deg,#ff6b6b,#9b6dff);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
        .nav{background:var(--bg2);border-bottom:1px solid var(--border);display:flex;padding:0 32px}
        .nav a{color:var(--dim);text-decoration:none;padding:12px 18px;font-size:.85rem;font-weight:500;border-bottom:2px solid transparent;transition:.2s}
        .nav a:hover,.nav a.active{color:var(--blue);border-bottom-color:var(--blue)}
        .container{max-width:1400px;margin:0 auto;padding:24px}
        .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-bottom:24px}
        .stat{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:20px}
        .stat .label{font-size:.7rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}
        .stat .val{font-size:1.8rem;font-weight:700}
        .card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:24px}
        .card h2{font-size:1.1rem;margin-bottom:16px}
        table{width:100%;border-collapse:collapse}
        th{text-align:left;padding:10px;font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:var(--dim);border-bottom:1px solid var(--border)}
        td{padding:10px;border-bottom:1px solid var(--border);font-size:.85rem}
        tr:hover{background:rgba(79,143,247,.04)}
        .badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:600;text-transform:uppercase}
        .badge.critical{background:rgba(255,68,68,.12);color:var(--red);border:1px solid rgba(255,68,68,.25)}
        .badge.high{background:rgba(255,140,66,.12);color:var(--orange);border:1px solid rgba(255,140,66,.25)}
        .badge.medium{background:rgba(255,209,102,.12);color:var(--yellow);border:1px solid rgba(255,209,102,.25)}
        .badge.low{background:rgba(46,204,113,.12);color:var(--green);border:1px solid rgba(46,204,113,.25)}
        .btn{padding:8px 16px;border-radius:8px;border:none;cursor:pointer;font-size:.85rem;font-weight:500;transition:.2s;text-decoration:none;display:inline-block;margin:2px}
        .btn-red{background:var(--red);color:#fff}.btn-red:hover{background:#d32f2f}
        .btn-blue{background:var(--blue);color:#fff}.btn-blue:hover{background:#3a7de0}
        .btn-green{background:var(--green);color:#fff}.btn-green:hover{background:#27ae60}
        .btn-sm{padding:4px 12px;font-size:.75rem}
        .two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px}
        @media(max-width:768px){.two-col{grid-template-columns:1fr}}
        .finding{padding:12px 16px;margin:8px 0;border-radius:8px;border-left:4px solid}
        .finding.critical{border-color:var(--red);background:rgba(255,68,68,.05)}
        .finding.high{border-color:var(--orange);background:rgba(255,140,66,.05)}
        .finding.medium{border-color:var(--yellow);background:rgba(255,209,102,.05)}
        .finding.low{border-color:var(--green);background:rgba(46,204,113,.05)}
        .finding h4{font-size:.9rem;margin-bottom:4px}
        .finding p{font-size:.8rem;color:var(--dim)}
        .finding .rem{font-size:.75rem;color:var(--blue);margin-top:6px}
        .path-item{font-family:monospace;font-size:.8rem;padding:8px 12px;margin:4px 0;background:var(--bg);border-radius:6px;border:1px solid var(--border);overflow-x:auto}
        .score-circle{width:120px;height:120px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:2rem;font-weight:700;margin:0 auto 16px}
        .grade-A{border:4px solid var(--green);color:var(--green)}
        .grade-B{border:4px solid var(--blue);color:var(--blue)}
        .grade-C{border:4px solid var(--yellow);color:var(--yellow)}
        .grade-D{border:4px solid var(--orange);color:var(--orange)}
        .grade-F{border:4px solid var(--red);color:var(--red)}
        .flash{padding:12px 20px;border-radius:8px;margin-bottom:16px;background:rgba(46,204,113,.12);border:1px solid rgba(46,204,113,.3);color:var(--green);font-size:.85rem}
    </style>
</head>
<body>
    <div class="header"><h1>🏰 Active Directory Attack & Defense Lab</h1><span style="color:var(--dim);font-size:.8rem">Domain: {{ domain }}</span></div>
    <div class="nav">
        <a href="/" class="{{ 'active' if page=='dash' }}">Dashboard</a>
        <a href="/environment" class="{{ 'active' if page=='env' }}">Environment</a>
        <a href="/attacks" class="{{ 'active' if page=='attacks' }}">Attacks</a>
        <a href="/defense" class="{{ 'active' if page=='defense' }}">Defense Audit</a>
        <a href="/paths" class="{{ 'active' if page=='paths' }}">Attack Paths</a>
    </div>
    <div class="container">
        {% if flash %}<div class="flash">{{ flash }}</div>{% endif %}
        {% block content %}{% endblock %}
    </div>
</body></html>
"""

# ── Routes ─────────────────────────────────────────────────────────────────

@app.route("/")
def dashboard():
    env_summary = ad_env.get_environment_summary()
    attack_summary = attack_engine.get_attack_summary()
    graph_stats = path_analyzer.get_graph_stats()
    content = """
{% extends "base" %}{% block content %}
<div class="grid">
    <div class="stat"><div class="label">Domain Users</div><div class="val" style="color:var(--blue)">{{ env.users }}</div></div>
    <div class="stat"><div class="label">Computers</div><div class="val" style="color:var(--purple)">{{ env.computers }}</div></div>
    <div class="stat"><div class="label">Domain Admins</div><div class="val" style="color:var(--red)">{{ env.domain_admins }}</div></div>
    <div class="stat"><div class="label">Kerberoastable</div><div class="val" style="color:var(--orange)">{{ env.kerberoastable }}</div></div>
    <div class="stat"><div class="label">Attacks Run</div><div class="val" style="color:var(--blue)">{{ attacks.total_attacks }}</div></div>
    <div class="stat"><div class="label">Attack Paths</div><div class="val" style="color:var(--red)">{{ graph.total_edges }}</div></div>
</div>
<div class="card">
    <h2>⚡ Quick Actions</h2>
    <a href="/run-attacks" class="btn btn-red">🗡️ Run All Attacks</a>
    <a href="/defense" class="btn btn-blue">🛡️ Security Audit</a>
    <a href="/paths" class="btn btn-blue">🔍 Attack Paths</a>
</div>
<div class="two-col">
    <div class="card">
        <h2>🏗️ Environment Overview</h2>
        <table>
            <tr><td style="color:var(--dim)">Domain</td><td>{{ env.domain }}</td></tr>
            <tr><td style="color:var(--dim)">Functional Level</td><td>{{ env.functional_level }}</td></tr>
            <tr><td style="color:var(--dim)">Groups</td><td>{{ env.groups }}</td></tr>
            <tr><td style="color:var(--dim)">GPOs</td><td>{{ env.gpos }}</td></tr>
            <tr><td style="color:var(--dim)">OUs</td><td>{{ env.ous }}</td></tr>
            <tr><td style="color:var(--dim)">AS-REP Roastable</td><td style="color:var(--red)">{{ env.asrep_roastable }}</td></tr>
        </table>
    </div>
    <div class="card">
        <h2>🎯 High Value Targets</h2>
        <table><thead><tr><th>Target</th><th>Type</th><th>Risk</th></tr></thead><tbody>
        {% for t in hvt[:6] %}
        <tr><td>{{ t.name }}</td><td>{{ t.type }}</td><td><span class="badge {{ t.risk }}">{{ t.risk }}</span></td></tr>
        {% endfor %}
        </tbody></table>
    </div>
</div>
{% endblock %}
"""
    from jinja2 import Template
    base = Template(BASE_TEMPLATE)
    page_t = Template(content)
    rendered = Template(
        BASE_TEMPLATE.replace("{% block content %}{% endblock %}", content)
    ).render(
        page="dash", domain=ad_env.domain_name, flash=request.args.get("msg"),
        env=env_summary, attacks=attack_summary, graph=graph_stats,
        hvt=path_analyzer.get_high_value_targets(),
    )
    return rendered


@app.route("/environment")
def environment():
    content = BASE_TEMPLATE.replace("{% block content %}{% endblock %}", """
<div class="two-col">
    <div class="card">
        <h2>👤 Domain Users ({{ users|length }})</h2>
        <table><thead><tr><th>User</th><th>OU</th><th>Admin</th><th>SPN</th><th>Groups</th></tr></thead><tbody>
        {% for u in users %}
        <tr>
            <td>{{ u.username }}</td><td style="font-size:.7rem">{{ u.ou }}</td>
            <td>{{ '🔴' if u.is_admin else '🟢' }}</td>
            <td style="font-size:.7rem">{{ u.spn or '-' }}</td>
            <td style="font-size:.7rem">{{ u.groups|join(', ') }}</td>
        </tr>{% endfor %}
        </tbody></table>
    </div>
    <div class="card">
        <h2>🖥️ Domain Computers ({{ computers|length }})</h2>
        <table><thead><tr><th>Name</th><th>OS</th><th>IP</th><th>Role</th><th>Local Admins</th></tr></thead><tbody>
        {% for c in computers %}
        <tr>
            <td>{{ c.name }}</td><td style="font-size:.75rem">{{ c.os_version }}</td>
            <td>{{ c.ip }}</td><td><span class="badge {{ 'critical' if c.role=='domain_controller' else 'medium' }}">{{ c.role }}</span></td>
            <td style="font-size:.7rem">{{ c.local_admins|join(', ') }}</td>
        </tr>{% endfor %}
        </tbody></table>
    </div>
</div>
<div class="card">
    <h2>📋 Group Policy Objects</h2>
    <table><thead><tr><th>GPO Name</th><th>Linked OU</th><th>Settings</th></tr></thead><tbody>
    {% for g in gpos %}
    <tr><td>{{ g.name }}</td><td>{{ g.linked_ou }}</td><td style="font-size:.7rem">{{ g.settings }}</td></tr>
    {% endfor %}
    </tbody></table>
</div>
""")
    from jinja2 import Template
    return Template(content).render(
        page="env", domain=ad_env.domain_name, flash=None,
        users=ad_env.users, computers=ad_env.computers, gpos=ad_env.gpos,
    )


@app.route("/attacks")
def attacks_page():
    content = BASE_TEMPLATE.replace("{% block content %}{% endblock %}", """
<div class="card">
    <h2>🗡️ Attack Simulations ({{ results|length }} executed)</h2>
    <a href="/run-attacks" class="btn btn-red" style="margin-bottom:16px">🎯 Run All Attacks</a>
    {% if results %}
    {% for r in results %}
    <div class="finding {{ 'critical' if r.success else 'low' }}" style="margin:12px 0">
        <h4>{{ r.name }} — {{ r.technique_id }} ({{ r.tactic }})</h4>
        <p>{{ r.details }}</p>
        <div class="rem"><strong>Events Generated:</strong> {{ r.events|length }}</div>
        <div class="rem"><strong>Mitigations:</strong><ul style="margin-top:4px">
        {% for m in r.mitigations %}<li>{{ m }}</li>{% endfor %}
        </ul></div>
    </div>
    {% endfor %}
    {% else %}
    <p style="color:var(--dim);padding:20px;text-align:center">No attacks executed yet. Click "Run All Attacks" to begin.</p>
    {% endif %}
</div>
""")
    from jinja2 import Template
    return Template(content).render(
        page="attacks", domain=ad_env.domain_name, flash=request.args.get("msg"),
        results=attack_engine.attack_log,
    )


@app.route("/run-attacks")
def run_attacks():
    attack_engine.attack_log = []
    attack_engine.run_all_attacks()
    return redirect(url_for("attacks_page", msg=f"Executed {len(attack_engine.attack_log)} attack simulations"))


@app.route("/defense")
def defense_page():
    audit = defense_advisor.run_full_audit()
    checklist = defense_advisor.get_hardening_checklist()
    content = BASE_TEMPLATE.replace("{% block content %}{% endblock %}", """
<div class="grid">
    <div class="stat" style="text-align:center">
        <div class="score-circle grade-{{ audit.grade }}">{{ audit.grade }}</div>
        <div class="label">Security Score: {{ audit.score }}/100</div>
    </div>
    <div class="stat"><div class="label">Total Findings</div><div class="val" style="color:var(--blue)">{{ audit.total_findings }}</div></div>
    <div class="stat"><div class="label">Critical</div><div class="val" style="color:var(--red)">{{ audit.critical }}</div></div>
    <div class="stat"><div class="label">High</div><div class="val" style="color:var(--orange)">{{ audit.high }}</div></div>
</div>
<div class="two-col">
    <div class="card">
        <h2>🔍 Audit Findings</h2>
        {% for f in audit.findings %}
        <div class="finding {{ f.severity }}">
            <h4><span class="badge {{ f.severity }}">{{ f.severity }}</span> {{ f.title }}</h4>
            <p>{{ f.description }}</p>
            <div class="rem">🛠️ {{ f.remediation }}</div>
            {% if f.cis_reference %}<div style="font-size:.7rem;color:var(--dim);margin-top:4px">📌 {{ f.cis_reference }}</div>{% endif %}
        </div>
        {% endfor %}
    </div>
    <div class="card">
        <h2>📋 Hardening Checklist</h2>
        <table><thead><tr><th>#</th><th>Action</th><th>Category</th></tr></thead><tbody>
        {% for item in checklist %}
        <tr><td>{{ item.priority }}</td><td>{{ item.action }}</td><td>{{ item.category }}</td></tr>
        {% endfor %}
        </tbody></table>
    </div>
</div>
{% endblock %}
""")
    from jinja2 import Template
    return Template(content).render(
        page="defense", domain=ad_env.domain_name, flash=None,
        audit=audit, checklist=checklist,
    )


@app.route("/paths")
def paths_page():
    report = path_analyzer.generate_report()
    content = BASE_TEMPLATE.replace("{% block content %}{% endblock %}", """
<div class="grid">
    <div class="stat"><div class="label">Graph Nodes</div><div class="val" style="color:var(--blue)">{{ report.graph_stats.total_nodes }}</div></div>
    <div class="stat"><div class="label">Graph Edges</div><div class="val" style="color:var(--purple)">{{ report.graph_stats.total_edges }}</div></div>
    <div class="stat"><div class="label">Users with DA Path</div><div class="val" style="color:var(--red)">{{ report.summary.users_with_da_paths }}</div></div>
    <div class="stat"><div class="label">Critical Targets</div><div class="val" style="color:var(--orange)">{{ report.summary.critical_targets }}</div></div>
</div>
<div class="card">
    <h2>🎯 High Value Targets</h2>
    <table><thead><tr><th>Target</th><th>Type</th><th>Risk</th><th>Reason</th></tr></thead><tbody>
    {% for t in report.high_value_targets %}
    <tr><td>{{ t.name }}</td><td>{{ t.type }}</td><td><span class="badge {{ t.risk }}">{{ t.risk }}</span></td><td style="font-size:.8rem">{{ t.reason }}</td></tr>
    {% endfor %}
    </tbody></table>
</div>
<div class="card">
    <h2>🔗 Attack Paths to Domain Admin</h2>
    {% for user, info in report.attack_paths.items() %}
    <div style="margin:12px 0;padding:12px;background:var(--bg);border-radius:8px;border:1px solid var(--border)">
        <h4 style="color:var(--red)">{{ user }} → Domain Admin ({{ info.total_paths }} path(s), shortest: {{ info.shortest_path }} hops)</h4>
        {% for p in info.paths %}
        <div class="path-item">{{ p }}</div>
        {% endfor %}
    </div>
    {% endfor %}
</div>
""")
    from jinja2 import Template
    return Template(content).render(
        page="paths", domain=ad_env.domain_name, flash=None, report=report,
    )


@app.route("/api/environment")
def api_environment():
    return jsonify(ad_env.get_environment_summary())


@app.route("/api/attacks")
def api_attacks():
    return jsonify(attack_engine.get_attack_summary())


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("  🏰 Active Directory Attack & Defense Lab")
    print("  Starting on http://localhost:5001")
    print("=" * 60 + "\n")
    app.run(debug=True, port=5001)
