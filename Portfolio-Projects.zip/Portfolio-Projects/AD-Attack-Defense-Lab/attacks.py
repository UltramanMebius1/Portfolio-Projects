"""
Active Directory Attack & Defense Lab — Attack Engine
Simulates 12+ real-world AD attack techniques with MITRE ATT&CK mapping.
"""

import random
import hashlib
import json
from datetime import datetime, timedelta


class AttackResult:
    """Represents the result of an attack simulation."""
    def __init__(self, name, technique_id, tactic, success, details, events, mitigations):
        self.name = name
        self.technique_id = technique_id
        self.tactic = tactic
        self.success = success
        self.details = details
        self.events = events      # list of generated security events
        self.mitigations = mitigations
        self.timestamp = datetime.utcnow()

    def to_dict(self):
        return {
            "name": self.name, "technique_id": self.technique_id,
            "tactic": self.tactic, "success": self.success,
            "details": self.details, "events": self.events,
            "mitigations": self.mitigations,
            "timestamp": self.timestamp.isoformat(),
        }


class ADAttackEngine:
    """Executes Active Directory attack simulations."""

    def __init__(self, ad_env):
        self.ad = ad_env
        self.attack_log = []

    def _gen_event(self, event_id, source, description, host, user, severity="high", extra=None):
        event = {
            "timestamp": datetime.utcnow().isoformat(),
            "event_id": event_id, "source": source,
            "description": description, "hostname": host,
            "username": user, "severity": severity,
        }
        if extra:
            event.update(extra)
        return event

    # ── Attack 1: Kerberoasting (T1558.003) ────────────────────────────────
    def kerberoasting(self, attacker_user="dev.junior"):
        """Simulate Kerberoasting attack — request TGS for service accounts."""
        targets = self.ad.get_kerberoastable_users()
        events = []

        for svc in targets:
            events.append(self._gen_event(
                4769, "Security", f"TGS ticket requested for {svc.spn} by {attacker_user}",
                "DC01", attacker_user, "high",
                {"spn": svc.spn, "encryption_type": "0x17 (RC4)", "service_account": svc.username}
            ))

        result = AttackResult(
            "Kerberoasting", "T1558.003", "Credential Access",
            success=len(targets) > 0,
            details=f"Requested TGS tickets for {len(targets)} service accounts with SPNs. "
                    f"RC4 encrypted tickets can be cracked offline.",
            events=events,
            mitigations=[
                "Use AES-256 encryption for Kerberos (disable RC4)",
                "Set long, complex passwords for service accounts (25+ chars)",
                "Implement Group Managed Service Accounts (gMSA)",
                "Monitor Event ID 4769 with encryption type 0x17",
                "Regularly audit accounts with SPNs",
            ]
        )
        self.attack_log.append(result)
        return result

    # ── Attack 2: AS-REP Roasting (T1558.004) ─────────────────────────────
    def asrep_roasting(self):
        """Simulate AS-REP Roasting — target accounts without pre-auth."""
        targets = self.ad.get_asrep_roastable_users()
        events = []

        for user in targets:
            events.append(self._gen_event(
                4768, "Security",
                f"AS-REP requested for {user.username} (pre-auth not required)",
                "DC01", user.username, "high",
                {"pre_auth_required": False}
            ))

        result = AttackResult(
            "AS-REP Roasting", "T1558.004", "Credential Access",
            success=len(targets) > 0,
            details=f"Found {len(targets)} account(s) with 'Do not require Kerberos pre-authentication'. "
                    f"AS-REP hashes can be cracked offline.",
            events=events,
            mitigations=[
                "Enable Kerberos pre-authentication for all accounts",
                "Audit accounts with DONT_REQUIRE_PREAUTH flag",
                "Monitor Event ID 4768 for unusual AS-REQ patterns",
                "Implement strong password policies",
            ]
        )
        self.attack_log.append(result)
        return result

    # ── Attack 3: Pass-the-Hash (T1550.002) ────────────────────────────────
    def pass_the_hash(self, source_host="WS-DEV01", target_host="SRV-FILE01"):
        """Simulate Pass-the-Hash lateral movement."""
        victim = self.ad.get_user("it.admin")
        events = [
            self._gen_event(4624, "Security",
                f"Logon Type 3 (Network) — {victim.username} authenticated via NTLM",
                target_host, victim.username, "critical",
                {"logon_type": 3, "auth_package": "NTLM", "source_ip": "10.0.2.40"}),
            self._gen_event(4672, "Security",
                f"Special privileges assigned to {victim.username}",
                target_host, victim.username, "high"),
        ]

        result = AttackResult(
            "Pass-the-Hash", "T1550.002", "Lateral Movement",
            success=True,
            details=f"Used captured NTLM hash of {victim.username} to authenticate to {target_host}. "
                    f"No cleartext password needed.",
            events=events,
            mitigations=[
                "Disable NTLM authentication where possible",
                "Enable Credential Guard on all endpoints",
                "Implement Local Administrator Password Solution (LAPS)",
                "Use Protected Users security group for privileged accounts",
                "Monitor for Type 3 logons with NTLM auth from unusual sources",
            ]
        )
        self.attack_log.append(result)
        return result

    # ── Attack 4: Golden Ticket (T1558.001) ────────────────────────────────
    def golden_ticket(self):
        """Simulate Golden Ticket attack."""
        events = [
            self._gen_event(4769, "Security",
                "TGS request with forged TGT — krbtgt hash compromise",
                "DC01", "admin", "critical",
                {"ticket_type": "Golden Ticket", "krbtgt_compromised": True}),
            self._gen_event(4624, "Security",
                "Logon with forged Kerberos ticket — unrestricted domain access",
                "DC01", "admin", "critical",
                {"logon_type": 3, "auth_package": "Kerberos"}),
        ]

        result = AttackResult(
            "Golden Ticket", "T1558.001", "Credential Access",
            success=True,
            details="Forged Kerberos TGT using compromised krbtgt hash. "
                    "Grants unrestricted access to any resource in the domain for up to 10 years.",
            events=events,
            mitigations=[
                "Reset krbtgt password TWICE (to invalidate all tickets)",
                "Monitor for TGT with unusually long lifetimes",
                "Implement Advanced Threat Analytics (ATA) or Defender for Identity",
                "Restrict and monitor Domain Admin usage",
                "Implement tiered administration model",
            ]
        )
        self.attack_log.append(result)
        return result

    # ── Attack 5: DCSync (T1003.006) ───────────────────────────────────────
    def dcsync(self, attacker_user="dev.lead"):
        """Simulate DCSync attack — replicate domain credentials."""
        events = [
            self._gen_event(4662, "Security",
                f"Directory replication requested by {attacker_user} (non-DC account)",
                "DC01", attacker_user, "critical",
                {"access_mask": "0x100", "properties": "Replicating Directory Changes All"}),
        ]

        result = AttackResult(
            "DCSync", "T1003.006", "Credential Access",
            success=True,
            details=f"{attacker_user} used DCSync to replicate password hashes from Domain Controller. "
                    f"All domain credentials compromised including krbtgt.",
            events=events,
            mitigations=[
                "Restrict Replicating Directory Changes permissions",
                "Monitor Event ID 4662 for replication requests from non-DC sources",
                "Use Microsoft Defender for Identity to detect DCSync",
                "Implement PAM (Privileged Access Management)",
                "Regular audit of AD delegation permissions",
            ]
        )
        self.attack_log.append(result)
        return result

    # ── Attack 6: Password Spraying (T1110.003) ───────────────────────────
    def password_spraying(self):
        """Simulate password spraying attack."""
        events = []
        for user in self.ad.users[:8]:
            events.append(self._gen_event(
                4625, "Security",
                f"Failed logon for {user.username} — password spray attempt",
                "DC01", user.username, "medium",
                {"logon_type": 3, "failure_reason": "Bad password"}
            ))

        # One success
        events.append(self._gen_event(
            4624, "Security",
            "Successful logon for fin.analyst — password spray succeeded",
            "DC01", "fin.analyst", "high",
            {"logon_type": 3, "password_used": "Spring2024!"}
        ))

        result = AttackResult(
            "Password Spraying", "T1110.003", "Credential Access",
            success=True,
            details="Sprayed common password 'Spring2024!' against all domain users. "
                    "Account fin.analyst compromised.",
            events=events,
            mitigations=[
                "Implement Azure AD Password Protection or similar banned password list",
                "Enable smart lockout policies",
                "Enforce MFA for all accounts",
                "Monitor for distributed failed logon attempts",
                "Implement fine-grained password policies",
            ]
        )
        self.attack_log.append(result)
        return result

    # ── Attack 7: LLMNR/NBT-NS Poisoning (T1557.001) ─────────────────────
    def llmnr_poisoning(self):
        """Simulate LLMNR/NBT-NS poisoning for hash capture."""
        events = [
            self._gen_event(0, "Network",
                "LLMNR query poisoned — NTLMv2 hash captured for fin.manager",
                "WS-FIN01", "fin.manager", "high",
                {"captured_hash": "NTLMv2", "protocol": "LLMNR"}),
        ]

        result = AttackResult(
            "LLMNR/NBT-NS Poisoning", "T1557.001", "Credential Access",
            success=True,
            details="Poisoned LLMNR broadcast to capture NTLMv2 hash of fin.manager. "
                    "Hash can be cracked offline or relayed.",
            events=events,
            mitigations=[
                "Disable LLMNR via Group Policy",
                "Disable NBT-NS on all network interfaces",
                "Enable SMB Signing on all systems",
                "Implement network segmentation",
                "Use DNS resolution exclusively",
            ]
        )
        self.attack_log.append(result)
        return result

    # ── Attack 8: Silver Ticket (T1558.002) ────────────────────────────────
    def silver_ticket(self):
        """Simulate Silver Ticket attack."""
        events = [
            self._gen_event(4624, "Security",
                "Service ticket forged for MSSQLSvc — Silver Ticket",
                "SRV-DB01", "svc_sql", "critical",
                {"ticket_type": "Silver Ticket", "service": "MSSQL"}),
        ]

        result = AttackResult(
            "Silver Ticket", "T1558.002", "Credential Access",
            success=True,
            details="Forged service ticket for MSSQL using svc_sql NTLM hash. "
                    "Direct access to SQL Server without touching Domain Controller.",
            events=events,
            mitigations=[
                "Implement PAC Validation for services",
                "Use gMSA for service accounts",
                "Rotate service account passwords frequently",
                "Monitor for service ticket anomalies",
            ]
        )
        self.attack_log.append(result)
        return result

    # ── Attack 9: DCShadow (T1207) ────────────────────────────────────────
    def dcshadow(self):
        """Simulate DCShadow attack — register rogue DC."""
        events = [
            self._gen_event(4742, "Security",
                "Computer account modified — SPN added for Directory Replication",
                "DC01", "admin", "critical",
                {"attack_type": "DCShadow", "rogue_dc": "WS-DEV01"}),
        ]

        result = AttackResult(
            "DCShadow", "T1207", "Defense Evasion",
            success=True,
            details="Registered rogue domain controller WS-DEV01 to push malicious AD changes "
                    "directly into replication stream, bypassing standard detection.",
            events=events,
            mitigations=[
                "Monitor for new DC registrations in AD",
                "Monitor nTDSDSA object creation",
                "Use Microsoft Defender for Identity",
                "Restrict who can modify computer SPNs",
            ]
        )
        self.attack_log.append(result)
        return result

    # ── Attack 10: Skeleton Key (T1556.001) ────────────────────────────────
    def skeleton_key(self):
        """Simulate Skeleton Key implant on DC."""
        events = [
            self._gen_event(7045, "System",
                "Suspicious driver loaded into LSASS on DC01 — Skeleton Key indicator",
                "DC01", "SYSTEM", "critical",
                {"driver": "msdte.dll", "target_process": "lsass.exe"}),
        ]

        result = AttackResult(
            "Skeleton Key", "T1556.001", "Persistence",
            success=True,
            details="Injected skeleton key into DC01 LSASS process. "
                    "Master password 'mimikatz' now works for any domain account alongside real password.",
            events=events,
            mitigations=[
                "Enable LSA Protection (RunAsPPL)",
                "Monitor for suspicious DLL loads into LSASS",
                "Implement Credential Guard on DCs",
                "Use two-factor authentication",
                "Regular DC restarts clear skeleton key from memory",
            ]
        )
        self.attack_log.append(result)
        return result

    # ── Attack 11: AdminSDHolder Abuse (T1078.002) ─────────────────────────
    def adminsdholder_abuse(self):
        """Simulate AdminSDHolder ACL persistence."""
        events = [
            self._gen_event(5136, "Security",
                "AdminSDHolder ACL modified — backdoor ACE added for dev.junior",
                "DC01", "admin", "critical",
                {"object": "CN=AdminSDHolder,CN=System", "modification": "ACE Added"}),
        ]

        result = AttackResult(
            "AdminSDHolder Abuse", "T1078.002", "Persistence",
            success=True,
            details="Modified AdminSDHolder ACL to grant dev.junior full control. "
                    "SDProp process will propagate these permissions to all protected groups every 60 minutes.",
            events=events,
            mitigations=[
                "Monitor modifications to AdminSDHolder container",
                "Regular ACL auditing of protected objects",
                "Monitor Event ID 5136 for directory service changes",
                "Implement JIT (Just-In-Time) privileged access",
            ]
        )
        self.attack_log.append(result)
        return result

    # ── Attack 12: GPO Abuse (T1484.001) ──────────────────────────────────
    def gpo_abuse(self):
        """Simulate Group Policy abuse for code execution."""
        events = [
            self._gen_event(5136, "Security",
                "GPO 'Workstation Security' modified — malicious scheduled task added",
                "DC01", "it.admin", "critical",
                {"gpo_name": "Workstation Security", "modification": "Scheduled Task added"}),
        ]

        result = AttackResult(
            "GPO Abuse", "T1484.001", "Privilege Escalation",
            success=True,
            details="Modified GPO to add malicious scheduled task that executes on all workstations. "
                    "Achieves code execution across all domain-joined systems in the OU.",
            events=events,
            mitigations=[
                "Restrict GPO modification permissions",
                "Monitor Group Policy changes (Event ID 5136)",
                "Implement GPO change approval workflow",
                "Use Advanced Group Policy Management (AGPM)",
                "Regularly audit GPO permissions and settings",
            ]
        )
        self.attack_log.append(result)
        return result

    def run_all_attacks(self):
        """Execute all attack simulations."""
        results = [
            self.kerberoasting(),
            self.asrep_roasting(),
            self.pass_the_hash(),
            self.golden_ticket(),
            self.dcsync(),
            self.password_spraying(),
            self.llmnr_poisoning(),
            self.silver_ticket(),
            self.dcshadow(),
            self.skeleton_key(),
            self.adminsdholder_abuse(),
            self.gpo_abuse(),
        ]
        return results

    def get_attack_summary(self):
        """Get summary of all executed attacks."""
        return {
            "total_attacks": len(self.attack_log),
            "successful": sum(1 for a in self.attack_log if a.success),
            "failed": sum(1 for a in self.attack_log if not a.success),
            "total_events": sum(len(a.events) for a in self.attack_log),
            "tactics_covered": list(set(a.tactic for a in self.attack_log)),
            "techniques": [{"id": a.technique_id, "name": a.name} for a in self.attack_log],
        }
