"""
Active Directory Attack & Defense Lab — AD Environment Simulator
Simulates a realistic enterprise Active Directory environment.
"""

import random
import hashlib
from datetime import datetime, timedelta


class ADUser:
    """Represents an Active Directory user account."""
    def __init__(self, username, full_name, ou, groups, is_admin=False, spn=None,
                 password_last_set=None, last_logon=None, enabled=True,
                 dont_require_preauth=False, description=""):
        self.username = username
        self.full_name = full_name
        self.ou = ou
        self.groups = groups
        self.is_admin = is_admin
        self.spn = spn  # Service Principal Name (for Kerberoasting)
        self.password_last_set = password_last_set or (datetime.utcnow() - timedelta(days=random.randint(1, 365)))
        self.last_logon = last_logon or (datetime.utcnow() - timedelta(hours=random.randint(1, 720)))
        self.enabled = enabled
        self.dont_require_preauth = dont_require_preauth
        self.description = description
        self.ntlm_hash = hashlib.md5(f"{username}:password123".encode()).hexdigest()
        self.logon_count = random.randint(10, 5000)
        self.bad_password_count = 0
        self.locked_out = False

    def to_dict(self):
        return {
            "username": self.username, "full_name": self.full_name,
            "ou": self.ou, "groups": self.groups, "is_admin": self.is_admin,
            "spn": self.spn, "enabled": self.enabled,
            "password_age_days": (datetime.utcnow() - self.password_last_set).days,
            "dont_require_preauth": self.dont_require_preauth,
            "logon_count": self.logon_count,
        }


class ADComputer:
    """Represents a domain-joined computer."""
    def __init__(self, name, os_version, ou, ip, role="workstation"):
        self.name = name
        self.os_version = os_version
        self.ou = ou
        self.ip = ip
        self.role = role  # workstation, server, domain_controller
        self.services = []
        self.local_admins = []
        self.logged_on_users = []

    def to_dict(self):
        return {
            "name": self.name, "os": self.os_version, "ou": self.ou,
            "ip": self.ip, "role": self.role, "services": self.services,
            "local_admins": self.local_admins,
        }


class GPO:
    """Represents a Group Policy Object."""
    def __init__(self, name, linked_ou, settings):
        self.name = name
        self.linked_ou = linked_ou
        self.settings = settings  # dict of policy settings

    def to_dict(self):
        return {"name": self.name, "linked_ou": self.linked_ou, "settings": self.settings}


class ADEnvironment:
    """Simulates a complete Active Directory environment."""

    def __init__(self, domain_name="corp.contoso.com"):
        self.domain_name = domain_name
        self.domain_sid = "S-1-5-21-3623811015-3361044348-30300820"
        self.forest_name = "contoso.com"
        self.domain_functional_level = "Windows Server 2019"
        self.users = []
        self.computers = []
        self.groups = {}
        self.ous = []
        self.gpos = []
        self.trusts = []
        self._build_environment()

    def _build_environment(self):
        """Construct the full AD environment."""
        self._create_ous()
        self._create_groups()
        self._create_users()
        self._create_computers()
        self._create_gpos()

    def _create_ous(self):
        self.ous = [
            "OU=Domain Controllers,DC=corp,DC=contoso,DC=com",
            "OU=IT,DC=corp,DC=contoso,DC=com",
            "OU=Finance,DC=corp,DC=contoso,DC=com",
            "OU=HR,DC=corp,DC=contoso,DC=com",
            "OU=Engineering,DC=corp,DC=contoso,DC=com",
            "OU=Executives,DC=corp,DC=contoso,DC=com",
            "OU=Service Accounts,DC=corp,DC=contoso,DC=com",
            "OU=Servers,DC=corp,DC=contoso,DC=com",
            "OU=Workstations,DC=corp,DC=contoso,DC=com",
        ]

    def _create_groups(self):
        self.groups = {
            "Domain Admins": {"members": ["admin", "it.admin"], "type": "Global", "critical": True},
            "Enterprise Admins": {"members": ["admin"], "type": "Universal", "critical": True},
            "Schema Admins": {"members": ["admin"], "type": "Universal", "critical": True},
            "Server Operators": {"members": ["svc_backup"], "type": "BuiltIn", "critical": True},
            "Account Operators": {"members": ["it.admin"], "type": "BuiltIn", "critical": True},
            "IT Admins": {"members": ["it.admin", "it.helpdesk"], "type": "Global", "critical": False},
            "Finance Users": {"members": ["fin.analyst", "fin.manager", "cfo"], "type": "Global", "critical": False},
            "HR Users": {"members": ["hr.specialist", "hr.director"], "type": "Global", "critical": False},
            "Engineering": {"members": ["dev.lead", "dev.junior", "devops"], "type": "Global", "critical": False},
            "VPN Users": {"members": ["fin.analyst", "dev.lead", "hr.specialist"], "type": "Global", "critical": False},
            "Remote Desktop Users": {"members": ["it.admin", "it.helpdesk", "dev.lead"], "type": "Global", "critical": False},
        }

    def _create_users(self):
        user_definitions = [
            ("admin", "Domain Administrator", "OU=IT", ["Domain Admins", "Enterprise Admins", "Schema Admins"], True),
            ("it.admin", "IT Administrator", "OU=IT", ["Domain Admins", "IT Admins", "Account Operators"], True),
            ("it.helpdesk", "IT Helpdesk", "OU=IT", ["IT Admins", "Remote Desktop Users"], False),
            ("fin.analyst", "Finance Analyst", "OU=Finance", ["Finance Users", "VPN Users"], False),
            ("fin.manager", "Finance Manager", "OU=Finance", ["Finance Users"], False),
            ("cfo", "Chief Financial Officer", "OU=Executives", ["Finance Users"], False),
            ("hr.specialist", "HR Specialist", "OU=HR", ["HR Users", "VPN Users"], False),
            ("hr.director", "HR Director", "OU=HR", ["HR Users"], False),
            ("dev.lead", "Development Lead", "OU=Engineering", ["Engineering", "VPN Users", "Remote Desktop Users"], False),
            ("dev.junior", "Junior Developer", "OU=Engineering", ["Engineering"], False),
            ("devops", "DevOps Engineer", "OU=Engineering", ["Engineering"], False),
            ("ceo", "Chief Executive Officer", "OU=Executives", [], False),
        ]

        # Service accounts with SPNs (vulnerable to Kerberoasting)
        svc_accounts = [
            ("svc_sql", "SQL Service Account", "OU=Service Accounts", ["Server Operators"],
             False, "MSSQLSvc/SRV-DB01.corp.contoso.com:1433"),
            ("svc_backup", "Backup Service Account", "OU=Service Accounts", ["Server Operators"],
             False, "backupexec/SRV-BACKUP01.corp.contoso.com"),
            ("svc_web", "Web Service Account", "OU=Service Accounts", [],
             False, "HTTP/SRV-WEB01.corp.contoso.com"),
            ("svc_exchange", "Exchange Service Account", "OU=Service Accounts", [],
             False, "exchangeMDB/SRV-MAIL01.corp.contoso.com"),
        ]

        for uname, fname, ou, groups, is_admin in user_definitions:
            user = ADUser(uname, fname, ou, groups, is_admin)
            self.users.append(user)

        for uname, fname, ou, groups, is_admin, spn in svc_accounts:
            user = ADUser(uname, fname, ou, groups, is_admin, spn=spn)
            self.users.append(user)

        # Set one user vulnerable to AS-REP Roasting
        for u in self.users:
            if u.username == "fin.analyst":
                u.dont_require_preauth = True
                break

    def _create_computers(self):
        computer_defs = [
            ("DC01", "Windows Server 2019", "OU=Domain Controllers", "10.0.1.10", "domain_controller"),
            ("DC02", "Windows Server 2019", "OU=Domain Controllers", "10.0.1.11", "domain_controller"),
            ("SRV-FILE01", "Windows Server 2019", "OU=Servers", "10.0.1.20", "server"),
            ("SRV-DB01", "Windows Server 2019", "OU=Servers", "10.0.1.21", "server"),
            ("SRV-WEB01", "Windows Server 2019", "OU=Servers", "10.0.1.22", "server"),
            ("SRV-MAIL01", "Windows Server 2019", "OU=Servers", "10.0.1.23", "server"),
            ("WS-IT01", "Windows 11 Enterprise", "OU=Workstations", "10.0.2.10", "workstation"),
            ("WS-FIN01", "Windows 11 Enterprise", "OU=Workstations", "10.0.2.20", "workstation"),
            ("WS-HR01", "Windows 10 Enterprise", "OU=Workstations", "10.0.2.30", "workstation"),
            ("WS-DEV01", "Windows 11 Enterprise", "OU=Workstations", "10.0.2.40", "workstation"),
            ("WS-EXEC01", "Windows 11 Enterprise", "OU=Workstations", "10.0.2.50", "workstation"),
        ]

        for name, os_ver, ou, ip, role in computer_defs:
            comp = ADComputer(name, os_ver, ou, ip, role)
            self.computers.append(comp)

        # Set local admins and services
        for comp in self.computers:
            if comp.role == "domain_controller":
                comp.local_admins = ["admin", "it.admin"]
                comp.services = ["DNS", "LDAP", "Kerberos", "NTDS", "GPO"]
            elif comp.role == "server":
                comp.local_admins = ["admin", "it.admin", "svc_backup"]
                if "DB" in comp.name:
                    comp.services = ["MSSQL", "SQLAgent"]
                elif "WEB" in comp.name:
                    comp.services = ["IIS", "HTTP"]
                elif "MAIL" in comp.name:
                    comp.services = ["Exchange", "SMTP"]
                else:
                    comp.services = ["FileShare", "DFS"]
            else:
                comp.local_admins = ["admin", "it.admin"]

    def _create_gpos(self):
        self.gpos = [
            GPO("Default Domain Policy", "DC=corp,DC=contoso,DC=com", {
                "password_min_length": 8,
                "password_complexity": True,
                "password_max_age_days": 90,
                "account_lockout_threshold": 5,
                "account_lockout_duration_min": 30,
            }),
            GPO("Server Hardening", "OU=Servers", {
                "disable_guest_account": True,
                "audit_logon_events": True,
                "restrict_remote_desktop": True,
                "windows_firewall_enabled": True,
            }),
            GPO("Workstation Security", "OU=Workstations", {
                "applocker_enabled": False,    # Misconfiguration!
                "powershell_logging": False,   # Misconfiguration!
                "windows_defender_enabled": True,
                "usb_storage_blocked": False,  # Misconfiguration!
            }),
        ]

    def get_user(self, username):
        for u in self.users:
            if u.username == username:
                return u
        return None

    def get_admin_users(self):
        return [u for u in self.users if u.is_admin or "Domain Admins" in u.groups]

    def get_kerberoastable_users(self):
        return [u for u in self.users if u.spn]

    def get_asrep_roastable_users(self):
        return [u for u in self.users if u.dont_require_preauth]

    def get_environment_summary(self):
        return {
            "domain": self.domain_name,
            "forest": self.forest_name,
            "functional_level": self.domain_functional_level,
            "users": len(self.users),
            "computers": len(self.computers),
            "groups": len(self.groups),
            "ous": len(self.ous),
            "gpos": len(self.gpos),
            "domain_admins": len(self.get_admin_users()),
            "kerberoastable": len(self.get_kerberoastable_users()),
            "asrep_roastable": len(self.get_asrep_roastable_users()),
        }
