"""
Active Directory Attack & Defense Lab — Defense & Hardening Module
CIS Benchmark auditing, GPO analysis, and hardening recommendations.
"""


class ADDefenseAdvisor:
    """Audits AD environment and provides hardening recommendations."""

    def __init__(self, ad_env):
        self.ad = ad_env
        self.findings = []
        self.score = 100

    def run_full_audit(self):
        """Run comprehensive security audit."""
        self.findings = []
        self.score = 100
        self._audit_password_policy()
        self._audit_privileged_accounts()
        self._audit_service_accounts()
        self._audit_gpo_settings()
        self._audit_kerberos_settings()
        self._audit_network_security()
        self._audit_monitoring()
        return {
            "score": max(self.score, 0),
            "grade": self._get_grade(),
            "findings": self.findings,
            "total_findings": len(self.findings),
            "critical": sum(1 for f in self.findings if f["severity"] == "critical"),
            "high": sum(1 for f in self.findings if f["severity"] == "high"),
            "medium": sum(1 for f in self.findings if f["severity"] == "medium"),
            "low": sum(1 for f in self.findings if f["severity"] == "low"),
        }

    def _add_finding(self, title, severity, category, description, remediation, cis_ref=""):
        deductions = {"critical": 15, "high": 10, "medium": 5, "low": 2}
        self.score -= deductions.get(severity, 0)
        self.findings.append({
            "title": title, "severity": severity, "category": category,
            "description": description, "remediation": remediation,
            "cis_reference": cis_ref,
        })

    def _get_grade(self):
        if self.score >= 90: return "A"
        if self.score >= 80: return "B"
        if self.score >= 70: return "C"
        if self.score >= 60: return "D"
        return "F"

    def _audit_password_policy(self):
        default_gpo = next((g for g in self.ad.gpos if "Default Domain" in g.name), None)
        if not default_gpo:
            return

        settings = default_gpo.settings
        if settings.get("password_min_length", 0) < 14:
            self._add_finding(
                "Weak Password Minimum Length",
                "high", "Password Policy",
                f"Password minimum length is {settings.get('password_min_length', 0)} characters. "
                "CIS recommends minimum 14 characters.",
                "Set password minimum length to 14+ via Default Domain Policy GPO.",
                "CIS 1.1.4"
            )

        if settings.get("password_max_age_days", 0) > 60:
            self._add_finding(
                "Password Max Age Too Long",
                "medium", "Password Policy",
                f"Password maximum age is {settings.get('password_max_age_days')} days.",
                "Set password maximum age to 60 days or implement passwordless authentication.",
                "CIS 1.1.2"
            )

    def _audit_privileged_accounts(self):
        admins = self.ad.get_admin_users()
        if len(admins) > 2:
            self._add_finding(
                "Excessive Domain Admin Accounts",
                "high", "Privileged Access",
                f"Found {len(admins)} accounts in Domain Admins group. "
                "Excessive privileged accounts increase attack surface.",
                "Reduce Domain Admin membership to max 2 break-glass accounts. "
                "Use delegated admin groups for daily operations.",
                "CIS 5.1"
            )

        for user in self.ad.users:
            if user.is_admin and (datetime.utcnow() - user.password_last_set).days > 90:
                self._add_finding(
                    f"Stale Admin Password — {user.username}",
                    "high", "Privileged Access",
                    f"Admin account {user.username} password is "
                    f"{(datetime.utcnow() - user.password_last_set).days} days old.",
                    f"Immediately rotate password for {user.username}.",
                    "CIS 5.2"
                )

    def _audit_service_accounts(self):
        svc_accounts = self.ad.get_kerberoastable_users()
        if svc_accounts:
            self._add_finding(
                f"Kerberoastable Service Accounts ({len(svc_accounts)})",
                "critical", "Service Accounts",
                f"Found {len(svc_accounts)} accounts with SPNs vulnerable to Kerberoasting: "
                f"{', '.join(u.username for u in svc_accounts)}",
                "Convert service accounts to Group Managed Service Accounts (gMSA). "
                "If not possible, set 25+ character random passwords and rotate every 30 days.",
                "CIS 5.4"
            )

        asrep = self.ad.get_asrep_roastable_users()
        if asrep:
            self._add_finding(
                f"AS-REP Roastable Accounts ({len(asrep)})",
                "critical", "Service Accounts",
                f"Accounts with 'Do not require Kerberos pre-authentication': "
                f"{', '.join(u.username for u in asrep)}",
                "Enable Kerberos pre-authentication for all accounts immediately.",
                "CIS 5.5"
            )

    def _audit_gpo_settings(self):
        for gpo in self.ad.gpos:
            settings = gpo.settings
            if settings.get("applocker_enabled") is False:
                self._add_finding(
                    f"AppLocker Disabled — {gpo.name}",
                    "high", "GPO Configuration",
                    f"AppLocker is not enabled in GPO '{gpo.name}'. "
                    "Without application whitelisting, users can execute arbitrary software.",
                    "Enable AppLocker with default rules and audit mode first.",
                    "CIS 2.3.1"
                )

            if settings.get("powershell_logging") is False:
                self._add_finding(
                    f"PowerShell Logging Disabled — {gpo.name}",
                    "critical", "GPO Configuration",
                    f"PowerShell Script Block Logging is disabled in '{gpo.name}'. "
                    "This is critical for detecting PowerShell-based attacks.",
                    "Enable PowerShell Script Block Logging, Module Logging, and Transcription.",
                    "CIS 18.9.100"
                )

            if settings.get("usb_storage_blocked") is False:
                self._add_finding(
                    f"USB Storage Not Blocked — {gpo.name}",
                    "medium", "GPO Configuration",
                    f"Removable storage is allowed in '{gpo.name}'.",
                    "Block removable storage devices via GPO or DLP solution.",
                    "CIS 18.8.22"
                )

    def _audit_kerberos_settings(self):
        self._add_finding(
            "RC4 Encryption Still Allowed for Kerberos",
            "high", "Kerberos Security",
            "RC4 encryption (0x17) is still allowed for Kerberos tickets. "
            "RC4 tickets can be cracked more easily than AES.",
            "Disable RC4 encryption. Ensure all systems support AES-256 before making this change.",
            "CIS 18.3.5"
        )

    def _audit_network_security(self):
        self._add_finding(
            "LLMNR Not Disabled",
            "high", "Network Security",
            "LLMNR (Link-Local Multicast Name Resolution) is not disabled via GPO. "
            "This allows LLMNR poisoning attacks for credential theft.",
            "Disable LLMNR via Computer Configuration > Administrative Templates > Network > DNS Client > Turn Off Multicast Name Resolution.",
            "CIS 18.5.4.2"
        )

    def _audit_monitoring(self):
        self._add_finding(
            "Advanced Audit Policy Not Configured",
            "medium", "Monitoring",
            "Advanced audit policies should be configured for comprehensive security monitoring. "
            "Without proper auditing, attacks cannot be detected.",
            "Enable audit policies: Logon/Logoff, Object Access, Privilege Use, Policy Change, Account Management.",
            "CIS 17.1-17.9"
        )

    def get_hardening_checklist(self):
        """Generate a prioritized hardening checklist."""
        return [
            {"priority": 1, "action": "Enable Kerberos pre-authentication for all accounts", "category": "Credential Security"},
            {"priority": 2, "action": "Convert service accounts to gMSA", "category": "Service Accounts"},
            {"priority": 3, "action": "Enable PowerShell Script Block Logging", "category": "Monitoring"},
            {"priority": 4, "action": "Reduce Domain Admin group membership", "category": "Privileged Access"},
            {"priority": 5, "action": "Disable LLMNR and NBT-NS", "category": "Network Security"},
            {"priority": 6, "action": "Implement LAPS for local admin passwords", "category": "Credential Security"},
            {"priority": 7, "action": "Enable AppLocker on all workstations", "category": "Application Control"},
            {"priority": 8, "action": "Disable RC4 for Kerberos encryption", "category": "Kerberos Security"},
            {"priority": 9, "action": "Configure Advanced Audit Policies", "category": "Monitoring"},
            {"priority": 10, "action": "Implement tiered administration model", "category": "Architecture"},
            {"priority": 11, "action": "Block USB storage via GPO", "category": "Data Protection"},
            {"priority": 12, "action": "Deploy Microsoft Defender for Identity", "category": "Detection"},
        ]


# Need datetime for password age calculation
from datetime import datetime
