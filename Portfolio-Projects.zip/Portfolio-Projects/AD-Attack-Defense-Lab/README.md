# 🏰 Active Directory Attack & Defense Lab

[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![MITRE ATT&CK](https://img.shields.io/badge/MITRE-ATT%26CK-red?style=for-the-badge)](https://attack.mitre.org)
[![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)](LICENSE)

A comprehensive Active Directory security laboratory simulating enterprise AD environments with realistic attack scenarios, detection mechanisms, and hardening recommendations. Demonstrates deep understanding of AD security, Kerberos attacks, privilege escalation paths, and defensive strategies.

## 🏗️ Architecture

```
┌──────────────────────────────────────────────────┐
│            AD Attack & Defense Lab                │
├────────────┬────────────┬────────────┬───────────┤
│  AD        │  Attack    │  Detection │  Defense  │
│  Simulator │  Engine    │  Module    │  Advisor  │
├────────────┼────────────┼────────────┼───────────┤
│ Domain     │ Kerberoast │ Event Log  │ GPO Audit │
│ Users/OUs  │ Pass Hash  │ Anomaly    │ Hardening │
│ Groups     │ Golden Tkt │ Sigma Rule │ Benchmark │
│ GPOs       │ BloodHound │ Alert      │ Report    │
└────────────┴────────────┴────────────┴───────────┘
```

## ✨ Features

- **AD Environment Simulation** — Full domain controller, OUs, users, groups, GPOs
- **12+ Attack Scenarios** — Kerberoasting, Pass-the-Hash, Golden Ticket, DCSync, AS-REP Roasting, etc.
- **Detection Engine** — Event log analysis, anomaly detection, Sigma-style rules
- **BloodHound-Style Analysis** — Attack path visualization and privilege escalation mapping
- **Defense Advisor** — CIS Benchmark checks, GPO auditing, hardening recommendations
- **Web Dashboard** — Real-time attack/defense visualization with Flask

## 📁 Project Structure

```
AD-Attack-Defense-Lab/
├── app.py                  # Flask dashboard
├── ad_simulator.py         # AD environment simulation
├── attacks.py              # Attack scenario engine
├── detection.py            # Detection & alerting
├── defense.py              # Hardening & recommendations
├── bloodhound_analyzer.py  # Attack path analysis
├── models.py               # Data models
├── config.py               # Configuration
├── requirements.txt
└── .gitignore
```

## 🚀 Quick Start

```bash
pip install -r requirements.txt
python app.py
# Visit http://localhost:5001
```

## 📜 License
MIT License — **Koventhan M**
