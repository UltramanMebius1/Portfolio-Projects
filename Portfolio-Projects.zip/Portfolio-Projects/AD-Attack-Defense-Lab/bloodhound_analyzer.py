"""
Active Directory Attack & Defense Lab — BloodHound-Style Attack Path Analyzer
Maps privilege escalation paths and attack graphs in the AD environment.
"""

from collections import defaultdict, deque


class AttackPathAnalyzer:
    """Analyzes Active Directory for attack paths and privilege escalation routes."""

    def __init__(self, ad_env):
        self.ad = ad_env
        self.graph = defaultdict(list)  # adjacency list
        self._build_graph()

    def _build_graph(self):
        """Build attack graph from AD environment relationships."""
        # User → Group membership edges
        for user in self.ad.users:
            for group in user.groups:
                self.graph[f"user:{user.username}"].append({
                    "target": f"group:{group}",
                    "relationship": "MemberOf",
                    "risk": "medium" if "Admin" in group else "low",
                })

        # Group → Group nesting
        for group_name, group_info in self.ad.groups.items():
            if group_info.get("critical"):
                self.graph[f"group:{group_name}"].append({
                    "target": "privilege:DomainAdmin",
                    "relationship": "HasPrivilege",
                    "risk": "critical",
                })

        # Computer → Local Admin edges
        for comp in self.ad.computers:
            for admin_user in comp.local_admins:
                self.graph[f"user:{admin_user}"].append({
                    "target": f"computer:{comp.name}",
                    "relationship": "AdminTo",
                    "risk": "high" if comp.role == "domain_controller" else "medium",
                })

            # Logged-on users (session data)
            for user in comp.logged_on_users:
                self.graph[f"computer:{comp.name}"].append({
                    "target": f"user:{user}",
                    "relationship": "HasSession",
                    "risk": "medium",
                })

        # Service account → Computer (SPN relationship)
        for user in self.ad.users:
            if user.spn:
                host = user.spn.split("/")[1].split(".")[0] if "/" in user.spn else ""
                if host:
                    self.graph[f"user:{user.username}"].append({
                        "target": f"computer:{host}",
                        "relationship": "ServiceOn",
                        "risk": "high",
                    })

    def find_paths_to_da(self, start_user):
        """Find all paths from a user to Domain Admin."""
        paths = []
        visited = set()
        queue = deque([(f"user:{start_user}", [f"user:{start_user}"])])

        while queue:
            current, path = queue.popleft()
            if current in visited:
                continue
            visited.add(current)

            if current == "privilege:DomainAdmin":
                paths.append(path)
                continue

            for edge in self.graph.get(current, []):
                target = edge["target"]
                if target not in visited:
                    queue.append((target, path + [f"--[{edge['relationship']}]--> {target}"]))

        return paths

    def find_all_attack_paths(self):
        """Find attack paths for all non-admin users."""
        attack_paths = {}
        for user in self.ad.users:
            if not user.is_admin:
                paths = self.find_paths_to_da(user.username)
                if paths:
                    attack_paths[user.username] = {
                        "paths": paths,
                        "shortest_path_length": min(len(p) for p in paths),
                        "total_paths": len(paths),
                    }
        return attack_paths

    def get_high_value_targets(self):
        """Identify high-value targets in the environment."""
        targets = []

        # Domain Controllers
        for comp in self.ad.computers:
            if comp.role == "domain_controller":
                targets.append({
                    "name": comp.name, "type": "Domain Controller",
                    "risk": "critical",
                    "reason": "Hosts NTDS.dit, Kerberos KDC, and AD database",
                })

        # Domain Admins
        for user in self.ad.get_admin_users():
            targets.append({
                "name": user.username, "type": "Domain Admin",
                "risk": "critical",
                "reason": "Full control over the entire domain",
            })

        # Kerberoastable accounts
        for user in self.ad.get_kerberoastable_users():
            targets.append({
                "name": user.username, "type": "Kerberoastable Account",
                "risk": "high",
                "reason": f"SPN: {user.spn} — vulnerable to offline cracking",
            })

        # AS-REP Roastable
        for user in self.ad.get_asrep_roastable_users():
            targets.append({
                "name": user.username, "type": "AS-REP Roastable",
                "risk": "high",
                "reason": "Pre-authentication disabled — hash can be requested without credentials",
            })

        return targets

    def get_graph_stats(self):
        """Get statistics about the attack graph."""
        total_edges = sum(len(edges) for edges in self.graph.values())
        risk_counts = defaultdict(int)
        relationship_counts = defaultdict(int)

        for edges in self.graph.values():
            for edge in edges:
                risk_counts[edge["risk"]] += 1
                relationship_counts[edge["relationship"]] += 1

        return {
            "total_nodes": len(self.graph),
            "total_edges": total_edges,
            "risk_distribution": dict(risk_counts),
            "relationship_types": dict(relationship_counts),
        }

    def generate_report(self):
        """Generate comprehensive attack path analysis report."""
        attack_paths = self.find_all_attack_paths()
        hvt = self.get_high_value_targets()
        stats = self.get_graph_stats()

        return {
            "graph_stats": stats,
            "high_value_targets": hvt,
            "attack_paths": {
                user: {
                    "total_paths": info["total_paths"],
                    "shortest_path": info["shortest_path_length"],
                    "paths": [" → ".join(p) for p in info["paths"][:3]],  # Top 3 paths
                }
                for user, info in attack_paths.items()
            },
            "most_dangerous_users": sorted(
                attack_paths.items(),
                key=lambda x: x[1]["shortest_path_length"]
            )[:5],
            "summary": {
                "users_with_da_paths": len(attack_paths),
                "total_attack_paths": sum(i["total_paths"] for i in attack_paths.values()),
                "critical_targets": sum(1 for t in hvt if t["risk"] == "critical"),
            },
        }
