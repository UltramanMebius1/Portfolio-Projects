# ☁️ Azure Cloud File Storage Simulator
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge)](https://python.org)

Simulated Azure Blob Storage dashboard featuring local file uploads, container isolation, SQLite metadata storage, Azure AD RBAC authentication mapping, and real-time operations logging.

## Features
- Simulated Azure Blob Storage container management (Public vs Private)
- Role-Based Access Control (RBAC) mapping (Owner, Contributor, Reader)
- File upload, download, delete, and link generation simulations
- Centralized operations log mimicking Azure Monitor Diagnostic logs
- Azure Advisor recommendation dashboard (cost, security alerts)

## Quick Start
```bash
pip install -r requirements.txt
python app.py  # http://localhost:5013
```
## License — MIT — **Koventhan M**
