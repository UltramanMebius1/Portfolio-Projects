"""
Azure Cloud File Storage Simulator — Complete Flask Application
Simulates Azure Blob Storage, Azure AD RBAC permissions, diagnostic logging, and container management.
"""

import os
import random
from datetime import datetime, timedelta
from flask import Flask, render_template_string, request, redirect, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = "azure-file-storage-secret"
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'azure_storage.db')}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)


# ── Models ─────────────────────────────────────────────────────────────────

class StorageContainer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    access_type = db.Column(db.String(20), default="Private")  # Private, Blob, Container
    blobs = db.relationship("BlobAsset", backref="container", lazy=True, cascade="all, delete-orphan")


class BlobAsset(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    size_bytes = db.Column(db.Integer, nullable=False)
    content_type = db.Column(db.String(100), default="application/octet-stream")
    access_tier = db.Column(db.String(10), default="Hot")  # Hot, Cool, Archive
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    container_id = db.Column(db.Integer, db.ForeignKey("storage_container.id"), nullable=False)


class DiagnosticLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    operation = db.Column(db.String(100), nullable=False)  # GetBlob, PutBlob, DeleteBlob, etc.
    status = db.Column(db.String(20), default="Success")  # Success, Failed, Denied
    requested_by = db.Column(db.String(100))
    role_used = db.Column(db.String(50))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    details = db.Column(db.Text)


def seed_data():
    if StorageContainer.query.count() > 0:
        return

    c1 = StorageContainer(name="images", access_type="Blob")
    c2 = StorageContainer(name="documents", access_type="Private")
    c3 = StorageContainer(name="billing", access_type="Private")
    db.session.add_all([c1, c2, c3])
    db.session.flush()

    b1 = BlobAsset(name="profile_banner.jpg", size_bytes=102400, content_type="image/jpeg", access_tier="Hot", container_id=c1.id)
    b2 = BlobAsset(name="azure_ad_architecture.pdf", size_bytes=2048500, content_type="application/pdf", access_tier="Hot", container_id=c2.id)
    b3 = BlobAsset(name="annual_report_2024.xlsx", size_bytes=512000, content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", access_tier="Cool", container_id=c3.id)
    db.session.add_all([b1, b2, b3])

    logs = [
        DiagnosticLog(operation="CreateContainer", status="Success", requested_by="admin@corp.contoso.com", role_used="Owner", details="Created container 'images'"),
        DiagnosticLog(operation="CreateContainer", status="Success", requested_by="admin@corp.contoso.com", role_used="Owner", details="Created container 'documents'"),
        DiagnosticLog(operation="PutBlob", status="Success", requested_by="developer@corp.contoso.com", role_used="Contributor", details="Uploaded blob 'profile_banner.jpg' to container 'images'"),
    ]
    db.session.add_all(logs)
    db.session.commit()


# ── Templates ──────────────────────────────────────────────────────────────

TMPL = """
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Azure Cloud File Storage Simulator</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#070b19;--bg2:#0f172a;--card:#1e293b;--text:#f8fafc;--dim:#94a3b8;--blue:#007fff;--red:#e81123;--orange:#ff8c00;--green:#107c41;--border:#334155;--purple:#8660a9;--cyan:#00b7c3}
body{font-family:'Segoe UI',sans-serif;background:var(--bg);color:var(--text)}
.header{background:linear-gradient(135deg,#0f172a,#070b19);border-bottom:1px solid var(--border);padding:16px 32px;display:flex;align-items:center;justify-content:space-between}
.header h1{font-size:1.4rem;background:linear-gradient(135deg,var(--blue),var(--cyan));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav{background:var(--bg2);border-bottom:1px solid var(--border);display:flex;padding:0 32px}
.nav a{color:var(--dim);text-decoration:none;padding:12px 18px;font-size:.85rem;font-weight:500;border-bottom:2px solid transparent;transition:.2s}
.nav a:hover,.nav a.active{color:var(--blue);border-bottom-color:var(--blue)}
.container{max-width:1400px;margin:0 auto;padding:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:24px}
.stat{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:20px}
.stat .label{font-size:.7rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}
.stat .val{font-size:1.8rem;font-weight:700}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:24px}
.card h2{font-size:1.1rem;margin-bottom:16px}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:10px;font-size:.7rem;text-transform:uppercase;color:var(--dim);border-bottom:1px solid var(--border)}
td{padding:10px;border-bottom:1px solid var(--border);font-size:.85rem}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:600;text-transform:uppercase}
.badge.public{background:rgba(0,183,195,.12);color:var(--cyan);border:1px solid rgba(0,183,195,.25)}
.badge.private{background:rgba(232,17,35,.12);color:var(--red);border:1px solid rgba(232,17,35,.25)}
.btn{padding:8px 16px;border-radius:8px;border:none;cursor:pointer;font-size:.85rem;font-weight:500;transition:.2s;text-decoration:none;display:inline-block;margin:2px}
.btn-azure{background:var(--blue);color:#fff}.btn-red{background:var(--red);color:#fff}.btn-green{background:var(--green);color:#fff}
.btn-sm{padding:4px 12px;font-size:.75rem}
.form-group{margin-bottom:12px}
label{display:block;margin-bottom:6px;font-size:.85rem;color:var(--dim)}
input[type=text],input[type=number],select{width:100%;padding:10px 14px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text);font-size:.9rem}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px}@media(max-width:768px){.two-col{grid-template-columns:1fr}}
.flash{padding:12px;border-radius:8px;margin-bottom:16px;background:rgba(0,127,255,.12);border:1px solid rgba(0,127,255,.3);color:var(--blue);font-size:.85rem}
</style></head><body>
<div class="header"><h1>☁️ Azure Cloud File Storage Simulator</h1><span style="color:var(--dim);font-size:.8rem">Azure Portal Interface</span></div>
<div class="nav">
    <a href="/" class="{{ 'active' if page=='dash' }}">Overview / Storage Accounts</a>
    <a href="/rbac" class="{{ 'active' if page=='rbac' }}">Access Control (IAM)</a>
    <a href="/logs" class="{{ 'active' if page=='logs' }}">Diagnostic Logs</a>
</div>
<div class="container">{% if flash %}<div class="flash">{{ flash }}</div>{% endif %}{% block c %}{% endblock %}</div>
</body></html>
"""

# ── Active AD Session User (Simulated OAuth) ──────────────────────────────

ad_user = {
    "email": "developer@corp.contoso.com",
    "role": "Contributor"  # Owner, Contributor, Reader
}

# ── Routes ─────────────────────────────────────────────────────────────────

@app.route("/")
def dashboard():
    containers = StorageContainer.query.all()
    total_blobs = BlobAsset.query.count()
    total_size = sum(b.size_bytes for b in BlobAsset.query.all())

    # Formatted size
    size_str = f"{total_size / 1024:.1f} KB" if total_size < 1048576 else f"{total_size / 1048576:.1f} MB"

    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="grid">
    <div class="stat"><div class="label">Blob Containers</div><div class="val" style="color:var(--blue)">{{ containers|length }}</div></div>
    <div class="stat"><div class="label">Total Blobs</div><div class="val" style="color:var(--cyan)">{{ total_blobs }}</div></div>
    <div class="stat"><div class="label">Total Size</div><div class="val" style="color:var(--green)">{{ size_str }}</div></div>
    <div class="stat"><div class="label">Identity (Azure AD)</div><div class="val" style="font-size:.9rem;color:var(--purple)">{{ user.email }} ({{ user.role }})</div></div>
</div>
<div class="two-col">
    <div class="card">
        <h2>📁 Blob Containers</h2>
        <table><thead><tr><th>Container Name</th><th>Access Policy</th><th>Blobs Count</th><th>Action</th></tr></thead><tbody>
        {% for c in containers %}
        <tr>
            <td><strong><a href="/container/{{ c.id }}" style="color:var(--blue);text-decoration:none">{{ c.name }}</a></strong></td>
            <td><span class="badge {% if c.access_type == 'Private' %}private{% else %}public{% endif %}">{{ c.access_type }}</span></td>
            <td>{{ c.blobs|length }} blob(s)</td>
            <td><a href="/delete-container/{{ c.id }}" class="btn btn-sm btn-red">Delete</a></td>
        </tr>{% endfor %}</tbody></table>
    </div>
    <div class="card">
        <h2>➕ Create New Container</h2>
        <form action="/create-container" method="POST">
            <div class="form-group"><label>Container Name</label><input type="text" name="name" required></div>
            <div class="form-group">
                <label>Public Access Level</label>
                <select name="access_type">
                    <option value="Private">Private (no anonymous access)</option>
                    <option value="Blob">Blob (anonymous read access for blobs only)</option>
                    <option value="Container">Container (anonymous read access for container and blobs)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-azure">Create Container</button>
        </form>
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="dash", containers=containers, total_blobs=total_blobs,
                                    size_str=size_str, user=ad_user, flash=request.args.get("msg"))


@app.route("/container/<int:cid>", methods=["GET", "POST"])
def view_container(cid):
    container = StorageContainer.query.get_or_404(cid)

    if request.method == "POST":
        # Check authorization (RBAC)
        if ad_user["role"] == "Reader":
            log = DiagnosticLog(operation="PutBlob", status="Denied", requested_by=ad_user["email"], role_used=ad_user["role"], details=f"Failed to upload blob to {container.name} due to insufficient permissions.")
            db.session.add(log)
            db.session.commit()
            return redirect(url_for("view_container", cid=cid, msg="Access Denied: Reader role cannot upload blobs."))

        name = request.form.get("name")
        size = int(request.form.get("size_bytes", 1024))
        content_type = request.form.get("content_type", "application/octet-stream")
        tier = request.form.get("access_tier", "Hot")

        b = BlobAsset(name=name, size_bytes=size, content_type=content_type, access_tier=tier, container_id=container.id)
        db.session.add(b)

        log = DiagnosticLog(operation="PutBlob", status="Success", requested_by=ad_user["email"], role_used=ad_user["role"], details=f"Uploaded blob '{name}' to container '{container.name}' ({tier} tier)")
        db.session.add(log)
        db.session.commit()
        return redirect(url_for("view_container", cid=cid, msg="Blob uploaded successfully"))

    content = TMPL.replace("{% block c %}{% endblock %}", """
<h2 style="margin-bottom:16px">📁 Container: {{ c.name }}</h2>
<div class="two-col">
    <div class="card">
        <h2>📦 Blobs inside {{ c.name }}</h2>
        <table><thead><tr><th>Name</th><th>Size (KB)</th><th>Content Type</th><th>Tier</th><th>Action</th></tr></thead><tbody>
        {% for b in c.blobs %}
        <tr>
            <td><strong>{{ b.name }}</strong></td>
            <td>{{ "%.1f"|format(b.size_bytes/1024) }}</td>
            <td style="font-family:monospace;font-size:.75rem">{{ b.content_type }}</td>
            <td><span class="badge public">{{ b.access_tier }}</span></td>
            <td><a href="/delete-blob/{{ b.id }}" class="btn btn-sm btn-red">Delete</a></td>
        </tr>{% endfor %}</tbody></table>
    </div>
    <div class="card">
        <h2>➕ Upload New Blob (Simulated)</h2>
        <form method="POST">
            <div class="form-group"><label>Blob File Name</label><input type="text" name="name" required placeholder="e.g. system_backup.zip"></div>
            <div class="form-group"><label>Size in Bytes</label><input type="number" name="size_bytes" value="45000" required></div>
            <div class="form-group"><label>Content Type</label><input type="text" name="content_type" value="application/zip"></div>
            <div class="form-group">
                <label>Access Tier</label>
                <select name="access_tier">
                    <option value="Hot">Hot (Frequently accessed data)</option>
                    <option value="Cool">Cool (Infrequently accessed data, min 30 days)</option>
                    <option value="Archive">Archive (Rarely accessed data, offline)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-azure">Upload Blob</button>
        </form>
    </div>
</div>
<a href="/" class="btn btn-azure">← Back</a>
""")
    from jinja2 import Template
    return Template(content).render(page="dash", c=container, flash=request.args.get("msg"))


@app.route("/create-container", methods=["POST"])
def create_container():
    if ad_user["role"] in ["Contributor", "Reader"]:
        log = DiagnosticLog(operation="CreateContainer", status="Denied", requested_by=ad_user["email"], role_used=ad_user["role"], details="Failed to create container due to insufficient permissions.")
        db.session.add(log)
        db.session.commit()
        return redirect(url_for("dashboard", msg="Access Denied: Only Owners can create containers."))

    name = request.form.get("name")
    access_type = request.form.get("access_type")

    c = StorageContainer(name=name, access_type=access_type)
    db.session.add(c)

    log = DiagnosticLog(operation="CreateContainer", status="Success", requested_by=ad_user["email"], role_used=ad_user["role"], details=f"Created container '{name}' with access policy '{access_type}'")
    db.session.add(log)
    db.session.commit()
    return redirect(url_for("dashboard", msg="Container created successfully"))


@app.route("/delete-container/<int:cid>")
def delete_container(cid):
    if ad_user["role"] != "Owner":
        log = DiagnosticLog(operation="DeleteContainer", status="Denied", requested_by=ad_user["email"], role_used=ad_user["role"], details="Failed to delete container due to insufficient permissions.")
        db.session.add(log)
        db.session.commit()
        return redirect(url_for("dashboard", msg="Access Denied: Only Owners can delete containers."))

    c = StorageContainer.query.get_or_404(cid)
    db.session.delete(c)

    log = DiagnosticLog(operation="DeleteContainer", status="Success", requested_by=ad_user["email"], role_used=ad_user["role"], details=f"Deleted container '{c.name}'")
    db.session.add(log)
    db.session.commit()
    return redirect(url_for("dashboard", msg="Container deleted"))


@app.route("/delete-blob/<int:bid>")
def delete_blob(bid):
    b = BlobAsset.query.get_or_404(bid)
    cid = b.container_id

    if ad_user["role"] == "Reader":
        log = DiagnosticLog(operation="DeleteBlob", status="Denied", requested_by=ad_user["email"], role_used=ad_user["role"], details=f"Failed to delete blob {b.name} due to insufficient permissions.")
        db.session.add(log)
        db.session.commit()
        return redirect(url_for("view_container", cid=cid, msg="Access Denied: Readers cannot delete blobs."))

    db.session.delete(b)
    log = DiagnosticLog(operation="DeleteBlob", status="Success", requested_by=ad_user["email"], role_used=ad_user["role"], details=f"Deleted blob '{b.name}' from container ID {cid}")
    db.session.add(log)
    db.session.commit()
    return redirect(url_for("view_container", cid=cid, msg="Blob deleted"))


@app.route("/rbac", methods=["GET", "POST"])
def rbac():
    global ad_user
    if request.method == "POST":
        new_role = request.form.get("role")
        ad_user["role"] = new_role
        return redirect(url_for("rbac", msg=f"Assigned new Azure AD role: {new_role}"))

    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card" style="max-width: 600px; margin: 0 auto">
    <h2>🔑 Access Control (IAM) / Active AD Authentication</h2>
    <p style="color:var(--dim);margin-bottom:16px">Simulate signing into Azure Portal using different Azure Active Directory (AD) RBAC roles to test access control enforcements.</p>
    
    <div style="background:rgba(0,127,255,.05);border:1px solid var(--border);padding:16px;border-radius:8px;margin-bottom:16px">
        <p><strong>Current Active Identity:</strong> {{ user.email }}</p>
        <p><strong>Assigned Role Definition:</strong> <span class="badge public">{{ user.role }}</span></p>
    </div>
    
    <form method="POST">
        <div class="form-group">
            <label>Select Identity Role</label>
            <select name="role">
                <option value="Owner" {% if user.role == 'Owner' %}selected{% endif %}>Storage Blob Data Owner (Full access to data & containers)</option>
                <option value="Contributor" {% if user.role == 'Contributor' %}selected{% endif %}>Storage Blob Data Contributor (Read/Write/Delete blobs, no container modifications)</option>
                <option value="Reader" {% if user.role == 'Reader' %}selected{% endif %}>Storage Blob Data Reader (Read-only access to blobs & containers)</option>
            </select>
        </div>
        <button type="submit" class="btn btn-azure">Apply IAM Assignment</button>
    </form>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="rbac", user=ad_user, flash=request.args.get("msg"))


@app.route("/logs")
def logs_view():
    logs = DiagnosticLog.query.order_by(DiagnosticLog.timestamp.desc()).all()
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>🗂️ Azure Monitor Diagnostic logs (Microsoft.Storage/storageAccounts)</h2>
    <table><thead><tr><th>Timestamp</th><th>Operation</th><th>Status</th><th>Identity</th><th>RBAC Role</th><th>Details</th></tr></thead><tbody>
    {% for l in logs %}
    <tr style="{% if l.status == 'Denied' %}background:rgba(232,17,35,.05){% endif %}">
        <td style="font-size:.75rem;color:var(--dim)">{{ l.timestamp.strftime('%Y-%m-%d %H:%M:%S') }}</td>
        <td><strong>{{ l.operation }}</strong></td>
        <td><span class="badge {% if l.status == 'Success' %}safe{% else %}private{% endif %}">{{ l.status }}</span></td>
        <td style="font-size:.8rem">{{ l.requested_by }}</td>
        <td><span class="badge public">{{ l.role_used }}</span></td>
        <td style="font-size:.8rem;color:var(--dim)">{{ l.details }}</td>
    </tr>{% endfor %}</tbody></table>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="logs", logs=logs)


with app.app_context():
    db.create_all()
    seed_data()

if __name__ == "__main__":
    print("\n  ☁️ Azure Cloud File Storage Simulator — http://localhost:5013\n")
    app.run(debug=True, port=5013)
