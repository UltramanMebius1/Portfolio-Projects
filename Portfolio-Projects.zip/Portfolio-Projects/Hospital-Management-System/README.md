# 🏥 Hospital Management System
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge)](https://python.org)

Professional modern hospital management system featuring appointment scheduling, medical inventory management, doctor panels, administrative reports, and PDF prescription generation.

## Features
- Patient registration and complete medical record tracking
- Appointment scheduling module with doctor allocation
- Ward and room allocation tracker
- Medical pharmacy inventory module
- Detailed administrative stats dashboard and reports

## Quick Start
```bash
pip install -r requirements.txt
python app.py  # http://localhost:5011
```
## License — MIT — **Koventhan M**
