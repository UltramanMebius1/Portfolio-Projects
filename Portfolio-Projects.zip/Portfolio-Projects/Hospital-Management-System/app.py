"""
Hospital Management System — Complete Flask Application
Patient records, doctor appointment scheduling, pharmacy inventory, ward management.
"""

import os
import json
import random
from datetime import datetime, timedelta
from flask import Flask, render_template_string, request, redirect, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = "hospital-mgmt-secret"
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'hospital.db')}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)


# ── Models ─────────────────────────────────────────────────────────────────

class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    gender = db.Column(db.String(10))
    phone = db.Column(db.String(20))
    address = db.Column(db.String(200))
    blood_group = db.Column(db.String(5))
    appointments = db.relationship("Appointment", backref="patient", lazy=True)


class Doctor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    specialty = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20))
    schedule = db.Column(db.String(100))  # e.g. "Mon-Fri 9AM-5PM"
    appointments = db.relationship("Appointment", backref="doctor", lazy=True)


class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patient.id"), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey("doctor.id"), nullable=False)
    appointment_date = db.Column(db.DateTime, nullable=False)
    reason = db.Column(db.String(200))
    status = db.Column(db.String(20), default="Scheduled")  # Scheduled, Completed, Cancelled


class PharmacyItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50))  # Tablet, Syrup, Injection, Equipment
    quantity = db.Column(db.Integer, default=0)
    buying_price = db.Column(db.Float, nullable=False)
    selling_price = db.Column(db.Float, nullable=False)


class Ward(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(50), nullable=False)  # General, Semi-Private, Private, ICU
    capacity = db.Column(db.Integer, nullable=False)
    occupied_beds = db.Column(db.Integer, default=0)
    allocations = db.relationship("WardAllocation", backref="ward", lazy=True, cascade="all, delete-orphan")


class WardAllocation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey("patient.id"), nullable=False)
    ward_id = db.Column(db.Integer, db.ForeignKey("ward.id"), nullable=False)
    bed_number = db.Column(db.String(20), nullable=False)
    check_in_date = db.Column(db.DateTime, default=datetime.utcnow)
    check_out_date = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), default="Admitted")  # Admitted, Discharged
    patient = db.relationship("Patient", backref="ward_allocations", lazy=True)


class Prescription(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    appointment_id = db.Column(db.Integer, db.ForeignKey("appointment.id"), nullable=False)
    medication_details = db.Column(db.Text, nullable=False)
    dosage = db.Column(db.String(100), nullable=False)
    duration = db.Column(db.String(100), nullable=False)
    notes = db.Column(db.Text)
    generated_at = db.Column(db.DateTime, default=datetime.utcnow)
    appointment = db.relationship("Appointment", backref="prescriptions", lazy=True)


def seed_data():
    if Doctor.query.count() > 0:
        return

    doctors = [
        {"name": "Dr. Sarah Jenkins", "specialty": "Cardiology", "phone": "555-0101", "sched": "Mon-Wed-Fri 9AM-4PM"},
        {"name": "Dr. David Vance", "specialty": "Neurology", "phone": "555-0102", "sched": "Tue-Thu 10AM-6PM"},
        {"name": "Dr. Amanda Ross", "specialty": "Pediatrics", "phone": "555-0103", "sched": "Mon-Fri 9AM-3PM"},
        {"name": "Dr. Robert Chen", "specialty": "General Surgery", "phone": "555-0104", "sched": "Mon-Tue-Wed 8AM-12PM"},
    ]
    for d in doctors:
        doc = Doctor(name=d["name"], specialty=d["specialty"], phone=d["phone"], schedule=d["sched"])
        db.session.add(doc)
    db.session.commit()

    patients = [
        {"name": "Alice Smith", "age": 34, "gender": "Female", "phone": "555-1234", "addr": "123 Maple St", "blood": "A+"},
        {"name": "Bob Jones", "age": 45, "gender": "Male", "phone": "555-5678", "addr": "456 Oak Ave", "blood": "O-"},
        {"name": "Charlie Miller", "age": 28, "gender": "Male", "phone": "555-9012", "addr": "789 Pine Rd", "blood": "B+"},
    ]
    for p in patients:
        pat = Patient(name=p["name"], age=p["age"], gender=p["gender"], phone=p["phone"], address=p["addr"], blood_group=p["blood"])
        db.session.add(pat)
    db.session.commit()

    pharmacy = [
        {"name": "Amoxicillin 500mg", "cat": "Tablet", "qty": 150, "buy": 5.0, "sell": 12.0},
        {"name": "Paracetamol 650mg", "cat": "Tablet", "qty": 500, "buy": 1.0, "sell": 3.0},
        {"name": "Ibuprofen 400mg", "cat": "Tablet", "qty": 200, "buy": 2.5, "sell": 6.0},
        {"name": "Cough Syrup (Guaifenesin)", "cat": "Syrup", "qty": 45, "buy": 4.0, "sell": 9.5},
    ]
    for ph in pharmacy:
        item = PharmacyItem(name=ph["name"], category=ph["cat"], quantity=ph["qty"], buying_price=ph["buy"], selling_price=ph["sell"])
        db.session.add(item)
    db.session.commit()

    if Ward.query.count() == 0:
        wards = [
            {"name": "General Ward A", "type": "General", "capacity": 10},
            {"name": "ICU Unit B", "type": "ICU", "capacity": 4},
            {"name": "Private Room 101", "type": "Private", "capacity": 1},
            {"name": "Semi-Private Ward C", "type": "Semi-Private", "capacity": 6},
        ]
        for w in wards:
            ward = Ward(name=w["name"], type=w["type"], capacity=w["capacity"])
            db.session.add(ward)
        db.session.commit()


# ── Templates ──────────────────────────────────────────────────────────────

TMPL = """
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Hospital Management System</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0b1329;--bg2:#1c2541;--card:#3a506b;--text:#edf2f4;--dim:#8d99ae;--blue:#4ea8de;--red:#ef233c;--orange:#f39c12;--green:#52b788;--border:#475569;--purple:#a2d2ff}
body{font-family:'Segoe UI',sans-serif;background:var(--bg);color:var(--text)}
.header{background:linear-gradient(135deg,#1c2541,#0b1329);border-bottom:1px solid var(--border);padding:16px 32px;display:flex;align-items:center;justify-content:space-between}
.header h1{font-size:1.4rem;background:linear-gradient(135deg,#4ea8de,#a2d2ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav{background:var(--bg2);border-bottom:1px solid var(--border);display:flex;padding:0 32px}
.nav a{color:var(--dim);text-decoration:none;padding:12px 18px;font-size:.85rem;font-weight:500;border-bottom:2px solid transparent;transition:.2s}
.nav a:hover,.nav a.active{color:var(--blue);border-bottom-color:var(--blue)}
.container{max-width:1400px;margin:0 auto;padding:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:24px}
.stat{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:20px}
.stat .label{font-size:.7rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}
.stat .val{font-size:1.8rem;font-weight:700}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:24px}
.card h2{font-size:1.1rem;margin-bottom:16px}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:10px;font-size:.7rem;text-transform:uppercase;color:var(--dim);border-bottom:1px solid var(--border)}
td{padding:10px;border-bottom:1px solid var(--border);font-size:.85rem}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:600;text-transform:uppercase}
.badge.alert{background:rgba(239,35,60,.12);color:var(--red);border:1px solid rgba(239,35,60,.25)}
.badge.safe{background:rgba(82,183,136,.12);color:var(--green);border:1px solid rgba(82,183,136,.25)}
.btn{padding:8px 16px;border-radius:8px;border:none;cursor:pointer;font-size:.85rem;font-weight:500;transition:.2s;text-decoration:none;display:inline-block;margin:2px}
.btn-blue{background:var(--blue);color:#fff}.btn-red{background:var(--red);color:#fff}.btn-purple{background:var(--purple);color:#0f172a}
.btn-sm{padding:4px 12px;font-size:.75rem}
.form-group{margin-bottom:12px}
label{display:block;margin-bottom:6px;font-size:.85rem;color:var(--dim)}
input[type=text],input[type=number],input[type=datetime-local],select{width:100%;padding:10px 14px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text);font-size:.9rem}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px}@media(max-width:768px){.two-col{grid-template-columns:1fr}}
.flash{padding:12px;border-radius:8px;margin-bottom:16px;background:rgba(78,168,222,.12);border:1px solid rgba(78,168,222,.3);color:var(--blue);font-size:.85rem}
@media print {
    body { background: #fff !important; color: #000 !important; font-family: 'Segoe UI', Arial, sans-serif !important; }
    .header, .nav, .btn, form, .flash, .btn-sm { display: none !important; }
    .container { max-width: 100% !important; margin: 0 !important; padding: 0 !important; }
    .card { background: #fff !important; border: none !important; padding: 0 !important; margin: 0 !important; color: #000 !important; box-shadow: none !important; }
    h2, h3 { color: #000 !important; margin-bottom: 12px !important; border-bottom: 2px solid #000 !important; padding-bottom: 6px !important; }
    table { width: 100% !important; border-collapse: collapse !important; margin-top: 15px !important; }
    th, td { border-bottom: 1px solid #ddd !important; color: #000 !important; padding: 8px !important; text-align: left !important; }
    th { text-transform: uppercase !important; font-size: 0.8rem !important; font-weight: 700 !important; }
}
</style></head><body>
<div class="header"><h1>🏥 Hospital Management System</h1><span style="color:var(--dim);font-size:.8rem">St. Mary's General</span></div>
<div class="nav">
    <a href="/" class="{{ 'active' if page=='dash' }}">Dashboard</a>
    <a href="/patients" class="{{ 'active' if page=='patients' }}">Patients</a>
    <a href="/doctors" class="{{ 'active' if page=='doctors' }}">Doctors</a>
    <a href="/wards" class="{{ 'active' if page=='wards' }}">Wards & Allocations</a>
    <a href="/pharmacy" class="{{ 'active' if page=='pharmacy' }}">Pharmacy / Inventory</a>
</div>
<div class="container">{% if flash %}<div class="flash">{{ flash }}</div>{% endif %}{% block c %}{% endblock %}</div>
</body></html>
"""

# ── Routes ─────────────────────────────────────────────────────────────────

@app.route("/")
def dashboard():
    total_patients = Patient.query.count()
    total_doctors = Doctor.query.count()
    total_appointments = Appointment.query.count()
    pharmacy_items = PharmacyItem.query.count()
    
    # Calculate ward occupancy
    total_beds = sum(w.capacity for w in Ward.query.all())
    occupied_beds = sum(w.occupied_beds for w in Ward.query.all())
    ward_occupancy = f"{occupied_beds}/{total_beds} Beds" if total_beds > 0 else "0/0"

    appointments = Appointment.query.order_by(Appointment.appointment_date.desc()).limit(10).all()

    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="grid">
    <div class="stat"><div class="label">Total Patients</div><div class="val" style="color:var(--blue)">{{ patients }}</div></div>
    <div class="stat"><div class="label">Total Doctors</div><div class="val" style="color:var(--purple)">{{ doctors }}</div></div>
    <div class="stat"><div class="label">Appointments</div><div class="val" style="color:var(--green)">{{ appointments_count }}</div></div>
    <div class="stat"><div class="label">Ward Occupancy</div><div class="val" style="color:var(--purple)">{{ ward_occ }}</div></div>
    <div class="stat"><div class="label">Pharmacy Items</div><div class="val" style="color:var(--orange)">{{ pharmacy }}</div></div>
</div>
<div class="card">
    <h2>🗓️ Recent Appointments Ledger</h2>
    <table><thead><tr><th>Date & Time</th><th>Patient</th><th>Doctor</th><th>Reason</th><th>Status</th><th>Prescription / Actions</th></tr></thead><tbody>
    {% for a in appointments %}
    <tr>
        <td style="font-size:.8rem">{{ a.appointment_date.strftime('%Y-%m-%d %H:%M') }}</td>
        <td><strong>{{ a.patient.name }}</strong></td>
        <td>{{ a.doctor.name }} ({{ a.doctor.specialty }})</td>
        <td>{{ a.reason }}</td>
        <td><span class="badge {% if a.status == 'Scheduled' %}safe{% else %}alert{% endif %}">{{ a.status }}</span></td>
        <td>
            {% if a.prescriptions %}
                {% for pr in a.prescriptions %}
                    <a href="/prescription/{{ pr.id }}/print" class="btn btn-sm btn-blue" target="_blank">📄 View Presc.</a>
                {% endfor %}
            {% else %}
                <a href="/appointment/{{ a.id }}/prescribe" class="btn btn-sm btn-purple">➕ Add Presc.</a>
            {% endif %}
        </td>
    </tr>{% endfor %}</tbody></table>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="dash", patients=total_patients, doctors=total_doctors,
                                     appointments_count=total_appointments, pharmacy=pharmacy_items,
                                     ward_occ=ward_occupancy, appointments=appointments, flash=request.args.get("msg"))


@app.route("/patients", methods=["GET", "POST"])
def patients():
    if request.method == "POST":
        name = request.form.get("name")
        age = int(request.form.get("age", 0))
        gender = request.form.get("gender")
        phone = request.form.get("phone")
        address = request.form.get("address")
        blood = request.form.get("blood_group")

        p = Patient(name=name, age=age, gender=gender, phone=phone, address=address, blood_group=blood)
        db.session.add(p)
        db.session.commit()
        return redirect(url_for("patients", msg="Patient profile created successfully"))

    patients_list = Patient.query.all()
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="two-col">
    <div class="card">
        <h2>👤 Registered Patients ({{ patients|length }})</h2>
        <table><thead><tr><th>Name</th><th>Age</th><th>Gender</th><th>Blood</th><th>Phone</th></tr></thead><tbody>
        {% for p in patients %}
        <tr>
            <td><strong>{{ p.name }}</strong></td><td>{{ p.age }}</td><td>{{ p.gender }}</td>
            <td><span class="badge safe">{{ p.blood_group }}</span></td><td>{{ p.phone }}</td>
        </tr>{% endfor %}</tbody></table>
    </div>
    <div class="card">
        <h2>➕ Register New Patient</h2>
        <form method="POST">
            <div class="form-group"><label>Full Name</label><input type="text" name="name" required></div>
            <div class="form-group"><label>Age</label><input type="number" name="age" required></div>
            <div class="form-group">
                <label>Gender</label>
                <select name="gender">
                    <option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option>
                </select>
            </div>
            <div class="form-group"><label>Blood Group</label><input type="text" name="blood_group"></div>
            <div class="form-group"><label>Phone Number</label><input type="text" name="phone"></div>
            <div class="form-group"><label>Address</label><input type="text" name="address"></div>
            <button type="submit" class="btn btn-blue">Create Patient</button>
        </form>
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="patients", patients=patients_list, flash=request.args.get("msg"))


@app.route("/doctors", methods=["GET", "POST"])
def doctors():
    if request.method == "POST":
        pid = int(request.form.get("patient_id"))
        did = int(request.form.get("doctor_id"))
        date_str = request.form.get("date")
        reason = request.form.get("reason")

        try:
            date_val = datetime.strptime(date_str, "%Y-%m-%dT%H:%M")
        except ValueError:
            return redirect(url_for("doctors", msg="Invalid date format"))

        a = Appointment(patient_id=pid, doctor_id=did, appointment_date=date_val, reason=reason)
        db.session.add(a)
        db.session.commit()
        return redirect(url_for("dashboard", msg="Appointment scheduled successfully"))

    doctors_list = Doctor.query.all()
    patients_list = Patient.query.all()
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="two-col">
    <div class="card">
        <h2>👨‍⚕️ Medical Practitioners ({{ doctors|length }})</h2>
        <table><thead><tr><th>Name</th><th>Specialty</th><th>Schedule</th><th>Contact</th></tr></thead><tbody>
        {% for d in doctors %}
        <tr>
            <td><strong>{{ d.name }}</strong></td>
            <td><span class="badge safe">{{ d.specialty }}</span></td>
            <td>{{ d.schedule }}</td><td>{{ d.phone }}</td>
        </tr>{% endfor %}</tbody></table>
    </div>
    <div class="card">
        <h2>🗓️ Schedule Patient Visit</h2>
        <form method="POST">
            <div class="form-group">
                <label>Select Patient</label>
                <select name="patient_id">
                    {% for p in patients %}
                    <option value="{{ p.id }}">{{ p.name }} (Age: {{ p.age }})</option>
                    {% endfor %}
                </select>
            </div>
            <div class="form-group">
                <label>Select Practitioner</label>
                <select name="doctor_id">
                    {% for d in doctors %}
                    <option value="{{ d.id }}">{{ d.name }} - {{ d.specialty }}</option>
                    {% endfor %}
                </select>
            </div>
            <div class="form-group"><label>Appointment Date & Time</label><input type="datetime-local" name="date" required></div>
            <div class="form-group"><label>Reason for Visit</label><input type="text" name="reason"></div>
            <button type="submit" class="btn btn-purple">Schedule Visit</button>
        </form>
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="doctors", doctors=doctors_list, patients=patients_list, flash=request.args.get("msg"))


@app.route("/pharmacy", methods=["GET", "POST"])
def pharmacy():
    if request.method == "POST":
        name = request.form.get("name")
        cat = request.form.get("category")
        qty = int(request.form.get("quantity", 0))
        buy = float(request.form.get("buying_price", 0.0))
        sell = float(request.form.get("selling_price", 0.0))

        item = PharmacyItem(name=name, category=cat, quantity=qty, buying_price=buy, selling_price=sell)
        db.session.add(item)
        db.session.commit()
        return redirect(url_for("pharmacy", msg="Pharmacy item registered"))

    items_list = PharmacyItem.query.all()
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="two-col">
    <div class="card">
        <h2>💊 Medical Stores & Pharmacy ({{ items|length }})</h2>
        <table><thead><tr><th>Medicine Name</th><th>Category</th><th>Qty</th><th>Buying Price</th><th>Selling Price</th></tr></thead><tbody>
        {% for item in items %}
        <tr>
            <td><strong>{{ item.name }}</strong></td><td>{{ item.category }}</td>
            <td style="{{ 'color:var(--red);font-weight:700' if item.quantity < 50 else 'color:var(--green)' }}">{{ item.quantity }}</td>
            <td>${{ item.buying_price }}</td><td>${{ item.selling_price }}</td>
        </tr>{% endfor %}</tbody></table>
    </div>
    <div class="card">
        <h2>➕ Add Pharmacy / Medicine Item</h2>
        <form method="POST">
            <div class="form-group"><label>Medicine Name</label><input type="text" name="name" required></div>
            <div class="form-group">
                <label>Category</label>
                <select name="category">
                    <option value="Tablet">Tablet</option><option value="Syrup">Syrup</option>
                    <option value="Injection">Injection</option><option value="Equipment">Equipment</option>
                </select>
            </div>
            <div class="form-group"><label>Quantity</label><input type="number" name="quantity" required></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                <div class="form-group"><label>Buying Price ($)</label><input type="number" step="0.01" name="buying_price" required></div>
                <div class="form-group"><label>Selling Price ($)</label><input type="number" step="0.01" name="selling_price" required></div>
            </div>
            <button type="submit" class="btn btn-blue">Register Stock</button>
        </form>
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="pharmacy", items=items_list, flash=request.args.get("msg"))


@app.route("/wards", methods=["GET", "POST"])
def wards():
    if request.method == "POST":
        name = request.form.get("name")
        w_type = request.form.get("type")
        capacity = int(request.form.get("capacity", 1))

        ward = Ward(name=name, type=w_type, capacity=capacity)
        db.session.add(ward)
        db.session.commit()
        return redirect(url_for("wards", msg="New ward added successfully"))

    wards_list = Ward.query.all()
    allocations = WardAllocation.query.filter_by(status="Admitted").all()
    patients_list = Patient.query.all()

    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="two-col">
    <div class="card">
        <h2>🏥 Active Ward Allocations</h2>
        <table><thead><tr><th>Patient</th><th>Ward (Type)</th><th>Bed No.</th><th>Admitted Date</th><th>Action</th></tr></thead><tbody>
        {% for a in allocations %}
        <tr>
            <td><strong>{{ a.patient.name }}</strong> (Age: {{ a.patient.age }})</td>
            <td>{{ a.ward.name }} ({{ a.ward.type }})</td>
            <td>Bed #{{ a.bed_number }}</td>
            <td style="font-size:.75rem">{{ a.check_in_date.strftime('%Y-%m-%d %H:%M') }}</td>
            <td><a href="/wards/discharge/{{ a.id }}" class="btn btn-sm btn-red">Discharge</a></td>
        </tr>{% endfor %}
        {% if not allocations %}
        <tr><td colspan="5" style="color:var(--dim);text-align:center">No patients currently admitted to wards.</td></tr>
        {% endif %}
        </tbody></table>
    </div>

    <div class="card">
        <h2>🛌 Admit Patient to Ward</h2>
        <form action="/wards/allocate" method="POST">
            <div class="form-group">
                <label>Select Patient</label>
                <select name="patient_id">
                    {% for p in patients %}
                    <option value="{{ p.id }}">{{ p.name }} (Blood: {{ p.blood_group or 'N/A' }})</option>
                    {% endfor %}
                </select>
            </div>
            <div class="form-group">
                <label>Select Ward</label>
                <select name="ward_id">
                    {% for w in wards %}
                    {% if w.occupied_beds < w.capacity %}
                    <option value="{{ w.id }}">{{ w.name }} (Available: {{ w.capacity - w.occupied_beds }}/{{ w.capacity }})</option>
                    {% endif %}
                    {% endfor %}
                </select>
            </div>
            <div class="form-group"><label>Bed Number / Room No.</label><input type="text" name="bed_number" required placeholder="e.g. Bed-14"></div>
            <button type="submit" class="btn btn-purple">Admit Patient</button>
        </form>
    </div>
</div>

<div class="card">
    <h2>🏥 Ward Status & Capacity</h2>
    <table><thead><tr><th>Ward Name</th><th>Type</th><th>Total Beds</th><th>Occupied</th><th>Available</th></tr></thead><tbody>
    {% for w in wards %}
    <tr>
        <td><strong>{{ w.name }}</strong></td>
        <td><span class="badge safe">{{ w.type }}</span></td>
        <td>{{ w.capacity }}</td>
        <td style="{{ 'color:var(--red);font-weight:700' if w.occupied_beds == w.capacity else '' }}">{{ w.occupied_beds }}</td>
        <td>{{ w.capacity - w.occupied_beds }}</td>
    </tr>{% endfor %}
    </tbody></table>
    <h3 style="margin-top:24px;margin-bottom:12px">➕ Create New Ward / Room</h3>
    <form method="POST">
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;align-items:flex-end">
            <div class="form-group" style="margin-bottom:0"><label>Ward Name</label><input type="text" name="name" required placeholder="e.g. ICU Wing D"></div>
            <div class="form-group" style="margin-bottom:0">
                <label>Ward Type</label>
                <select name="type">
                    <option value="General">General</option>
                    <option value="Semi-Private">Semi-Private</option>
                    <option value="Private">Private Room</option>
                    <option value="ICU">ICU</option>
                </select>
            </div>
            <div class="form-group" style="margin-bottom:0"><label>Bed Capacity</label><input type="number" name="capacity" required min="1" value="5"></div>
        </div>
        <button type="submit" class="btn btn-blue" style="margin-top:16px">Create Ward</button>
    </form>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="wards", wards=wards_list, allocations=allocations, patients=patients_list, flash=request.args.get("msg"))


@app.route("/wards/allocate", methods=["POST"])
def allocate_ward():
    pid = int(request.form.get("patient_id"))
    wid = int(request.form.get("ward_id"))
    bed = request.form.get("bed_number")

    ward = Ward.query.get(wid)
    if not ward or ward.occupied_beds >= ward.capacity:
        return redirect(url_for("wards", msg="Ward is fully occupied or invalid"))

    ward.occupied_beds += 1
    alloc = WardAllocation(patient_id=pid, ward_id=wid, bed_number=bed)
    db.session.add(alloc)
    db.session.commit()
    return redirect(url_for("wards", msg="Patient successfully admitted to ward"))


@app.route("/wards/discharge/<int:alloc_id>")
def discharge_ward(alloc_id):
    alloc = WardAllocation.query.get_or_404(alloc_id)
    if alloc.status == "Admitted":
        alloc.status = "Discharged"
        alloc.check_out_date = datetime.utcnow()
        alloc.ward.occupied_beds = max(0, alloc.ward.occupied_beds - 1)
        db.session.commit()
        return redirect(url_for("wards", msg="Patient discharged from ward"))
    return redirect(url_for("wards"))


@app.route("/appointment/<int:app_id>/prescribe", methods=["GET", "POST"])
def prescribe(app_id):
    appt = Appointment.query.get_or_404(app_id)
    if request.method == "POST":
        meds = request.form.get("medications")
        dosage = request.form.get("dosage")
        duration = request.form.get("duration")
        notes = request.form.get("notes")

        presc = Prescription(appointment_id=appt.id, medication_details=meds, dosage=dosage, duration=duration, notes=notes)
        appt.status = "Completed"
        db.session.add(presc)
        db.session.commit()
        return redirect(url_for("dashboard", msg="Prescription written, appointment marked complete"))

    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card" style="max-width:600px;margin: 0 auto">
    <h2>✍️ Write Prescription</h2>
    <p style="color:var(--dim);font-size:.85rem;margin-bottom:16px">
        Patient: <strong>{{ appt.patient.name }}</strong> (Age: {{ appt.patient.age }})<br>
        Doctor: <strong>{{ appt.doctor.name }}</strong> ({{ appt.doctor.specialty }})
    </p>
    <form method="POST">
        <div class="form-group"><label>Medication Details</label><input type="text" name="medications" required placeholder="e.g. Amoxicillin 500mg, Paracetamol 650mg"></div>
        <div class="form-group"><label>Dosage Instructions</label><input type="text" name="dosage" required placeholder="e.g. 1-0-1 after food"></div>
        <div class="form-group"><label>Duration</label><input type="text" name="duration" required placeholder="e.g. 5 Days"></div>
        <div class="form-group"><label>Clinical Notes</label><input type="text" name="notes" placeholder="Rest for 2 days, avoid cold drinks."></div>
        <button type="submit" class="btn btn-purple">Submit Prescription</button>
        <a href="/" class="btn btn-red">Cancel</a>
    </form>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="dash", appt=appt)


@app.route("/prescription/<int:presc_id>/print")
def print_prescription(presc_id):
    presc = Prescription.query.get_or_404(presc_id)
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card" style="background:#fff;color:#000;border:1px solid #ccc;padding:40px;border-radius:8px;max-width:800px;margin:20px auto">
    <div style="text-align:center;border-bottom:3px solid #000;padding-bottom:12px;margin-bottom:20px">
        <h1 style="color:#000;margin-bottom:4px">ST. MARY'S GENERAL HOSPITAL</h1>
        <p style="color:#666;font-size:.9rem;margin-bottom:0">123 Health Ave, Medical District | Ph: 555-0100</p>
    </div>
    <div style="display:flex;justify-content:space-between;margin-bottom:20px;font-size:.9rem">
        <div>
            <p><strong>Patient Name:</strong> {{ presc.appointment.patient.name }}</p>
            <p><strong>Age / Gender:</strong> {{ presc.appointment.patient.age }} / {{ presc.appointment.patient.gender }}</p>
            <p><strong>Blood Group:</strong> {{ presc.appointment.patient.blood_group or 'N/A' }}</p>
        </div>
        <div style="text-align:right">
            <p><strong>Date:</strong> {{ presc.generated_at.strftime('%Y-%m-%d %H:%M') }}</p>
            <p><strong>Doctor:</strong> {{ presc.appointment.doctor.name }}</p>
            <p><strong>Specialty:</strong> {{ presc.appointment.doctor.specialty }}</p>
        </div>
    </div>
    
    <div style="margin-top:30px">
        <h3 style="border-bottom:2px solid #000;padding-bottom:6px;color:#000">💊 Prescribed Medications (Rx)</h3>
        <table style="width:100%;border-collapse:collapse;margin-top:10px">
            <thead>
                <tr style="border-bottom:2px solid #000">
                    <th style="padding:8px 0;text-align:left;color:#000">Medication</th>
                    <th style="padding:8px 0;text-align:left;color:#000">Dosage</th>
                    <th style="padding:8px 0;text-align:left;color:#000">Duration</th>
                </tr>
            </thead>
            <tbody>
                <tr style="border-bottom:1px solid #ddd">
                    <td style="padding:10px 0;font-weight:bold;color:#000">{{ presc.medication_details }}</td>
                    <td style="padding:10px 0;color:#000">{{ presc.dosage }}</td>
                    <td style="padding:10px 0;color:#000">{{ presc.duration }}</td>
                </tr>
            </tbody>
        </table>
    </div>

    {% if presc.notes %}
    <div style="margin-top:30px">
        <p><strong>Clinical Notes / Advice:</strong></p>
        <p style="background:#f9f9f9;padding:12px;border-left:4px solid #000;font-style:italic;color:#333">{{ presc.notes }}</p>
    </div>
    {% endif %}

    <div style="margin-top:50px;display:flex;justify-content:space-between;align-items:flex-end">
        <button class="btn btn-blue" onclick="window.print()" style="margin:0">🖨️ Print Prescription</button>
        <div style="text-align:center;border-top:1px solid #000;width:200px;padding-top:6px;font-size:.85rem">
            Authorized Signature
        </div>
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="dash", presc=presc)


with app.app_context():
    db.create_all()
    seed_data()

if __name__ == "__main__":
    print("\n  🏥 Hospital Management System — http://localhost:5011\n")
    app.run(debug=True, port=5011)
