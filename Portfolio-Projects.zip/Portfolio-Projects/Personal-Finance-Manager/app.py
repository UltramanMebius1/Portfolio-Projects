"""
Personal Finance Manager — Complete Flask Application
Income and expense tracking, budget thresholds, CSV import/export, dashboard charts.
"""

import os
import csv
import io
from datetime import datetime, timedelta
from flask import Flask, render_template_string, request, redirect, url_for, Response
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = "personal-finance-secret"
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'finance.db')}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)


# ── Models ─────────────────────────────────────────────────────────────────

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    type = db.Column(db.String(10), nullable=False)  # income or expense
    category = db.Column(db.String(50), nullable=False)
    date = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)


class BudgetLimit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(50), unique=True, nullable=False)
    limit_amount = db.Column(db.Float, nullable=False)


def seed_data():
    if Transaction.query.count() > 0:
        return

    # Seed transaction history
    txs = [
        {"title": "Monthly Salary", "amt": 5000.0, "type": "income", "cat": "Salary", "days_ago": 28},
        {"title": "Apartment Rent", "amt": 1200.0, "type": "expense", "cat": "Housing", "days_ago": 27},
        {"title": "Whole Foods Grocery", "amt": 150.0, "type": "expense", "cat": "Food", "days_ago": 25},
        {"title": "Electric Bill", "amt": 85.0, "type": "expense", "cat": "Utilities", "days_ago": 20},
        {"title": "Netflix Subscription", "amt": 15.5, "type": "expense", "cat": "Entertainment", "days_ago": 15},
        {"title": "Freelance Project", "amt": 750.0, "type": "income", "cat": "Salary", "days_ago": 10},
        {"title": "Restaurant Dinner", "amt": 95.0, "type": "expense", "cat": "Food", "days_ago": 5},
        {"title": "Gas Station", "amt": 45.0, "type": "expense", "cat": "Transportation", "days_ago": 2},
    ]

    for tx in txs:
        t = Transaction(title=tx["title"], amount=tx["amt"], type=tx["type"], category=tx["cat"],
                        date=datetime.utcnow() - timedelta(days=tx["days_ago"]))
        db.session.add(t)

    budgets = [
        {"cat": "Food", "lim": 300.0},
        {"cat": "Housing", "lim": 1500.0},
        {"cat": "Utilities", "lim": 200.0},
        {"cat": "Entertainment", "lim": 100.0},
        {"cat": "Transportation", "lim": 150.0},
    ]
    for b in budgets:
        bl = BudgetLimit(category=b["cat"], limit_amount=b["lim"])
        db.session.add(bl)

    db.session.commit()


# ── Templates ──────────────────────────────────────────────────────────────

TMPL = """
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Personal Finance Manager</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0b0f19;--bg2:#161c2d;--card:#21293e;--text:#f8fafc;--dim:#94a3b8;--blue:#3b82f6;--red:#ef4444;--orange:#f97316;--green:#10b981;--border:#334155;--purple:#8b5cf6}
body{font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:var(--text)}
.header{background:linear-gradient(135deg,#161c2d,#0b0f19);border-bottom:1px solid var(--border);padding:16px 32px;display:flex;align-items:center;justify-content:space-between}
.header h1{font-size:1.4rem;background:linear-gradient(135deg,#10b981,#3b82f6);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav{background:var(--bg2);border-bottom:1px solid var(--border);display:flex;padding:0 32px}
.nav a{color:var(--dim);text-decoration:none;padding:12px 18px;font-size:.85rem;font-weight:500;border-bottom:2px solid transparent;transition:.2s}
.nav a:hover,.nav a.active{color:var(--green);border-bottom-color:var(--green)}
.container{max-width:1400px;margin:0 auto;padding:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:24px}
.stat{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:20px}
.stat .label{font-size:.7rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}
.stat .val{font-size:1.8rem;font-weight:700}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:24px}
.card h2{font-size:1.1rem;margin-bottom:16px}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:10px;font-size:.7rem;text-transform:uppercase;color:var(--dim);border-bottom:1px solid var(--border)}
td{padding:10px;border-bottom:1px solid var(--border);font-size:.85rem}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:600;text-transform:uppercase}
.badge.income{background:rgba(16,185,129,.12);color:var(--green);border:1px solid rgba(16,185,129,.25)}
.badge.expense{background:rgba(239,68,68,.12);color:var(--red);border:1px solid rgba(239,68,68,.25)}
.btn{padding:8px 16px;border-radius:8px;border:none;cursor:pointer;font-size:.85rem;font-weight:500;transition:.2s;text-decoration:none;display:inline-block;margin:2px}
.btn-green{background:var(--green);color:#fff}.btn-red{background:var(--red);color:#fff}.btn-blue{background:var(--blue);color:#fff}
.btn-sm{padding:4px 12px;font-size:.75rem}
.form-group{margin-bottom:12px}
label{display:block;margin-bottom:6px;font-size:.85rem;color:var(--dim)}
input[type=text],input[type=number],select{width:100%;padding:10px 14px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text);font-size:.9rem}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px}@media(max-width:768px){.two-col{grid-template-columns:1fr}}
.bar{height:10px;border-radius:5px;overflow:hidden;background:var(--border);margin-top:6px}
.bar-fill{height:100%;border-radius:5px;transition:width .5s}
.flash{padding:12px;border-radius:8px;margin-bottom:16px;background:rgba(16,185,129,.12);border:1px solid rgba(16,185,129,.3);color:var(--green);font-size:.85rem}
</style></head><body>
<div class="header"><h1>📈 Personal Finance Manager</h1><span style="color:var(--dim);font-size:.8rem">Koventhan's Portfolio</span></div>
<div class="nav">
    <a href="/" class="{{ 'active' if page=='dash' }}">Dashboard</a>
    <a href="/transactions" class="{{ 'active' if page=='transactions' }}">Transactions Ledger</a>
    <a href="/budgets" class="{{ 'active' if page=='budgets' }}">Budget Manager</a>
</div>
<div class="container">{% if flash %}<div class="flash">{{ flash }}</div>{% endif %}{% block c %}{% endblock %}</div>
</body></html>
"""

# ── Routes ─────────────────────────────────────────────────────────────────

@app.route("/")
def dashboard():
    txs = Transaction.query.all()
    total_income = sum(t.amount for t in txs if t.type == "income")
    total_expense = sum(t.amount for t in txs if t.type == "expense")
    net_savings = total_income - total_expense

    # Category summary for budgets progress
    budgets = BudgetLimit.query.all()
    budget_progress = []
    for b in budgets:
        spent = sum(t.amount for t in txs if t.type == "expense" and t.category == b.category)
        pct = min(int((spent / b.limit_amount) * 100), 100) if b.limit_amount > 0 else 0
        budget_progress.append({
            "category": b.category,
            "limit": b.limit_amount,
            "spent": spent,
            "percentage": pct,
            "warning": spent > b.limit_amount
        })

    recent_txs = Transaction.query.order_by(Transaction.date.desc()).limit(8).all()

    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="grid">
    <div class="stat"><div class="label">Total Income</div><div class="val" style="color:var(--green)">+${{ "%.2f"|format(income) }}</div></div>
    <div class="stat"><div class="label">Total Expense</div><div class="val" style="color:var(--red)">-${{ "%.2f"|format(expense) }}</div></div>
    <div class="stat"><div class="label">Net Savings</div><div class="val" style="color:var(--blue)">${{ "%.2f"|format(savings) }}</div></div>
    <div class="stat"><div class="label">Budget Enforcements</div><div class="val" style="color:var(--purple)">{{ budgets|length }} Categories</div></div>
</div>
<div class="two-col">
    <div class="card">
        <h2>📊 Monthly Budgets vs Spending</h2>
        {% for b in progress %}
        <div style="margin:12px 0">
            <div style="display:flex;justify-content:space-between;font-size:.85rem">
                <span><strong>{{ b.category }}</strong></span>
                <span style="{{ 'color:var(--red);font-weight:700' if b.warning else '' }}">
                    ${{ "%.2f"|format(b.spent) }} / ${{ "%.2f"|format(b.limit) }} ({{ b.percentage }}%)
                </span>
            </div>
            <div class="bar">
                <div class="bar-fill" style="width:{{ b.percentage }}%;background:{% if b.warning %}var(--red){% else %}var(--green){% endif %}"></div>
            </div>
        </div>
        {% endfor %}
    </div>
    <div class="card">
        <h2>🧾 Recent Transactions</h2>
        <table><thead><tr><th>Date</th><th>Description</th><th>Category</th><th>Amount</th></tr></thead><tbody>
        {% for t in recent %}
        <tr>
            <td style="font-size:.75rem">{{ t.date.strftime('%Y-%m-%d') }}</td>
            <td><strong>{{ t.title }}</strong></td>
            <td><span class="badge">{{ t.category }}</span></td>
            <td><span class="badge {{ t.type }}">${{ "%.2f"|format(t.amount) }}</span></td>
        </tr>{% endfor %}</tbody></table>
        <div style="margin-top:16px;display:flex;gap:8px">
            <a href="/export-csv" class="btn btn-blue btn-sm">📤 Export CSV Ledger</a>
            <a href="/simulate-import" class="btn btn-green btn-sm">📥 Simulate Bank CSV Import</a>
        </div>
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="dash", income=total_income, expense=total_expense,
                                    savings=net_savings, budgets=budgets, progress=budget_progress,
                                    recent=recent_txs, flash=request.args.get("msg"))


@app.route("/transactions", methods=["GET", "POST"])
def transactions():
    if request.method == "POST":
        title = request.form.get("title")
        amount = float(request.form.get("amount", 0.0))
        tx_type = request.form.get("type")
        category = request.form.get("category")
        notes = request.form.get("notes")

        t = Transaction(title=title, amount=amount, type=tx_type, category=category, notes=notes)
        db.session.add(t)
        db.session.commit()
        return redirect(url_for("transactions", msg="Transaction recorded successfully"))

    txs_list = Transaction.query.order_by(Transaction.date.desc()).all()
    categories = ["Housing", "Food", "Utilities", "Salary", "Entertainment", "Transportation", "Other"]
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="two-col">
    <div class="card">
        <h2>🧾 Transaction Ledger ({{ txs|length }})</h2>
        <table><thead><tr><th>Date</th><th>Title</th><th>Category</th><th>Amount</th><th>Action</th></tr></thead><tbody>
        {% for t in txs %}
        <tr>
            <td style="font-size:.75rem">{{ t.date.strftime('%Y-%m-%d') }}</td>
            <td><strong>{{ t.title }}</strong></td>
            <td>{{ t.category }}</td>
            <td><span class="badge {{ t.type }}">${{ "%.2f"|format(t.amount) }}</span></td>
            <td><a href="/delete-tx/{{ t.id }}" class="btn btn-sm btn-red">Delete</a></td>
        </tr>{% endfor %}</tbody></table>
    </div>
    <div class="card">
        <h2>➕ Record Transaction</h2>
        <form method="POST">
            <div class="form-group"><label>Transaction Title / Merchant</label><input type="text" name="title" required></div>
            <div class="form-group"><label>Amount ($)</label><input type="number" step="0.01" name="amount" required></div>
            <div class="form-group">
                <label>Flow Type</label>
                <select name="type">
                    <option value="expense">Expense (-)</option><option value="income">Income (+)</option>
                </select>
            </div>
            <div class="form-group">
                <label>Category</label>
                <select name="category">
                    {% for c in categories %}
                    <option value="{{ c }}">{{ c }}</option>
                    {% endfor %}
                </select>
            </div>
            <div class="form-group"><label>Notes</label><input type="text" name="notes"></div>
            <button type="submit" class="btn btn-green">Save Entry</button>
        </form>
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="transactions", txs=txs_list, categories=categories, flash=request.args.get("msg"))


@app.route("/budgets", methods=["GET", "POST"])
def budgets():
    if request.method == "POST":
        category = request.form.get("category")
        amount = float(request.form.get("limit_amount", 0.0))

        existing = BudgetLimit.query.filter_by(category=category).first()
        if existing:
            existing.limit_amount = amount
        else:
            bl = BudgetLimit(category=category, limit_amount=amount)
            db.session.add(bl)
        db.session.commit()
        return redirect(url_for("budgets", msg="Budget limit established"))

    budgets_list = BudgetLimit.query.all()
    categories = ["Housing", "Food", "Utilities", "Salary", "Entertainment", "Transportation", "Other"]
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="two-col">
    <div class="card">
        <h2>🛡️ Category Monthly Limits</h2>
        <table><thead><tr><th>Category</th><th>Limit Amount</th><th>Action</th></tr></thead><tbody>
        {% for b in budgets %}
        <tr>
            <td><strong>{{ b.category }}</strong></td>
            <td style="font-weight:700">${{ "%.2f"|format(b.limit_amount) }}</td>
            <td><a href="/delete-budget/{{ b.id }}" class="btn btn-sm btn-red">Remove</a></td>
        </tr>{% endfor %}</tbody></table>
    </div>
    <div class="card">
        <h2>➕ Establish Budget Limit</h2>
        <form method="POST">
            <div class="form-group">
                <label>Category</label>
                <select name="category">
                    {% for c in categories %}
                    {% if c != 'Salary' %}
                    <option value="{{ c }}">{{ c }}</option>
                    {% endif %}
                    {% endfor %}
                </select>
            </div>
            <div class="form-group"><label>Limit Amount ($)</label><input type="number" step="0.01" name="limit_amount" required></div>
            <button type="submit" class="btn btn-blue">Enforce Budget</button>
        </form>
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="budgets", budgets=budgets_list, categories=categories, flash=request.args.get("msg"))


@app.route("/delete-tx/<int:tid>")
def delete_tx(tid):
    t = Transaction.query.get_or_404(tid)
    db.session.delete(t)
    db.session.commit()
    return redirect(url_for("transactions", msg="Entry removed"))


@app.route("/delete-budget/<int:bid>")
def delete_budget(bid):
    b = BudgetLimit.query.get_or_404(bid)
    db.session.delete(b)
    db.session.commit()
    return redirect(url_for("budgets", msg="Budget limit removed"))


@app.route("/export-csv")
def export_csv():
    txs = Transaction.query.all()
    dest = io.StringIO()
    writer = csv.writer(dest)
    writer.writerow(["ID", "Date", "Title", "Category", "Type", "Amount"])
    for t in txs:
        writer.writerow([t.id, t.date.strftime("%Y-%m-%d"), t.title, t.category, t.type, t.amount])

    return Response(
        dest.getvalue(),
        mimetype="text/csv",
        headers={"Content-disposition": "attachment; filename=transactions_ledger.csv"}
    )


@app.route("/simulate-import")
def simulate_import():
    # Simulate importing CSV file of 3 new bank records
    new_txs = [
        {"title": "Uber Ride", "amt": 22.50, "type": "expense", "cat": "Transportation"},
        {"title": "Coffee Shop", "amt": 6.80, "type": "expense", "cat": "Food"},
        {"title": "Dividend Payout", "amt": 120.00, "type": "income", "cat": "Salary"},
    ]
    for tx in new_txs:
        t = Transaction(title=tx["title"], amount=tx["amt"], type=tx["type"], category=tx["cat"], date=datetime.utcnow())
        db.session.add(t)
    db.session.commit()
    return redirect(url_for("dashboard", msg="Imported 3 new bank transactions from statement.csv"))


with app.app_context():
    db.create_all()
    seed_data()

if __name__ == "__main__":
    print("\n  📈 Personal Finance Manager — http://localhost:5012\n")
    app.run(debug=True, port=5012)
