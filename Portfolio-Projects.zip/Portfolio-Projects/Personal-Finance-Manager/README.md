# 📈 Personal Finance Manager
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge)](https://python.org)

Interactive personal finance dashboard and budgeting system with income and expense tracking, graphical monthly trends, budget limit alerts, and CSV import/export capabilities.

## Features
- Track Income and Expenses across multiple categories
- Establish custom monthly budget limits with threshold alerts
- Import bank transactions from CSV files
- Export financial statements to CSV or JSON formats
- Interactive dashboard featuring monthly spending breakdown charts

## Quick Start
```bash
pip install -r requirements.txt
python app.py  # http://localhost:5012
```
## License — MIT — **Koventhan M**
