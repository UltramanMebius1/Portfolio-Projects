# 📦 Smart Inventory Management System
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge)](https://python.org)

Professional enterprise inventory management system with stock prediction, barcode scanning simulation, invoicing, interactive dashboard with analytical charts.

## Features
- Complete CRUD inventory management (Products, Categories, Suppliers)
- Simulated Barcode/QR Code scanner interaction
- Dynamic sales forecasting using simple regression models
- Invoice generation and printing utilities
- Executive dashboard with inventory valuation and alert indicators

## Quick Start
```bash
pip install -r requirements.txt
python app.py  # http://localhost:5010
```
## License — MIT — **Koventhan M**
