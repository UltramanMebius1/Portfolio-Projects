"""
Smart Inventory Management System — Complete Flask Application
CRUD operations, stock level predictions, barcode scanning simulation, sales invoicing, analytics dashboard.
"""

import os
import json
import random
from datetime import datetime, timedelta
from flask import Flask, render_template_string, request, redirect, url_for, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = "smart-inventory-secret"
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'inventory.db')}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)


# ── Models ─────────────────────────────────────────────────────────────────

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    sku = db.Column(db.String(50), unique=True, nullable=False)
    barcode = db.Column(db.String(50), unique=True)
    category = db.Column(db.String(50))
    quantity = db.Column(db.Integer, default=0)
    min_threshold = db.Column(db.Integer, default=10)
    buying_price = db.Column(db.Float, nullable=False)
    selling_price = db.Column(db.Float, nullable=False)
    supplier = db.Column(db.String(100))
    sales = db.relationship("Sale", backref="product", lazy=True)


class Sale(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    sold_at = db.Column(db.DateTime, default=datetime.utcnow)


def seed_data():
    if Product.query.count() > 0:
        return

    items = [
        {"name": "Dell XPS 13 Laptop", "sku": "DELL-XPS13", "barcode": "789012345601", "category": "Electronics", "qty": 15, "min": 5, "buy": 900.0, "sell": 1200.0, "sup": "Dell Solutions"},
        {"name": "iPhone 15 Pro", "sku": "APPL-IP15P", "barcode": "789012345602", "category": "Electronics", "qty": 25, "min": 8, "buy": 800.0, "sell": 1099.0, "sup": "Apple Corp"},
        {"name": "Logitech MX Master 3S", "sku": "LOGI-MX3S", "barcode": "789012345603", "category": "Accessories", "qty": 8, "min": 10, "buy": 60.0, "sell": 99.0, "sup": "Logitech Global"},
        {"name": "Samsung 32\" 4K Monitor", "sku": "SAMS-U32R", "barcode": "789012345604", "category": "Electronics", "qty": 12, "min": 4, "buy": 250.0, "sell": 349.0, "sup": "Samsung Display"},
        {"name": "Ergonomic Office Chair", "sku": "FURN-CH01", "barcode": "789012345605", "category": "Furniture", "qty": 3, "min": 5, "buy": 120.0, "sell": 199.0, "sup": "Comfort Seats Corp"},
    ]

    for it in items:
        p = Product(name=it["name"], sku=it["sku"], barcode=it["barcode"], category=it["category"],
                    quantity=it["qty"], min_threshold=it["min"], buying_price=it["buy"],
                    selling_price=it["sell"], supplier=it["sup"])
        db.session.add(p)
    db.session.commit()

    # Seed sales
    products = Product.query.all()
    for p in products:
        for i in range(5):
            qty = random.randint(1, 3)
            s = Sale(product_id=p.id, quantity=qty, total_price=qty * p.selling_price,
                     sold_at=datetime.utcnow() - timedelta(days=random.randint(1, 30)))
            db.session.add(s)
    db.session.commit()


# ── Templates ──────────────────────────────────────────────────────────────

TMPL = """
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Smart Inventory Management</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0f172a;--bg2:#1e293b;--card:#334155;--text:#f8fafc;--dim:#94a3b8;--blue:#3b82f6;--red:#ef4444;--orange:#f97316;--yellow:#eab308;--green:#22c55e;--border:#475569;--purple:#a855f7}
body{font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:var(--text)}
.header{background:linear-gradient(135deg,#1e293b,#0f172a);border-bottom:1px solid var(--border);padding:16px 32px;display:flex;align-items:center;justify-content:space-between}
.header h1{font-size:1.4rem;background:linear-gradient(135deg,#3b82f6,#a855f7);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav{background:var(--bg2);border-bottom:1px solid var(--border);display:flex;padding:0 32px}
.nav a{color:var(--dim);text-decoration:none;padding:12px 18px;font-size:.85rem;font-weight:500;border-bottom:2px solid transparent;transition:.2s}
.nav a:hover,.nav a.active{color:var(--blue);border-bottom-color:var(--blue)}
.container{max-width:1400px;margin:0 auto;padding:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:24px}
.stat{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:20px}
.stat .label{font-size:.7rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}
.stat .val{font-size:1.8rem;font-weight:700}
.card{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:24px}
.card h2{font-size:1.1rem;margin-bottom:16px}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:10px;font-size:.7rem;text-transform:uppercase;color:var(--dim);border-bottom:1px solid var(--border)}
td{padding:10px;border-bottom:1px solid var(--border);font-size:.85rem}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:600;text-transform:uppercase}
.badge.alert{background:rgba(239,68,68,.12);color:var(--red);border:1px solid rgba(239,68,68,.25)}
.badge.safe{background:rgba(34,197,94,.12);color:var(--green);border:1px solid rgba(34,197,94,.25)}
.btn{padding:8px 16px;border-radius:8px;border:none;cursor:pointer;font-size:.85rem;font-weight:500;transition:.2s;text-decoration:none;display:inline-block;margin:2px}
.btn-blue{background:var(--blue);color:#fff}.btn-red{background:var(--red);color:#fff}.btn-purple{background:var(--purple);color:#fff}
.btn-sm{padding:4px 12px;font-size:.75rem}
.form-group{margin-bottom:12px}
label{display:block;margin-bottom:6px;font-size:.85rem;color:var(--dim)}
input[type=text],input[type=number],select{width:100%;padding:10px 14px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--text);font-size:.9rem}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:24px}@media(max-width:768px){.two-col{grid-template-columns:1fr}}
.flash{padding:12px;border-radius:8px;margin-bottom:16px;background:rgba(59,130,246,.12);border:1px solid rgba(59,130,246,.3);color:var(--blue);font-size:.85rem}
</style></head><body>
<div class="header"><h1>📦 Smart Inventory Management System</h1><span style="color:var(--dim);font-size:.8rem">HQ Warehouse</span></div>
<div class="nav">
    <a href="/" class="{{ 'active' if page=='dash' }}">Dashboard</a>
    <a href="/products" class="{{ 'active' if page=='products' }}">Products</a>
    <a href="/sales" class="{{ 'active' if page=='sales' }}">Sales / Billing</a>
    <a href="/scanner" class="{{ 'active' if page=='scanner' }}">Barcode Simulator</a>
</div>
<div class="container">{% if flash %}<div class="flash">{{ flash }}</div>{% endif %}{% block c %}{% endblock %}</div>
</body></html>
"""

# ── Routes ─────────────────────────────────────────────────────────────────

@app.route("/")
def dashboard():
    products = Product.query.all()
    total_products = len(products)
    low_stock = sum(1 for p in products if p.quantity <= p.min_threshold)
    total_value = sum(p.quantity * p.buying_price for p in products)
    expected_revenue = sum(p.quantity * p.selling_price for p in products)

    # Forecast/predictions simple model
    recommendations = []
    for p in products:
        sales_qty = sum(s.quantity for s in p.sales)
        # Prediction: if sales rate suggests depletion within 10 days, flag for order
        if sales_qty > 5 and p.quantity <= p.min_threshold * 1.5:
            recommendations.append({"product": p.name, "sku": p.sku, "reason": f"High demand ({sales_qty} sold recently) + low stock ({p.quantity} left)"})

    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="grid">
    <div class="stat"><div class="label">Total Products</div><div class="val" style="color:var(--blue)">{{ total }}</div></div>
    <div class="stat"><div class="label">Low Stock Alerts</div><div class="val" style="color:var(--red)">{{ low_stock }}</div></div>
    <div class="stat"><div class="label">Inventory Value</div><div class="val" style="color:var(--green)">${{ "%.2f"|format(value) }}</div></div>
    <div class="stat"><div class="label">Expected Revenue</div><div class="val" style="color:var(--purple)">${{ "%.2f"|format(revenue) }}</div></div>
</div>
<div class="two-col">
    <div class="card">
        <h2>🔮 Intelligent Restock Suggestions</h2>
        {% for r in recs %}
        <div style="background:rgba(249,115,22,.06);border-left:4px solid var(--orange);padding:12px;margin:8px 0;border-radius:4px">
            <strong>{{ r.product }}</strong> (SKU: {{ r.sku }})<br>
            <span style="font-size:.85rem;color:var(--dim)">{{ r.reason }}</span>
        </div>{% endfor %}
        {% if not recs %}<p style="color:var(--dim)">All stock levels healthy for current sales trends.</p>{% endif %}
    </div>
    <div class="card">
        <h2>⚠️ Alerting Stock Levels</h2>
        <table><thead><tr><th>Product</th><th>SKU</th><th>Stock</th><th>Threshold</th><th>Status</th></tr></thead><tbody>
        {% for p in products %}
        {% if p.quantity <= p.min_threshold %}
        <tr>
            <td>{{ p.name }}</td><td>{{ p.sku }}</td>
            <td style="color:var(--red);font-weight:700">{{ p.quantity }}</td><td>{{ p.min_threshold }}</td>
            <td><span class="badge alert">REORDER</span></td>
        </tr>{% endif %}{% endfor %}</tbody></table>
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="dash", total=total_products, low_stock=low_stock,
                                    value=total_value, revenue=expected_revenue, recs=recommendations,
                                    products=products, flash=request.args.get("msg"))


@app.route("/products", methods=["GET", "POST"])
def products():
    if request.method == "POST":
        name = request.form.get("name")
        sku = request.form.get("sku")
        barcode = request.form.get("barcode")
        category = request.form.get("category")
        quantity = int(request.form.get("quantity", 0))
        min_threshold = int(request.form.get("min_threshold", 5))
        buy_price = float(request.form.get("buying_price", 0.0))
        sell_price = float(request.form.get("selling_price", 0.0))
        supplier = request.form.get("supplier")

        p = Product(name=name, sku=sku, barcode=barcode, category=category, quantity=quantity,
                    min_threshold=min_threshold, buying_price=buy_price, selling_price=sell_price,
                    supplier=supplier)
        db.session.add(p)
        db.session.commit()
        return redirect(url_for("products", msg="Product added successfully"))

    products_list = Product.query.all()
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="two-col">
    <div class="card">
        <h2>📦 Product Catalog ({{ products|length }})</h2>
        <table><thead><tr><th>Name</th><th>SKU</th><th>Barcode</th><th>Category</th><th>Stock</th><th>Buy</th><th>Sell</th></tr></thead><tbody>
        {% for p in products %}
        <tr>
            <td><strong>{{ p.name }}</strong></td><td>{{ p.sku }}</td><td style="font-family:monospace">{{ p.barcode or '-' }}</td>
            <td>{{ p.category }}</td>
            <td style="{{ 'color:var(--red);font-weight:700' if p.quantity <= p.min_threshold else 'color:var(--green)' }}">{{ p.quantity }}</td>
            <td>${{ p.buying_price }}</td><td>${{ p.selling_price }}</td>
        </tr>{% endfor %}</tbody></table>
    </div>
    <div class="card">
        <h2>➕ Add New Product</h2>
        <form method="POST">
            <div class="form-group"><label>Product Name</label><input type="text" name="name" required></div>
            <div class="form-group"><label>SKU (Stock Keeping Unit)</label><input type="text" name="sku" required></div>
            <div class="form-group"><label>Barcode (EAN-13)</label><input type="text" name="barcode"></div>
            <div class="form-group"><label>Category</label><input type="text" name="category"></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                <div class="form-group"><label>Quantity</label><input type="number" name="quantity" value="0" required></div>
                <div class="form-group"><label>Min Threshold</label><input type="number" name="min_threshold" value="5" required></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                <div class="form-group"><label>Buying Price ($)</label><input type="number" step="0.01" name="buying_price" required></div>
                <div class="form-group"><label>Selling Price ($)</label><input type="number" step="0.01" name="selling_price" required></div>
            </div>
            <div class="form-group"><label>Supplier</label><input type="text" name="supplier"></div>
            <button type="submit" class="btn btn-blue">Add Product</button>
        </form>
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="products", products=products_list, flash=request.args.get("msg"))


@app.route("/sales", methods=["GET", "POST"])
def sales():
    if request.method == "POST":
        pid = int(request.form.get("product_id"))
        qty = int(request.form.get("quantity"))

        p = Product.query.get(pid)
        if p and p.quantity >= qty:
            p.quantity -= qty
            s = Sale(product_id=p.id, quantity=qty, total_price=qty * p.selling_price)
            db.session.add(s)
            db.session.commit()
            return redirect(url_for("sales", msg="Invoice generated successfully"))
        else:
            return redirect(url_for("sales", msg="Insufficient stock!"))

    products_list = Product.query.all()
    sales_list = Sale.query.order_by(Sale.sold_at.desc()).all()
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="two-col">
    <div class="card">
        <h2>🧾 Generate Invoice / Register Sale</h2>
        <form method="POST">
            <div class="form-group">
                <label>Select Product</label>
                <select name="product_id">
                    {% for p in products %}
                    <option value="{{ p.id }}">{{ p.name }} (${{ p.selling_price }} | Stock: {{ p.quantity }})</option>
                    {% endfor %}
                </select>
            </div>
            <div class="form-group"><label>Quantity</label><input type="number" name="quantity" value="1" min="1" required></div>
            <button type="submit" class="btn btn-purple">Checkout & Print Invoice</button>
        </form>
    </div>
    <div class="card">
        <h2>📊 Transaction Ledger</h2>
        <table><thead><tr><th>Date</th><th>Product</th><th>Qty</th><th>Total Sale</th></tr></thead><tbody>
        {% for s in sales_list %}
        <tr>
            <td style="font-size:.75rem">{{ s.sold_at.strftime('%Y-%m-%d %H:%M') }}</td>
            <td><strong>{{ s.product.name }}</strong></td>
            <td>{{ s.quantity }}</td>
            <td style="color:var(--green)">${{ "%.2f"|format(s.total_price) }}</td>
        </tr>{% endfor %}</tbody></table>
    </div>
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="sales", products=products_list, sales_list=sales_list, flash=request.args.get("msg"))


@app.route("/scanner", methods=["GET", "POST"])
def scanner():
    result = None
    if request.method == "POST":
        code = request.form.get("barcode", "").strip()
        p = Product.query.filter_by(barcode=code).first()
        if p:
            result = p
        else:
            result = "Not Found"

    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card" style="max-width: 600px; margin: 0 auto">
    <h2>📸 Barcode Scanner Simulation</h2>
    <p style="color:var(--dim);margin-bottom:16px">Enter a scanned product barcode to fetch inventory info instantly.</p>
    <p style="margin-bottom:8px"><strong>Sample Barcodes to copy:</strong><br>
    Dell Laptop: <code style="color:var(--orange)">789012345601</code> | iPhone: <code style="color:var(--orange)">789012345602</code>
    </p>
    <form method="POST">
        <input type="text" name="barcode" placeholder="Scan or type barcode number..." required autofocus>
        <button type="submit" class="btn btn-blue">🔍 Query Scanner</button>
    </form>
    
    {% if res %}
        {% if res == 'Not Found' %}
            <div style="background:rgba(239,68,68,.06);border-left:4px solid var(--red);padding:12px;margin-top:16px;border-radius:4px">
                [-] Product not found in database for scanned barcode.
            </div>
        {% else %}
            <div style="background:rgba(34,197,94,.06);border-left:4px solid var(--green);padding:16px;margin-top:16px;border-radius:8px">
                <h3 style="color:var(--green);margin-bottom:8px">Product Scanned: {{ res.name }}</h3>
                <p><strong>SKU:</strong> {{ res.sku }}</p>
                <p><strong>Category:</strong> {{ res.category }}</p>
                <p><strong>Quantity In Warehouse:</strong> {{ res.quantity }}</p>
                <p><strong>Selling Price:</strong> ${{ res.selling_price }}</p>
            </div>
        {% endif %}
    {% endif %}
</div>
""")
    from jinja2 import Template
    return Template(content).render(page="scanner", res=result)


with app.app_context():
    db.create_all()
    seed_data()

if __name__ == "__main__":
    print("\n  📦 Smart Inventory Management — http://localhost:5010\n")
    app.run(debug=True, port=5010)
