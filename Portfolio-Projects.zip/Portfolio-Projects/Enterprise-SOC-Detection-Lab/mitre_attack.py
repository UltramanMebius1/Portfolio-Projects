"""
Enterprise SOC Detection Lab — MITRE ATT&CK Framework Integration
Provides complete tactic/technique mapping, coverage analysis, and heatmap generation.
"""

MITRE_TACTICS = [
    {"id": "TA0001", "name": "Initial Access", "description": "Techniques to gain initial foothold"},
    {"id": "TA0002", "name": "Execution", "description": "Techniques to run malicious code"},
    {"id": "TA0003", "name": "Persistence", "description": "Techniques to maintain foothold"},
    {"id": "TA0004", "name": "Privilege Escalation", "description": "Techniques to gain higher-level permissions"},
    {"id": "TA0005", "name": "Defense Evasion", "description": "Techniques to avoid detection"},
    {"id": "TA0006", "name": "Credential Access", "description": "Techniques to steal credentials"},
    {"id": "TA0007", "name": "Discovery", "description": "Techniques to explore the environment"},
    {"id": "TA0008", "name": "Lateral Movement", "description": "Techniques to move through the environment"},
    {"id": "TA0009", "name": "Collection", "description": "Techniques to gather data"},
    {"id": "TA0010", "name": "Exfiltration", "description": "Techniques to steal data"},
    {"id": "TA0011", "name": "Command and Control", "description": "Techniques to communicate with compromised systems"},
    {"id": "TA0040", "name": "Impact", "description": "Techniques to disrupt availability or integrity"},
]

MITRE_TECHNIQUES = {
    "T1078": {"name": "Valid Accounts", "tactic": "TA0001", "tactic_name": "Initial Access",
              "description": "Adversaries may obtain and abuse credentials of existing accounts"},
    "T1190": {"name": "Exploit Public-Facing Application", "tactic": "TA0001", "tactic_name": "Initial Access",
              "description": "Adversaries may exploit vulnerabilities in internet-facing systems"},
    "T1059.001": {"name": "PowerShell", "tactic": "TA0002", "tactic_name": "Execution",
                  "description": "Adversaries may abuse PowerShell commands and scripts"},
    "T1059.003": {"name": "Windows Command Shell", "tactic": "TA0002", "tactic_name": "Execution",
                  "description": "Adversaries may abuse the Windows command shell for execution"},
    "T1053": {"name": "Scheduled Task/Job", "tactic": "TA0003", "tactic_name": "Persistence",
              "description": "Adversaries may create scheduled tasks for persistence"},
    "T1547.001": {"name": "Registry Run Keys / Startup Folder", "tactic": "TA0003", "tactic_name": "Persistence",
                  "description": "Adversaries may achieve persistence via registry run keys"},
    "T1543.003": {"name": "Windows Service", "tactic": "TA0003", "tactic_name": "Persistence",
                  "description": "Adversaries may create or modify Windows services for persistence"},
    "T1068": {"name": "Exploitation for Privilege Escalation", "tactic": "TA0004", "tactic_name": "Privilege Escalation",
              "description": "Adversaries may exploit software vulnerabilities to escalate privileges"},
    "T1055": {"name": "Process Injection", "tactic": "TA0004", "tactic_name": "Privilege Escalation",
              "description": "Adversaries may inject code into processes to evade defenses and escalate privileges"},
    "T1070": {"name": "Indicator Removal", "tactic": "TA0005", "tactic_name": "Defense Evasion",
              "description": "Adversaries may delete or modify artifacts to remove evidence"},
    "T1036": {"name": "Masquerading", "tactic": "TA0005", "tactic_name": "Defense Evasion",
              "description": "Adversaries may manipulate features to make artifacts appear legitimate"},
    "T1562.001": {"name": "Disable or Modify Tools", "tactic": "TA0005", "tactic_name": "Defense Evasion",
                  "description": "Adversaries may disable security tools to evade detection"},
    "T1003": {"name": "OS Credential Dumping", "tactic": "TA0006", "tactic_name": "Credential Access",
              "description": "Adversaries may dump credentials to obtain account login information"},
    "T1003.006": {"name": "DCSync", "tactic": "TA0006", "tactic_name": "Credential Access",
                  "description": "Adversaries may abuse the DCSync technique to steal password hashes"},
    "T1558.003": {"name": "Kerberoasting", "tactic": "TA0006", "tactic_name": "Credential Access",
                  "description": "Adversaries may abuse Kerberos TGS tickets to crack service account passwords"},
    "T1110": {"name": "Brute Force", "tactic": "TA0006", "tactic_name": "Credential Access",
              "description": "Adversaries may use brute force techniques to attempt access"},
    "T1087": {"name": "Account Discovery", "tactic": "TA0007", "tactic_name": "Discovery",
              "description": "Adversaries may attempt to get a listing of accounts on a system"},
    "T1082": {"name": "System Information Discovery", "tactic": "TA0007", "tactic_name": "Discovery",
              "description": "Adversaries may attempt to get detailed information about the operating system"},
    "T1021": {"name": "Remote Services", "tactic": "TA0008", "tactic_name": "Lateral Movement",
              "description": "Adversaries may use remote services to move laterally"},
    "T1021.001": {"name": "Remote Desktop Protocol", "tactic": "TA0008", "tactic_name": "Lateral Movement",
                  "description": "Adversaries may use RDP to move laterally"},
    "T1570": {"name": "Lateral Tool Transfer", "tactic": "TA0008", "tactic_name": "Lateral Movement",
              "description": "Adversaries may transfer tools between systems"},
    "T1005": {"name": "Data from Local System", "tactic": "TA0009", "tactic_name": "Collection",
              "description": "Adversaries may search local system sources for data of interest"},
    "T1114": {"name": "Email Collection", "tactic": "TA0009", "tactic_name": "Collection",
              "description": "Adversaries may collect email to gather intelligence"},
    "T1041": {"name": "Exfiltration Over C2 Channel", "tactic": "TA0010", "tactic_name": "Exfiltration",
              "description": "Adversaries may steal data by exfiltrating over an existing C2 channel"},
    "T1048": {"name": "Exfiltration Over Alternative Protocol", "tactic": "TA0010", "tactic_name": "Exfiltration",
              "description": "Adversaries may steal data by exfiltrating over different protocols"},
    "T1071": {"name": "Application Layer Protocol", "tactic": "TA0011", "tactic_name": "Command and Control",
              "description": "Adversaries may communicate using application layer protocols"},
    "T1486": {"name": "Data Encrypted for Impact", "tactic": "TA0040", "tactic_name": "Impact",
              "description": "Adversaries may encrypt data on target systems for ransomware"},
    "T1489": {"name": "Service Stop", "tactic": "TA0040", "tactic_name": "Impact",
              "description": "Adversaries may stop services to render systems less useful"},
}


class MitreAttackMapper:
    """Maps detections to the MITRE ATT&CK framework and generates coverage reports."""

    def __init__(self):
        self.tactics = MITRE_TACTICS
        self.techniques = MITRE_TECHNIQUES
        self.coverage = {}

    def map_technique(self, technique_id: str) -> dict:
        """Get full technique details by ID."""
        return self.techniques.get(technique_id, {
            "name": "Unknown Technique",
            "tactic": "Unknown",
            "tactic_name": "Unknown",
            "description": "No description available"
        })

    def get_tactic_name(self, tactic_id: str) -> str:
        """Get tactic name by ID."""
        for tactic in self.tactics:
            if tactic["id"] == tactic_id:
                return tactic["name"]
        return "Unknown"

    def update_coverage(self, technique_id: str, detection_count: int = 1):
        """Update coverage tracking for a technique."""
        if technique_id not in self.coverage:
            self.coverage[technique_id] = {
                "technique": self.map_technique(technique_id),
                "detections": 0,
                "rules": [],
            }
        self.coverage[technique_id]["detections"] += detection_count

    def get_coverage_matrix(self) -> dict:
        """Generate MITRE ATT&CK coverage matrix grouped by tactic."""
        matrix = {}
        for tactic in self.tactics:
            tactic_id = tactic["id"]
            tactic_name = tactic["name"]
            matrix[tactic_name] = {
                "tactic_id": tactic_id,
                "techniques": [],
                "covered": 0,
                "total": 0,
            }

        for tech_id, tech_info in self.techniques.items():
            tactic_name = tech_info.get("tactic_name", "Unknown")
            if tactic_name in matrix:
                matrix[tactic_name]["total"] += 1
                covered = tech_id in self.coverage
                matrix[tactic_name]["techniques"].append({
                    "id": tech_id,
                    "name": tech_info["name"],
                    "covered": covered,
                    "detections": self.coverage.get(tech_id, {}).get("detections", 0),
                })
                if covered:
                    matrix[tactic_name]["covered"] += 1

        return matrix

    def get_coverage_percentage(self) -> float:
        """Calculate overall MITRE ATT&CK coverage percentage."""
        total = len(self.techniques)
        covered = len(self.coverage)
        return round((covered / total) * 100, 1) if total > 0 else 0.0

    def get_heatmap_data(self) -> list:
        """Generate heatmap data for visualization."""
        heatmap = []
        for tactic in self.tactics:
            tactic_name = tactic["name"]
            techniques_in_tactic = [
                (tid, tinfo) for tid, tinfo in self.techniques.items()
                if tinfo.get("tactic_name") == tactic_name
            ]
            for tech_id, tech_info in techniques_in_tactic:
                detections = self.coverage.get(tech_id, {}).get("detections", 0)
                heatmap.append({
                    "tactic": tactic_name,
                    "technique_id": tech_id,
                    "technique_name": tech_info["name"],
                    "detections": detections,
                    "intensity": min(detections / 10, 1.0) if detections > 0 else 0,
                })
        return heatmap

    def generate_gap_analysis(self) -> dict:
        """Identify uncovered techniques for gap analysis."""
        uncovered = []
        covered = []
        for tech_id, tech_info in self.techniques.items():
            entry = {"id": tech_id, "name": tech_info["name"], "tactic": tech_info["tactic_name"]}
            if tech_id in self.coverage:
                entry["detections"] = self.coverage[tech_id]["detections"]
                covered.append(entry)
            else:
                uncovered.append(entry)

        return {
            "covered": covered,
            "uncovered": uncovered,
            "coverage_pct": self.get_coverage_percentage(),
            "total_techniques": len(self.techniques),
            "covered_count": len(covered),
            "uncovered_count": len(uncovered),
        }
