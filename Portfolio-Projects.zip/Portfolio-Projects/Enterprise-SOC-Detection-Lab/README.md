# 🛡️ Enterprise SOC Detection Lab

[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![MITRE ATT&CK](https://img.shields.io/badge/MITRE-ATT%26CK-red?style=for-the-badge)](https://attack.mitre.org)
[![Sigma](https://img.shields.io/badge/Sigma-Rules-blue?style=for-the-badge)](https://github.com/SigmaHQ/sigma)
[![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)](LICENSE)

A comprehensive Security Operations Center (SOC) detection laboratory that simulates enterprise-grade threat detection, investigation, and response workflows. This project demonstrates real-world SOC analyst capabilities including log analysis, detection engineering, MITRE ATT&CK mapping, alert triage, and incident investigation.

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    SOC Detection Lab                         │
├──────────┬──────────┬──────────┬──────────┬─────────────────┤
│  Log     │ Detection│  Alert   │ Investi- │   Dashboard     │
│ Ingestion│  Engine  │  Manager │  gation  │   & Reports     │
├──────────┼──────────┼──────────┼──────────┼─────────────────┤
│ Sysmon   │ Sigma    │ Triage   │ Timeline │  Flask Web UI   │
│ WinEvent │ YARA     │ Priority │ Evidence │  Charts/Graphs  │
│ Auth     │ Custom   │ Escalate │ IOC      │  MITRE Heatmap  │
│ Firewall │ ML-based │ Notify   │ Forensic │  PDF Export     │
└──────────┴──────────┴──────────┴──────────┴─────────────────┘
```

## ✨ Features

### Detection Engine
- **Sigma Rule Processing** — Parse and execute Sigma detection rules against log data
- **Custom Detection Rules** — YAML-based custom rule engine with boolean logic
- **YARA Integration** — File/memory pattern matching for malware indicators
- **Anomaly Detection** — Statistical baseline deviation alerting
- **MITRE ATT&CK Mapping** — Every detection mapped to tactics and techniques

### Attack Simulations
- Brute Force Authentication (T1110)
- Credential Dumping (T1003)
- Lateral Movement (T1021)
- Privilege Escalation (T1068)
- Data Exfiltration (T1041)
- PowerShell Abuse (T1059.001)
- Persistence via Registry (T1547.001)
- Kerberoasting (T1558.003)
- DCSync Attack (T1003.006)
- Ransomware Behavior (T1486)

### SOC Workflow
- Alert triage and prioritization
- Incident investigation with timeline analysis
- IOC extraction and enrichment
- Evidence collection and chain of custody
- Executive reporting with PDF export

### Dashboard
- Real-time alert feed
- MITRE ATT&CK coverage heatmap
- Detection rule performance metrics
- Analyst KPI tracking
- Threat landscape overview

## 📁 Project Structure

```
Enterprise-SOC-Detection-Lab/
├── app.py                  # Flask web application & dashboard
├── detection_engine.py     # Core detection engine with Sigma/custom rules
├── attack_simulator.py     # Realistic attack log generation
├── investigation.py        # Investigation & forensic analysis module
├── mitre_attack.py         # MITRE ATT&CK framework integration
├── models.py               # Database models
├── config.py               # Configuration management
├── requirements.txt        # Python dependencies
├── rules/
│   ├── sigma/              # Sigma detection rules
│   │   ├── brute_force.yml
│   │   ├── credential_dump.yml
│   │   ├── lateral_movement.yml
│   │   ├── powershell_abuse.yml
│   │   └── persistence.yml
│   └── custom/             # Custom detection rules
│       ├── data_exfil.yml
│       └── ransomware.yml
├── sample_logs/            # Sample log datasets
│   └── generate_logs.py    # Log generation utility
└── .gitignore
```

## 🚀 Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/Enterprise-SOC-Detection-Lab.git
cd Enterprise-SOC-Detection-Lab

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# Install dependencies
pip install -r requirements.txt

# Run the application
python app.py
```

Open your browser and navigate to `http://localhost:5000`

## 🖥️ Screenshots

> Screenshots will be added after deployment

## 🔧 Usage

### 1. Generate Attack Simulations
```python
from attack_simulator import AttackSimulator
simulator = AttackSimulator()
simulator.run_all_scenarios()
```

### 2. Run Detection Engine
```python
from detection_engine import DetectionEngine
engine = DetectionEngine()
alerts = engine.scan_all_logs()
```

### 3. Investigate Alerts
```python
from investigation import InvestigationManager
investigator = InvestigationManager()
report = investigator.investigate_alert(alert_id=1)
```

## 🎯 MITRE ATT&CK Coverage

| Tactic | Techniques Covered |
|--------|--------------------|
| Initial Access | T1078, T1190 |
| Execution | T1059.001, T1059.003 |
| Persistence | T1547.001, T1053 |
| Privilege Escalation | T1068, T1055 |
| Defense Evasion | T1070, T1036 |
| Credential Access | T1003, T1558.003 |
| Discovery | T1087, T1082 |
| Lateral Movement | T1021, T1570 |
| Collection | T1005, T1114 |
| Exfiltration | T1041, T1048 |
| Impact | T1486, T1489 |

## 📜 License

This project is licensed under the MIT License.

## 👤 Author

**Koventhan M**
- Cybersecurity Analyst | SOC Engineer
- 30+ Industry Certifications
- BSNL Cybersecurity Intern
