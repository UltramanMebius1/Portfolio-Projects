"""
Enterprise SOC Detection Lab — Investigation Module
Provides incident investigation, timeline analysis, IOC extraction, and forensic reporting.
"""

import json
from datetime import datetime
from collections import defaultdict
from models import db, Alert, Investigation, LogEntry


class InvestigationManager:
    """Manages incident investigations, correlates alerts, extracts IOCs, and generates reports."""

    def __init__(self):
        self.ioc_patterns = {
            "ip_addresses": set(),
            "domains": set(),
            "file_hashes": set(),
            "file_paths": set(),
            "user_accounts": set(),
            "processes": set(),
            "registry_keys": set(),
        }

    def create_investigation(self, title: str, alert_ids: list, analyst: str = "SOC Analyst") -> Investigation:
        """Create a new investigation from correlated alerts."""
        investigation = Investigation(
            title=title,
            analyst=analyst,
            status="in_progress",
        )
        db.session.add(investigation)
        db.session.flush()

        # Link alerts
        alerts = Alert.query.filter(Alert.id.in_(alert_ids)).all()
        max_severity = "low"
        severity_rank = {"informational": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}

        for alert in alerts:
            alert.investigation_id = investigation.id
            alert.status = "investigating"
            if severity_rank.get(alert.severity, 0) > severity_rank.get(max_severity, 0):
                max_severity = alert.severity

        investigation.severity = max_severity

        # Build timeline
        timeline = self._build_timeline(alerts)
        investigation.timeline = json.dumps(timeline)

        # Extract IOCs
        iocs = self._extract_iocs(alerts)
        investigation.iocs = json.dumps(iocs)

        # Map MITRE techniques
        techniques = list(set(a.mitre_technique for a in alerts if a.mitre_technique))
        investigation.mitre_techniques = json.dumps(techniques)

        # Generate summary
        investigation.summary = self._generate_summary(alerts, timeline, iocs, techniques)

        # Generate recommendations
        investigation.recommendations = self._generate_recommendations(alerts, techniques)

        db.session.commit()
        return investigation

    def investigate_alert(self, alert_id: int) -> dict:
        """Perform automated investigation on a single alert."""
        alert = Alert.query.get(alert_id)
        if not alert:
            return {"error": "Alert not found"}

        # Find correlated alerts (same host/user within 1 hour)
        correlated = Alert.query.filter(
            Alert.id != alert_id,
            Alert.hostname == alert.hostname,
        ).all()

        # Extract evidence
        evidence = json.loads(alert.evidence) if alert.evidence else {}

        # Get associated log entry
        log_entry = LogEntry.query.get(alert.log_entry_id) if alert.log_entry_id else None

        # Build investigation report
        report = {
            "alert": alert.to_dict(),
            "evidence": evidence,
            "correlated_alerts": [a.to_dict() for a in correlated[:20]],
            "correlated_count": len(correlated),
            "iocs": self._extract_iocs_from_alert(alert),
            "timeline": self._build_alert_timeline(alert, correlated),
            "risk_score": self._calculate_risk_score(alert, correlated),
            "recommendations": self._get_alert_recommendations(alert),
            "log_entry": log_entry.to_dict() if log_entry else None,
        }

        return report

    def _build_timeline(self, alerts: list) -> list:
        """Build a chronological timeline from alerts."""
        timeline = []
        for alert in sorted(alerts, key=lambda a: a.timestamp):
            timeline.append({
                "timestamp": alert.timestamp.isoformat(),
                "event": alert.rule_name,
                "severity": alert.severity,
                "host": alert.hostname,
                "user": alert.username,
                "source_ip": alert.source_ip,
                "mitre": alert.mitre_technique,
                "description": alert.description,
            })
        return timeline

    def _build_alert_timeline(self, alert: Alert, correlated: list) -> list:
        """Build timeline around a specific alert."""
        all_alerts = [alert] + correlated
        return self._build_timeline(all_alerts)

    def _extract_iocs(self, alerts: list) -> dict:
        """Extract Indicators of Compromise from alerts."""
        iocs = {
            "ip_addresses": set(),
            "file_hashes": set(),
            "file_paths": set(),
            "processes": set(),
            "user_accounts": set(),
            "registry_keys": set(),
            "command_lines": set(),
        }

        for alert in alerts:
            if alert.source_ip and not alert.source_ip.startswith("10."):
                iocs["ip_addresses"].add(alert.source_ip)

            if alert.evidence:
                try:
                    evidence = json.loads(alert.evidence)
                    if evidence.get("process"):
                        iocs["processes"].add(evidence["process"])
                    if evidence.get("file_path"):
                        iocs["file_paths"].add(evidence["file_path"])
                    if evidence.get("registry_key"):
                        iocs["registry_keys"].add(evidence["registry_key"])
                    if evidence.get("command_line"):
                        iocs["command_lines"].add(evidence["command_line"])
                except json.JSONDecodeError:
                    pass

            if alert.username:
                iocs["user_accounts"].add(alert.username)

        # Convert sets to lists for JSON serialization
        return {k: list(v) for k, v in iocs.items() if v}

    def _extract_iocs_from_alert(self, alert: Alert) -> dict:
        """Extract IOCs from a single alert."""
        return self._extract_iocs([alert])

    def _calculate_risk_score(self, alert: Alert, correlated: list) -> dict:
        """Calculate risk score based on alert severity and correlation."""
        severity_scores = {"critical": 40, "high": 30, "medium": 20, "low": 10, "informational": 5}
        base_score = severity_scores.get(alert.severity, 10)

        # Correlation bonus
        correlation_bonus = min(len(correlated) * 5, 30)

        # MITRE bonus (if mapped)
        mitre_bonus = 10 if alert.mitre_technique else 0

        total = min(base_score + correlation_bonus + mitre_bonus, 100)

        risk_level = "critical" if total >= 80 else "high" if total >= 60 else "medium" if total >= 40 else "low"

        return {
            "score": total,
            "level": risk_level,
            "breakdown": {
                "base_severity": base_score,
                "correlation_bonus": correlation_bonus,
                "mitre_mapping": mitre_bonus,
            },
        }

    def _generate_summary(self, alerts: list, timeline: list, iocs: dict, techniques: list) -> str:
        """Generate a narrative investigation summary."""
        host_counts = defaultdict(int)
        for a in alerts:
            if a.hostname:
                host_counts[a.hostname] += 1

        primary_host = max(host_counts, key=host_counts.get) if host_counts else "Unknown"
        severities = [a.severity for a in alerts]
        critical_count = severities.count("critical")
        high_count = severities.count("high")

        summary = f"Investigation involves {len(alerts)} correlated alerts "
        summary += f"across {len(host_counts)} host(s), primarily affecting {primary_host}. "
        summary += f"Severity breakdown: {critical_count} critical, {high_count} high. "

        if techniques:
            summary += f"MITRE ATT&CK techniques observed: {', '.join(techniques)}. "

        if iocs:
            ioc_count = sum(len(v) for v in iocs.values())
            summary += f"Total IOCs extracted: {ioc_count}. "

        if timeline:
            start = timeline[0]["timestamp"]
            end = timeline[-1]["timestamp"]
            summary += f"Activity window: {start} to {end}."

        return summary

    def _generate_recommendations(self, alerts: list, techniques: list) -> str:
        """Generate actionable recommendations based on detected techniques."""
        recommendations = []

        technique_actions = {
            "T1110": "• Enforce account lockout policies\n• Implement MFA on all remote access\n• Review failed logon patterns and block source IPs",
            "T1003": "• Enable Credential Guard\n• Restrict LSASS access with PPL\n• Monitor for suspicious LSASS access patterns",
            "T1003.006": "• Restrict DCSync permissions to DC accounts only\n• Monitor Event ID 4662 for replication requests\n• Audit Domain Admin group membership",
            "T1021": "• Implement network segmentation\n• Restrict lateral movement via host-based firewalls\n• Deploy privileged access workstations (PAWs)",
            "T1059.001": "• Enable PowerShell Constrained Language Mode\n• Implement Script Block Logging\n• Block encoded PowerShell execution via AppLocker",
            "T1547.001": "• Monitor registry run key modifications\n• Implement application whitelisting\n• Regular audit of startup entries",
            "T1558.003": "• Use AES encryption for Kerberos\n• Rotate service account passwords regularly\n• Implement Group Managed Service Accounts (gMSA)",
            "T1041": "• Implement DLP controls\n• Monitor for unusual outbound data volumes\n• Block suspicious external IP communications",
            "T1486": "• Maintain offline backups\n• Implement volume shadow copy protection\n• Deploy endpoint detection and response (EDR)",
            "T1562.001": "• Implement tamper protection\n• Monitor for security tool process termination\n• Alert on event log clearing",
        }

        recommendations.append("=== IMMEDIATE ACTIONS ===")
        recommendations.append("• Isolate affected hosts from the network")
        recommendations.append("• Reset credentials for compromised accounts")
        recommendations.append("• Preserve evidence for forensic analysis")
        recommendations.append("")
        recommendations.append("=== TECHNIQUE-SPECIFIC REMEDIATION ===")

        for technique in techniques:
            if technique in technique_actions:
                recommendations.append(f"\n[{technique}]")
                recommendations.append(technique_actions[technique])

        recommendations.append("\n=== LONG-TERM IMPROVEMENTS ===")
        recommendations.append("• Review and harden Active Directory security")
        recommendations.append("• Implement zero trust network architecture")
        recommendations.append("• Enhance monitoring and logging coverage")
        recommendations.append("• Conduct regular purple team exercises")

        return "\n".join(recommendations)

    def _get_alert_recommendations(self, alert: Alert) -> list:
        """Get quick recommendations for a single alert."""
        recs = ["Verify if activity is authorized", "Check for similar activity on other hosts"]

        severity_recs = {
            "critical": ["Escalate to incident response team immediately", "Isolate affected system"],
            "high": ["Investigate within 1 hour", "Check for lateral movement indicators"],
            "medium": ["Review within 4 hours", "Correlate with other alerts"],
            "low": ["Review during next shift", "Add to watchlist"],
        }

        recs.extend(severity_recs.get(alert.severity, []))
        return recs

    def get_investigation_report(self, investigation_id: int) -> dict:
        """Generate a comprehensive investigation report."""
        inv = Investigation.query.get(investigation_id)
        if not inv:
            return {"error": "Investigation not found"}

        return {
            "investigation": inv.to_dict(),
            "timeline": json.loads(inv.timeline) if inv.timeline else [],
            "iocs": json.loads(inv.iocs) if inv.iocs else {},
            "mitre_techniques": json.loads(inv.mitre_techniques) if inv.mitre_techniques else [],
            "recommendations": inv.recommendations,
            "alerts": [a.to_dict() for a in inv.alerts],
        }

    def close_investigation(self, investigation_id: int, summary: str = "") -> Investigation:
        """Close an investigation with final summary."""
        inv = Investigation.query.get(investigation_id)
        if inv:
            inv.status = "closed"
            if summary:
                inv.summary = summary
            for alert in inv.alerts:
                alert.status = "resolved"
            db.session.commit()
        return inv
