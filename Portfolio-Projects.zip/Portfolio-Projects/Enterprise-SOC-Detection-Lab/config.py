"""
Enterprise SOC Detection Lab — Configuration
"""
import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "soc-lab-secret-key-change-in-production")
    SQLALCHEMY_DATABASE_URI = f"sqlite:///{os.path.join(BASE_DIR, 'instance', 'soc_lab.db')}"
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Detection Engine
    SIGMA_RULES_DIR = os.path.join(BASE_DIR, "rules", "sigma")
    CUSTOM_RULES_DIR = os.path.join(BASE_DIR, "rules", "custom")
    SAMPLE_LOGS_DIR = os.path.join(BASE_DIR, "sample_logs")
    REPORTS_DIR = os.path.join(BASE_DIR, "reports")

    # Alert thresholds
    ALERT_SEVERITY_LEVELS = {
        "critical": 4,
        "high": 3,
        "medium": 2,
        "low": 1,
        "informational": 0,
    }

    LOG_RETENTION_DAYS = 90
    MAX_ALERTS_DISPLAY = 500
