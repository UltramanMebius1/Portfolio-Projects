"""
Enterprise SOC Detection Lab — Detection Engine
Core detection engine supporting Sigma-style rules, custom YAML rules, and anomaly detection.
"""

import os
import re
import json
import yaml
from datetime import datetime
from models import db, LogEntry, Alert, DetectionRule
from mitre_attack import MitreAttackMapper


class SigmaRule:
    """Represents a parsed Sigma-style detection rule."""

    def __init__(self, rule_data: dict, source_file: str = ""):
        self.title = rule_data.get("title", "Unknown Rule")
        self.rule_id = rule_data.get("id", "")
        self.status = rule_data.get("status", "experimental")
        self.description = rule_data.get("description", "")
        self.level = rule_data.get("level", "medium")
        self.author = rule_data.get("author", "SOC Lab")
        self.tags = rule_data.get("tags", [])
        self.logsource = rule_data.get("logsource", {})
        self.detection = rule_data.get("detection", {})
        self.falsepositives = rule_data.get("falsepositives", [])
        self.source_file = source_file

        # Extract MITRE from tags
        self.mitre_tactic = ""
        self.mitre_technique = ""
        for tag in self.tags:
            if tag.startswith("attack.t"):
                self.mitre_technique = tag.replace("attack.", "").upper()
            elif tag.startswith("attack."):
                tactic = tag.replace("attack.", "").replace("_", " ").title()
                self.mitre_tactic = tactic

    def evaluate(self, log_entry: LogEntry) -> bool:
        """Evaluate this rule against a log entry."""
        selection = self.detection.get("selection", {})
        condition = self.detection.get("condition", "selection")

        # Check logsource match
        if self.logsource:
            if self.logsource.get("product") and self.logsource["product"] != "windows":
                if log_entry.source not in ["windows_security", "sysmon"]:
                    return False

        # Evaluate selection criteria
        match = self._evaluate_selection(selection, log_entry)

        # Handle filter (exclusion)
        if "filter" in self.detection and "not filter" in condition:
            filter_match = self._evaluate_selection(self.detection["filter"], log_entry)
            return match and not filter_match

        return match

    def _evaluate_selection(self, selection: dict, log_entry: LogEntry) -> bool:
        """Evaluate selection criteria against a log entry."""
        if not selection:
            return False

        for field, pattern in selection.items():
            log_value = self._get_log_field(field, log_entry)
            if log_value is None:
                return False

            if isinstance(pattern, list):
                # Any of the patterns should match
                if not any(self._match_value(str(log_value), str(p)) for p in pattern):
                    return False
            else:
                if not self._match_value(str(log_value), str(pattern)):
                    return False

        return True

    def _get_log_field(self, field: str, log_entry: LogEntry) -> str:
        """Map Sigma field names to LogEntry attributes."""
        field_map = {
            "EventID": "event_id",
            "event_id": "event_id",
            "Image": "process_name",
            "CommandLine": "command_line",
            "ParentImage": "parent_process",
            "TargetFilename": "file_path",
            "TargetObject": "registry_key",
            "User": "username",
            "SourceIp": "source_ip",
            "DestinationIp": "dest_ip",
            "DestinationPort": "dest_port",
            "Hashes": "hash_sha256",
            "Description": "description",
        }
        attr = field_map.get(field, field.lower())
        return str(getattr(log_entry, attr, None) or "")

    def _match_value(self, log_value: str, pattern: str) -> bool:
        """Match a log value against a pattern (supports wildcards)."""
        log_lower = log_value.lower()
        pattern_lower = str(pattern).lower()

        if "*" in pattern_lower:
            regex = "^" + re.escape(pattern_lower).replace(r"\*", ".*") + "$"
            return bool(re.match(regex, log_lower))
        return pattern_lower in log_lower


class DetectionEngine:
    """Core detection engine that loads rules and scans logs for threats."""

    def __init__(self, app=None):
        self.rules = []
        self.mitre_mapper = MitreAttackMapper()
        self.stats = {
            "total_scanned": 0,
            "total_alerts": 0,
            "rules_loaded": 0,
            "by_severity": {"critical": 0, "high": 0, "medium": 0, "low": 0},
        }
        if app:
            self.load_rules(app.config)

    def load_rules(self, config: dict = None):
        """Load all detection rules from the rules directories."""
        rules_dirs = []
        if config:
            sigma_dir = config.get("SIGMA_RULES_DIR", "rules/sigma")
            custom_dir = config.get("CUSTOM_RULES_DIR", "rules/custom")
            rules_dirs = [sigma_dir, custom_dir]
        else:
            rules_dirs = ["rules/sigma", "rules/custom"]

        for rules_dir in rules_dirs:
            if not os.path.exists(rules_dir):
                continue
            for filename in os.listdir(rules_dir):
                if filename.endswith((".yml", ".yaml")):
                    filepath = os.path.join(rules_dir, filename)
                    try:
                        with open(filepath, "r") as f:
                            rule_data = yaml.safe_load(f)
                        if rule_data:
                            rule = SigmaRule(rule_data, source_file=filepath)
                            self.rules.append(rule)
                    except Exception as e:
                        print(f"[!] Error loading rule {filename}: {e}")

        self.stats["rules_loaded"] = len(self.rules)
        print(f"[+] Loaded {len(self.rules)} detection rules")

    def load_builtin_rules(self):
        """Load hardcoded detection rules for environments without YAML files."""
        builtin = [
            {
                "title": "Brute Force Authentication",
                "id": "BF-001",
                "description": "Detects multiple failed authentication attempts indicating brute force",
                "level": "high",
                "tags": ["attack.credential_access", "attack.t1110"],
                "logsource": {"product": "windows", "service": "security"},
                "detection": {
                    "selection": {"event_id": "4625"},
                    "condition": "selection",
                },
            },
            {
                "title": "Credential Dumping — Mimikatz",
                "id": "CD-001",
                "description": "Detects mimikatz credential dumping tool execution",
                "level": "critical",
                "tags": ["attack.credential_access", "attack.t1003"],
                "logsource": {"product": "windows"},
                "detection": {
                    "selection": {"CommandLine": "*mimikatz*"},
                    "condition": "selection",
                },
            },
            {
                "title": "Suspicious PowerShell Encoded Command",
                "id": "PS-001",
                "description": "Detects encoded PowerShell commands often used by attackers",
                "level": "high",
                "tags": ["attack.execution", "attack.t1059.001"],
                "logsource": {"product": "windows"},
                "detection": {
                    "selection": {"CommandLine": "*-Enc*"},
                    "condition": "selection",
                },
            },
            {
                "title": "PowerShell Download Cradle",
                "id": "PS-002",
                "description": "Detects PowerShell download cradle for remote payload execution",
                "level": "high",
                "tags": ["attack.execution", "attack.t1059.001"],
                "logsource": {"product": "windows"},
                "detection": {
                    "selection": {"CommandLine": "*DownloadString*"},
                    "condition": "selection",
                },
            },
            {
                "title": "Registry Run Key Persistence",
                "id": "PER-001",
                "description": "Detects registry modifications for persistence via run keys",
                "level": "high",
                "tags": ["attack.persistence", "attack.t1547.001"],
                "logsource": {"product": "windows"},
                "detection": {
                    "selection": {"CommandLine": "*CurrentVersion\\Run*"},
                    "condition": "selection",
                },
            },
            {
                "title": "Lateral Movement — PsExec",
                "id": "LM-001",
                "description": "Detects PsExec usage for lateral movement",
                "level": "high",
                "tags": ["attack.lateral_movement", "attack.t1021"],
                "logsource": {"product": "windows"},
                "detection": {
                    "selection": {"CommandLine": "*psexec*"},
                    "condition": "selection",
                },
            },
            {
                "title": "Kerberoasting — TGS Request",
                "id": "KRB-001",
                "description": "Detects Kerberoasting through TGS ticket requests with RC4 encryption",
                "level": "high",
                "tags": ["attack.credential_access", "attack.t1558.003"],
                "logsource": {"product": "windows", "service": "security"},
                "detection": {
                    "selection": {"event_id": "4769", "Description": "*Kerberoasting*"},
                    "condition": "selection",
                },
            },
            {
                "title": "DCSync Attack",
                "id": "DC-001",
                "description": "Detects DCSync attack — directory replication from non-DC",
                "level": "critical",
                "tags": ["attack.credential_access", "attack.t1003.006"],
                "logsource": {"product": "windows", "service": "security"},
                "detection": {
                    "selection": {"Description": "*DCSync*"},
                    "condition": "selection",
                },
            },
            {
                "title": "Volume Shadow Copy Deletion",
                "id": "RAN-001",
                "description": "Detects vssadmin shadow copy deletion — ransomware indicator",
                "level": "critical",
                "tags": ["attack.impact", "attack.t1486"],
                "logsource": {"product": "windows"},
                "detection": {
                    "selection": {"CommandLine": "*vssadmin*delete*shadows*"},
                    "condition": "selection",
                },
            },
            {
                "title": "Security Tool Disabled",
                "id": "DE-001",
                "description": "Detects disabling of security monitoring tools",
                "level": "critical",
                "tags": ["attack.defense_evasion", "attack.t1562.001"],
                "logsource": {"product": "windows"},
                "detection": {
                    "selection": {"CommandLine": "*DisableRealtimeMonitoring*"},
                    "condition": "selection",
                },
            },
            {
                "title": "Security Event Log Cleared",
                "id": "DE-002",
                "description": "Detects clearing of Windows security event log",
                "level": "critical",
                "tags": ["attack.defense_evasion", "attack.t1070"],
                "logsource": {"product": "windows"},
                "detection": {
                    "selection": {"CommandLine": "*wevtutil*cl*Security*"},
                    "condition": "selection",
                },
            },
            {
                "title": "Large Outbound Data Transfer",
                "id": "EX-001",
                "description": "Detects large outbound data transfers indicating exfiltration",
                "level": "high",
                "tags": ["attack.exfiltration", "attack.t1041"],
                "logsource": {"product": "firewall"},
                "detection": {
                    "selection": {"Description": "*Large outbound*"},
                    "condition": "selection",
                },
            },
            {
                "title": "LSASS Memory Access",
                "id": "CD-002",
                "description": "Detects suspicious access to LSASS process memory",
                "level": "critical",
                "tags": ["attack.credential_access", "attack.t1003"],
                "logsource": {"product": "windows"},
                "detection": {
                    "selection": {"Description": "*lsass*credential*"},
                    "condition": "selection",
                },
            },
            {
                "title": "Ransomware File Encryption",
                "id": "RAN-002",
                "description": "Detects mass file encryption typical of ransomware",
                "level": "critical",
                "tags": ["attack.impact", "attack.t1486"],
                "logsource": {"product": "windows"},
                "detection": {
                    "selection": {"Description": "*File encryption*"},
                    "condition": "selection",
                },
            },
            {
                "title": "Firewall Disabled",
                "id": "DE-003",
                "description": "Detects Windows Firewall being disabled",
                "level": "high",
                "tags": ["attack.defense_evasion", "attack.t1562.001"],
                "logsource": {"product": "windows"},
                "detection": {
                    "selection": {"CommandLine": "*advfirewall*state off*"},
                    "condition": "selection",
                },
            },
        ]

        for rule_data in builtin:
            rule = SigmaRule(rule_data, source_file="builtin")
            self.rules.append(rule)

        self.stats["rules_loaded"] = len(self.rules)

    def scan_log(self, log_entry: LogEntry) -> list:
        """Scan a single log entry against all loaded rules."""
        alerts = []
        for rule in self.rules:
            if rule.evaluate(log_entry):
                alert = Alert(
                    timestamp=log_entry.timestamp,
                    rule_name=rule.title,
                    rule_id=rule.rule_id,
                    severity=rule.level,
                    description=rule.description,
                    mitre_tactic=rule.mitre_tactic,
                    mitre_technique=rule.mitre_technique,
                    source_ip=log_entry.source_ip,
                    dest_ip=log_entry.dest_ip,
                    hostname=log_entry.hostname,
                    username=log_entry.username,
                    evidence=json.dumps({
                        "process": log_entry.process_name,
                        "command_line": log_entry.command_line,
                        "file_path": log_entry.file_path,
                        "registry_key": log_entry.registry_key,
                        "raw_log": log_entry.raw_log,
                    }),
                    log_entry_id=log_entry.id,
                    status="new",
                )
                alerts.append(alert)

                # Update MITRE coverage
                if rule.mitre_technique:
                    self.mitre_mapper.update_coverage(rule.mitre_technique)

                # Update stats
                self.stats["total_alerts"] += 1
                sev = rule.level.lower()
                if sev in self.stats["by_severity"]:
                    self.stats["by_severity"][sev] += 1

        return alerts

    def scan_all_logs(self) -> list:
        """Scan all log entries in the database."""
        all_alerts = []
        logs = LogEntry.query.all()
        self.stats["total_scanned"] = len(logs)

        for log in logs:
            alerts = self.scan_log(log)
            all_alerts.extend(alerts)

        # Persist alerts
        for alert in all_alerts:
            db.session.add(alert)
        db.session.commit()

        # Register rules in database
        self._register_rules()

        return all_alerts

    def _register_rules(self):
        """Register all loaded rules in the detection_rules table."""
        for rule in self.rules:
            existing = DetectionRule.query.filter_by(rule_id=rule.rule_id).first()
            if not existing:
                db_rule = DetectionRule(
                    rule_id=rule.rule_id,
                    name=rule.title,
                    description=rule.description,
                    severity=rule.level,
                    mitre_tactic=rule.mitre_tactic,
                    mitre_technique=rule.mitre_technique,
                    rule_type="sigma" if "sigma" in (rule.source_file or "") else "custom",
                    source_file=rule.source_file,
                )
                db.session.add(db_rule)
        db.session.commit()

    def get_stats(self) -> dict:
        """Return detection engine statistics."""
        return {
            **self.stats,
            "mitre_coverage": self.mitre_mapper.get_coverage_percentage(),
            "mitre_matrix": self.mitre_mapper.get_coverage_matrix(),
        }
