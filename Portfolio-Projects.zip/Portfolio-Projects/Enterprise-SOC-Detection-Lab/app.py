"""
Enterprise SOC Detection Lab — Flask Web Application & Dashboard
Professional SOC analyst interface with alert management, investigations, and MITRE heatmap.
"""

import os
import json
from datetime import datetime
from flask import Flask, render_template_string, request, jsonify, redirect, url_for
from config import Config
from models import db, LogEntry, Alert, Investigation, DetectionRule
from detection_engine import DetectionEngine
from attack_simulator import AttackSimulator
from investigation import InvestigationManager
from mitre_attack import MitreAttackMapper, MITRE_TACTICS, MITRE_TECHNIQUES

app = Flask(__name__)
app.config.from_object(Config)

# Ensure instance directory exists
os.makedirs(os.path.join(Config.BASE_DIR, "instance"), exist_ok=True)
os.makedirs(Config.REPORTS_DIR, exist_ok=True) if hasattr(Config, "REPORTS_DIR") else None

db.init_app(app)

detection_engine = DetectionEngine()
investigation_mgr = InvestigationManager()

# ── HTML Template ──────────────────────────────────────────────────────────
DASHBOARD_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise SOC Detection Lab</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --bg-primary: #0a0e1a; --bg-secondary: #111827; --bg-card: #1a1f35;
            --text-primary: #e2e8f0; --text-secondary: #94a3b8;
            --accent-blue: #3b82f6; --accent-purple: #8b5cf6;
            --severity-critical: #ef4444; --severity-high: #f97316;
            --severity-medium: #eab308; --severity-low: #22c55e;
            --border: #2d3748;
        }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg-primary); color: var(--text-primary); }
        .header { background: linear-gradient(135deg, #1a1f35 0%, #0f172a 100%); border-bottom: 1px solid var(--border); padding: 16px 32px; display: flex; align-items: center; justify-content: space-between; }
        .header h1 { font-size: 1.5rem; background: linear-gradient(135deg, var(--accent-blue), var(--accent-purple)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .header .status { display: flex; gap: 16px; align-items: center; }
        .header .status .indicator { width: 8px; height: 8px; border-radius: 50%; background: var(--severity-low); animation: pulse 2s infinite; display: inline-block; margin-right: 6px; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        .nav { background: var(--bg-secondary); border-bottom: 1px solid var(--border); display: flex; gap: 0; padding: 0 32px; }
        .nav a { color: var(--text-secondary); text-decoration: none; padding: 12px 20px; font-size: 0.875rem; font-weight: 500; border-bottom: 2px solid transparent; transition: all 0.2s; }
        .nav a:hover, .nav a.active { color: var(--accent-blue); border-bottom-color: var(--accent-blue); }
        .container { max-width: 1400px; margin: 0 auto; padding: 24px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 20px; transition: transform 0.2s, box-shadow 0.2s; }
        .stat-card:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(0,0,0,0.3); }
        .stat-card .label { font-size: 0.75rem; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; }
        .stat-card .value { font-size: 2rem; font-weight: 700; }
        .stat-card .value.critical { color: var(--severity-critical); }
        .stat-card .value.high { color: var(--severity-high); }
        .stat-card .value.medium { color: var(--severity-medium); }
        .stat-card .value.blue { color: var(--accent-blue); }
        .stat-card .value.purple { color: var(--accent-purple); }
        .card { background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 24px; margin-bottom: 24px; }
        .card h2 { font-size: 1.125rem; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }
        .card h2 .icon { font-size: 1.25rem; }
        table { width: 100%; border-collapse: collapse; }
        thead th { text-align: left; padding: 12px; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: var(--text-secondary); border-bottom: 1px solid var(--border); }
        tbody td { padding: 12px; border-bottom: 1px solid var(--border); font-size: 0.875rem; }
        tbody tr:hover { background: rgba(59, 130, 246, 0.05); }
        .badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 0.7rem; font-weight: 600; text-transform: uppercase; }
        .badge.critical { background: rgba(239,68,68,0.15); color: var(--severity-critical); border: 1px solid rgba(239,68,68,0.3); }
        .badge.high { background: rgba(249,115,22,0.15); color: var(--severity-high); border: 1px solid rgba(249,115,22,0.3); }
        .badge.medium { background: rgba(234,179,8,0.15); color: var(--severity-medium); border: 1px solid rgba(234,179,8,0.3); }
        .badge.low { background: rgba(34,197,94,0.15); color: var(--severity-low); border: 1px solid rgba(34,197,94,0.3); }
        .badge.new { background: rgba(59,130,246,0.15); color: var(--accent-blue); border: 1px solid rgba(59,130,246,0.3); }
        .badge.investigating { background: rgba(139,92,246,0.15); color: var(--accent-purple); border: 1px solid rgba(139,92,246,0.3); }
        .badge.resolved { background: rgba(34,197,94,0.15); color: var(--severity-low); border: 1px solid rgba(34,197,94,0.3); }
        .btn { padding: 8px 16px; border-radius: 8px; border: none; cursor: pointer; font-size: 0.875rem; font-weight: 500; transition: all 0.2s; text-decoration: none; display: inline-block; }
        .btn-primary { background: var(--accent-blue); color: white; }
        .btn-primary:hover { background: #2563eb; }
        .btn-danger { background: var(--severity-critical); color: white; }
        .btn-danger:hover { background: #dc2626; }
        .btn-success { background: var(--severity-low); color: white; }
        .btn-success:hover { background: #16a34a; }
        .btn-sm { padding: 4px 12px; font-size: 0.75rem; }
        .mitre-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 8px; }
        .mitre-cell { padding: 8px; border-radius: 6px; text-align: center; font-size: 0.7rem; transition: transform 0.2s; cursor: pointer; }
        .mitre-cell:hover { transform: scale(1.05); }
        .mitre-cell.covered { background: rgba(59,130,246,0.2); border: 1px solid rgba(59,130,246,0.4); color: var(--accent-blue); }
        .mitre-cell.uncovered { background: rgba(100,100,100,0.1); border: 1px solid var(--border); color: var(--text-secondary); }
        .mitre-cell .tech-id { font-weight: 700; display: block; }
        .mitre-cell .tech-name { font-size: 0.6rem; display: block; margin-top: 2px; }
        .tactic-group { margin-bottom: 16px; }
        .tactic-group h3 { font-size: 0.875rem; color: var(--accent-purple); margin-bottom: 8px; }
        .timeline-item { display: flex; gap: 16px; padding: 12px 0; border-left: 2px solid var(--border); padding-left: 20px; position: relative; }
        .timeline-item::before { content: ''; width: 10px; height: 10px; border-radius: 50%; background: var(--accent-blue); position: absolute; left: -6px; top: 16px; }
        .timeline-item.critical::before { background: var(--severity-critical); }
        .timeline-item.high::before { background: var(--severity-high); }
        .timeline-ts { font-size: 0.75rem; color: var(--text-secondary); white-space: nowrap; min-width: 140px; }
        .timeline-content { flex: 1; }
        .timeline-content .event { font-weight: 600; }
        .timeline-content .detail { font-size: 0.8rem; color: var(--text-secondary); margin-top: 4px; }
        .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
        @media (max-width: 768px) { .two-col { grid-template-columns: 1fr; } .stats-grid { grid-template-columns: repeat(2, 1fr); } }
        .empty { text-align: center; padding: 40px; color: var(--text-secondary); }
        .empty .icon { font-size: 2rem; margin-bottom: 12px; }
        .ioc-list { list-style: none; }
        .ioc-list li { padding: 6px 12px; margin: 4px 0; background: rgba(239,68,68,0.08); border-left: 3px solid var(--severity-critical); border-radius: 4px; font-family: 'Courier New', monospace; font-size: 0.8rem; }
        .flash { padding: 12px 20px; border-radius: 8px; margin-bottom: 16px; font-size: 0.875rem; }
        .flash.success { background: rgba(34,197,94,0.15); border: 1px solid rgba(34,197,94,0.3); color: var(--severity-low); }
        .flash.error { background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.3); color: var(--severity-critical); }
    </style>
</head>
<body>
    <div class="header">
        <h1>🛡️ Enterprise SOC Detection Lab</h1>
        <div class="status">
            <span><span class="indicator"></span> Engine Active</span>
            <span style="color:var(--text-secondary); font-size:0.8rem;">{{ current_time }}</span>
        </div>
    </div>
    <div class="nav">
        <a href="/" class="{{ 'active' if page == 'dashboard' }}">Dashboard</a>
        <a href="/alerts" class="{{ 'active' if page == 'alerts' }}">Alerts</a>
        <a href="/investigations" class="{{ 'active' if page == 'investigations' }}">Investigations</a>
        <a href="/mitre" class="{{ 'active' if page == 'mitre' }}">MITRE ATT&CK</a>
        <a href="/rules" class="{{ 'active' if page == 'rules' }}">Detection Rules</a>
        <a href="/logs" class="{{ 'active' if page == 'logs' }}">Log Explorer</a>
    </div>
    <div class="container">
        {% if flash_msg %}
        <div class="flash success">{{ flash_msg }}</div>
        {% endif %}
        {% block content %}{% endblock %}
    </div>
</body>
</html>
"""

DASHBOARD_CONTENT = """
{% extends "base" %}
{% block content %}
<div class="stats-grid">
    <div class="stat-card"><div class="label">Total Alerts</div><div class="value blue">{{ stats.total_alerts }}</div></div>
    <div class="stat-card"><div class="label">Critical</div><div class="value critical">{{ stats.critical }}</div></div>
    <div class="stat-card"><div class="label">High</div><div class="value high">{{ stats.high }}</div></div>
    <div class="stat-card"><div class="label">Logs Ingested</div><div class="value purple">{{ stats.total_logs }}</div></div>
    <div class="stat-card"><div class="label">Detection Rules</div><div class="value blue">{{ stats.rules_count }}</div></div>
    <div class="stat-card"><div class="label">MITRE Coverage</div><div class="value purple">{{ stats.mitre_coverage }}%</div></div>
</div>
<div class="two-col">
    <div class="card">
        <h2><span class="icon">🚨</span> Recent Alerts</h2>
        {% if recent_alerts %}
        <table>
            <thead><tr><th>Time</th><th>Rule</th><th>Severity</th><th>Host</th><th>Status</th></tr></thead>
            <tbody>
            {% for alert in recent_alerts %}
            <tr>
                <td style="font-size:0.75rem;color:var(--text-secondary)">{{ alert.timestamp.strftime('%m/%d %H:%M') }}</td>
                <td>{{ alert.rule_name[:40] }}</td>
                <td><span class="badge {{ alert.severity }}">{{ alert.severity }}</span></td>
                <td>{{ alert.hostname }}</td>
                <td><span class="badge {{ alert.status }}">{{ alert.status }}</span></td>
            </tr>
            {% endfor %}
            </tbody>
        </table>
        {% else %}
        <div class="empty"><div class="icon">📭</div><p>No alerts yet. Run attack simulations to generate alerts.</p></div>
        {% endif %}
    </div>
    <div class="card">
        <h2><span class="icon">📊</span> Severity Distribution</h2>
        <div style="display:flex;flex-direction:column;gap:12px;padding:20px 0;">
            {% for sev, count in severity_dist.items() %}
            <div>
                <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
                    <span class="badge {{ sev }}">{{ sev }}</span>
                    <span style="font-size:0.875rem;font-weight:600;">{{ count }}</span>
                </div>
                <div style="background:var(--border);height:8px;border-radius:4px;overflow:hidden;">
                    <div style="height:100%;width:{{ (count / (stats.total_alerts or 1) * 100)|int }}%;border-radius:4px;
                        background:{% if sev == 'critical' %}var(--severity-critical){% elif sev == 'high' %}var(--severity-high){% elif sev == 'medium' %}var(--severity-medium){% else %}var(--severity-low){% endif %};
                        transition:width 0.5s;"></div>
                </div>
            </div>
            {% endfor %}
        </div>
    </div>
</div>
<div class="card">
    <h2><span class="icon">⚡</span> Quick Actions</h2>
    <div style="display:flex;gap:12px;flex-wrap:wrap;">
        <a href="/simulate" class="btn btn-danger">🎯 Run Attack Simulations</a>
        <a href="/scan" class="btn btn-primary">🔍 Run Detection Scan</a>
        <a href="/mitre" class="btn btn-primary">🗺️ MITRE Coverage</a>
    </div>
</div>
{% endblock %}
"""

ALERTS_CONTENT = """
{% extends "base" %}
{% block content %}
<div class="card">
    <h2><span class="icon">🚨</span> Alert Queue ({{ alerts|length }})</h2>
    <div style="margin-bottom:16px;display:flex;gap:8px;">
        <a href="/alerts" class="btn btn-sm btn-primary">All</a>
        <a href="/alerts?severity=critical" class="btn btn-sm btn-danger">Critical</a>
        <a href="/alerts?severity=high" class="btn btn-sm" style="background:var(--severity-high);color:white;">High</a>
        <a href="/alerts?status=new" class="btn btn-sm" style="background:var(--accent-purple);color:white;">New</a>
    </div>
    {% if alerts %}
    <table>
        <thead><tr><th>ID</th><th>Time</th><th>Rule</th><th>Severity</th><th>MITRE</th><th>Host</th><th>User</th><th>Status</th><th>Action</th></tr></thead>
        <tbody>
        {% for alert in alerts %}
        <tr>
            <td>#{{ alert.id }}</td>
            <td style="font-size:0.75rem;color:var(--text-secondary)">{{ alert.timestamp.strftime('%Y-%m-%d %H:%M:%S') }}</td>
            <td>{{ alert.rule_name }}</td>
            <td><span class="badge {{ alert.severity }}">{{ alert.severity }}</span></td>
            <td style="font-family:monospace;font-size:0.75rem;">{{ alert.mitre_technique or '-' }}</td>
            <td>{{ alert.hostname or '-' }}</td>
            <td>{{ alert.username or '-' }}</td>
            <td><span class="badge {{ alert.status }}">{{ alert.status }}</span></td>
            <td><a href="/alert/{{ alert.id }}" class="btn btn-sm btn-primary">Investigate</a></td>
        </tr>
        {% endfor %}
        </tbody>
    </table>
    {% else %}
    <div class="empty"><div class="icon">✅</div><p>No alerts matching filters.</p></div>
    {% endif %}
</div>
{% endblock %}
"""

ALERT_DETAIL_CONTENT = """
{% extends "base" %}
{% block content %}
<h2 style="margin-bottom:16px;">🔎 Alert #{{ report.alert.id }} Investigation</h2>
<div class="stats-grid">
    <div class="stat-card"><div class="label">Risk Score</div><div class="value {{ report.risk_score.level }}">{{ report.risk_score.score }}/100</div></div>
    <div class="stat-card"><div class="label">Severity</div><div class="value {{ report.alert.severity }}">{{ report.alert.severity|upper }}</div></div>
    <div class="stat-card"><div class="label">Correlated Alerts</div><div class="value blue">{{ report.correlated_count }}</div></div>
    <div class="stat-card"><div class="label">MITRE Technique</div><div class="value purple">{{ report.alert.mitre_technique or 'N/A' }}</div></div>
</div>
<div class="two-col">
    <div class="card">
        <h2><span class="icon">📋</span> Alert Details</h2>
        <table>
            <tr><td style="color:var(--text-secondary)">Rule</td><td>{{ report.alert.rule_name }}</td></tr>
            <tr><td style="color:var(--text-secondary)">Description</td><td>{{ report.alert.description }}</td></tr>
            <tr><td style="color:var(--text-secondary)">Host</td><td>{{ report.alert.hostname }}</td></tr>
            <tr><td style="color:var(--text-secondary)">User</td><td>{{ report.alert.username }}</td></tr>
            <tr><td style="color:var(--text-secondary)">Source IP</td><td>{{ report.alert.source_ip }}</td></tr>
            <tr><td style="color:var(--text-secondary)">MITRE Tactic</td><td>{{ report.alert.mitre_tactic }}</td></tr>
            <tr><td style="color:var(--text-secondary)">Status</td><td><span class="badge {{ report.alert.status }}">{{ report.alert.status }}</span></td></tr>
        </table>
    </div>
    <div class="card">
        <h2><span class="icon">🔑</span> Indicators of Compromise</h2>
        {% if report.iocs %}
        {% for ioc_type, ioc_list in report.iocs.items() %}
        <h4 style="color:var(--accent-purple);font-size:0.8rem;margin:12px 0 4px;">{{ ioc_type|replace('_',' ')|title }}</h4>
        <ul class="ioc-list">{% for ioc in ioc_list %}<li>{{ ioc }}</li>{% endfor %}</ul>
        {% endfor %}
        {% else %}
        <p style="color:var(--text-secondary)">No IOCs extracted.</p>
        {% endif %}
    </div>
</div>
<div class="card">
    <h2><span class="icon">📐</span> Evidence</h2>
    <pre style="background:var(--bg-primary);padding:16px;border-radius:8px;overflow-x:auto;font-size:0.8rem;color:var(--text-secondary);">{{ report.evidence | tojson(indent=2) }}</pre>
</div>
<div class="card">
    <h2><span class="icon">🛠️</span> Recommendations</h2>
    <ul style="list-style:none;">{% for rec in report.recommendations %}<li style="padding:6px 0;border-bottom:1px solid var(--border);">✅ {{ rec }}</li>{% endfor %}</ul>
</div>
<div style="margin-top:16px;display:flex;gap:12px;">
    <a href="/alert/{{ report.alert.id }}/resolve" class="btn btn-success">✅ Resolve</a>
    <a href="/alert/{{ report.alert.id }}/fp" class="btn btn-sm" style="background:var(--border);color:var(--text-primary);">False Positive</a>
    <a href="/alerts" class="btn btn-sm" style="background:var(--border);color:var(--text-primary);">← Back</a>
</div>
{% endblock %}
"""

MITRE_CONTENT = """
{% extends "base" %}
{% block content %}
<div class="stats-grid">
    <div class="stat-card"><div class="label">Total Techniques</div><div class="value blue">{{ gap.total_techniques }}</div></div>
    <div class="stat-card"><div class="label">Covered</div><div class="value" style="color:var(--severity-low)">{{ gap.covered_count }}</div></div>
    <div class="stat-card"><div class="label">Uncovered</div><div class="value critical">{{ gap.uncovered_count }}</div></div>
    <div class="stat-card"><div class="label">Coverage</div><div class="value purple">{{ gap.coverage_pct }}%</div></div>
</div>
<div class="card">
    <h2><span class="icon">🗺️</span> MITRE ATT&CK Coverage Heatmap</h2>
    {% for tactic_name, data in matrix.items() %}
    <div class="tactic-group">
        <h3>{{ tactic_name }} ({{ data.covered }}/{{ data.total }})</h3>
        <div class="mitre-grid">
        {% for tech in data.techniques %}
        <div class="mitre-cell {{ 'covered' if tech.covered else 'uncovered' }}">
            <span class="tech-id">{{ tech.id }}</span>
            <span class="tech-name">{{ tech.name }}</span>
            {% if tech.covered %}<span style="font-size:0.6rem;">{{ tech.detections }} hits</span>{% endif %}
        </div>
        {% endfor %}
        </div>
    </div>
    {% endfor %}
</div>
<div class="two-col">
    <div class="card">
        <h2 style="color:var(--severity-low)"><span class="icon">✅</span> Covered Techniques</h2>
        <table><thead><tr><th>ID</th><th>Name</th><th>Tactic</th><th>Detections</th></tr></thead><tbody>
        {% for t in gap.covered %}
        <tr><td style="font-family:monospace">{{ t.id }}</td><td>{{ t.name }}</td><td>{{ t.tactic }}</td><td>{{ t.detections }}</td></tr>
        {% endfor %}
        </tbody></table>
    </div>
    <div class="card">
        <h2 style="color:var(--severity-critical)"><span class="icon">⚠️</span> Coverage Gaps</h2>
        <table><thead><tr><th>ID</th><th>Name</th><th>Tactic</th></tr></thead><tbody>
        {% for t in gap.uncovered %}
        <tr><td style="font-family:monospace">{{ t.id }}</td><td>{{ t.name }}</td><td>{{ t.tactic }}</td></tr>
        {% endfor %}
        </tbody></table>
    </div>
</div>
{% endblock %}
"""

INVESTIGATIONS_CONTENT = """
{% extends "base" %}
{% block content %}
<div class="card">
    <h2><span class="icon">🔍</span> Investigations</h2>
    {% if investigations %}
    <table>
        <thead><tr><th>ID</th><th>Title</th><th>Created</th><th>Severity</th><th>Status</th><th>Alerts</th><th>Action</th></tr></thead>
        <tbody>
        {% for inv in investigations %}
        <tr>
            <td>#{{ inv.id }}</td>
            <td>{{ inv.title }}</td>
            <td style="font-size:0.75rem">{{ inv.created_at.strftime('%Y-%m-%d %H:%M') }}</td>
            <td><span class="badge {{ inv.severity }}">{{ inv.severity }}</span></td>
            <td><span class="badge {{ inv.status }}">{{ inv.status }}</span></td>
            <td>{{ inv.alerts|length }}</td>
            <td><a href="/investigation/{{ inv.id }}" class="btn btn-sm btn-primary">View</a></td>
        </tr>
        {% endfor %}
        </tbody>
    </table>
    {% else %}
    <div class="empty"><div class="icon">🔍</div><p>No investigations yet. Investigate alerts to create investigations.</p></div>
    {% endif %}
</div>
{% endblock %}
"""

RULES_CONTENT = """
{% extends "base" %}
{% block content %}
<div class="card">
    <h2><span class="icon">📜</span> Detection Rules ({{ rules|length }})</h2>
    {% if rules %}
    <table>
        <thead><tr><th>ID</th><th>Name</th><th>Severity</th><th>MITRE</th><th>Type</th><th>Hits</th><th>Status</th></tr></thead>
        <tbody>
        {% for rule in rules %}
        <tr>
            <td style="font-family:monospace;font-size:0.75rem">{{ rule.rule_id }}</td>
            <td>{{ rule.name }}</td>
            <td><span class="badge {{ rule.severity }}">{{ rule.severity }}</span></td>
            <td style="font-family:monospace;font-size:0.75rem">{{ rule.mitre_technique or '-' }}</td>
            <td>{{ rule.rule_type }}</td>
            <td>{{ rule.total_hits }}</td>
            <td><span class="badge {{ 'low' if rule.enabled else 'medium' }}">{{ 'Active' if rule.enabled else 'Disabled' }}</span></td>
        </tr>
        {% endfor %}
        </tbody>
    </table>
    {% else %}
    <div class="empty"><div class="icon">📜</div><p>Run a detection scan to register rules.</p></div>
    {% endif %}
</div>
{% endblock %}
"""

LOGS_CONTENT = """
{% extends "base" %}
{% block content %}
<div class="card">
    <h2><span class="icon">📃</span> Log Explorer ({{ logs|length }} entries)</h2>
    <div style="margin-bottom:12px;display:flex;gap:8px;">
        <a href="/logs" class="btn btn-sm btn-primary">All</a>
        <a href="/logs?source=sysmon" class="btn btn-sm" style="background:var(--border);color:var(--text-primary);">Sysmon</a>
        <a href="/logs?source=windows_security" class="btn btn-sm" style="background:var(--border);color:var(--text-primary);">WinSec</a>
        <a href="/logs?source=firewall" class="btn btn-sm" style="background:var(--border);color:var(--text-primary);">Firewall</a>
        <a href="/logs?malicious=1" class="btn btn-sm btn-danger">Malicious Only</a>
    </div>
    {% if logs %}
    <table>
        <thead><tr><th>Time</th><th>Source</th><th>EventID</th><th>Host</th><th>User</th><th>Process</th><th>Description</th><th>Mal?</th></tr></thead>
        <tbody>
        {% for log in logs %}
        <tr style="{{ 'background:rgba(239,68,68,0.05)' if log.is_malicious else '' }}">
            <td style="font-size:0.7rem;color:var(--text-secondary)">{{ log.timestamp.strftime('%m/%d %H:%M:%S') }}</td>
            <td><span class="badge low">{{ log.source }}</span></td>
            <td>{{ log.event_id or '-' }}</td>
            <td>{{ log.hostname or '-' }}</td>
            <td>{{ log.username or '-' }}</td>
            <td style="font-size:0.75rem">{{ (log.process_name or '-')[:25] }}</td>
            <td style="font-size:0.75rem">{{ (log.description or '-')[:50] }}</td>
            <td>{{ '🔴' if log.is_malicious else '🟢' }}</td>
        </tr>
        {% endfor %}
        </tbody>
    </table>
    {% else %}
    <div class="empty"><div class="icon">📃</div><p>No logs yet. Run attack simulations to generate logs.</p></div>
    {% endif %}
</div>
{% endblock %}
"""

# ── Jinja Template Setup ──────────────────────────────────────────────────
from jinja2 import BaseLoader, TemplateNotFound

class DictLoader(BaseLoader):
    def __init__(self, templates):
        self.templates = templates
    def get_source(self, environment, template):
        if template in self.templates:
            return self.templates[template], template, lambda: True
        raise TemplateNotFound(template)

TEMPLATES = {
    "base": DASHBOARD_TEMPLATE,
    "dashboard": DASHBOARD_CONTENT,
    "alerts": ALERTS_CONTENT,
    "alert_detail": ALERT_DETAIL_CONTENT,
    "mitre": MITRE_CONTENT,
    "investigations": INVESTIGATIONS_CONTENT,
    "rules": RULES_CONTENT,
    "logs": LOGS_CONTENT,
}

app.jinja_loader = DictLoader(TEMPLATES)


# ── Routes ─────────────────────────────────────────────────────────────────

@app.route("/")
def dashboard():
    total_alerts = Alert.query.count()
    critical = Alert.query.filter_by(severity="critical").count()
    high = Alert.query.filter_by(severity="high").count()
    total_logs = LogEntry.query.count()
    rules_count = DetectionRule.query.count() or len(detection_engine.rules)
    recent_alerts = Alert.query.order_by(Alert.timestamp.desc()).limit(15).all()
    severity_dist = {
        "critical": critical,
        "high": high,
        "medium": Alert.query.filter_by(severity="medium").count(),
        "low": Alert.query.filter_by(severity="low").count(),
    }
    stats = {
        "total_alerts": total_alerts, "critical": critical, "high": high,
        "total_logs": total_logs, "rules_count": rules_count,
        "mitre_coverage": detection_engine.mitre_mapper.get_coverage_percentage(),
    }
    return render_template_string(
        "{% extends 'dashboard' %}",
        page="dashboard", stats=stats, recent_alerts=recent_alerts,
        severity_dist=severity_dist,
        current_time=datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        flash_msg=request.args.get("msg"),
    )


@app.route("/alerts")
def alerts():
    query = Alert.query.order_by(Alert.timestamp.desc())
    if request.args.get("severity"):
        query = query.filter_by(severity=request.args["severity"])
    if request.args.get("status"):
        query = query.filter_by(status=request.args["status"])
    alerts_list = query.limit(200).all()
    return render_template_string(
        "{% extends 'alerts' %}",
        page="alerts", alerts=alerts_list,
        current_time=datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        flash_msg=None,
    )


@app.route("/alert/<int:alert_id>")
def alert_detail(alert_id):
    report = investigation_mgr.investigate_alert(alert_id)
    if "error" in report:
        return redirect(url_for("alerts"))
    return render_template_string(
        "{% extends 'alert_detail' %}",
        page="alerts", report=report,
        current_time=datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        flash_msg=None,
    )


@app.route("/alert/<int:alert_id>/resolve")
def resolve_alert(alert_id):
    alert = Alert.query.get(alert_id)
    if alert:
        alert.status = "resolved"
        db.session.commit()
    return redirect(url_for("alerts", msg="Alert resolved"))


@app.route("/alert/<int:alert_id>/fp")
def false_positive(alert_id):
    alert = Alert.query.get(alert_id)
    if alert:
        alert.status = "false_positive"
        alert.false_positive = True
        db.session.commit()
    return redirect(url_for("alerts", msg="Marked as false positive"))


@app.route("/mitre")
def mitre_view():
    matrix = detection_engine.mitre_mapper.get_coverage_matrix()
    gap = detection_engine.mitre_mapper.generate_gap_analysis()
    return render_template_string(
        "{% extends 'mitre' %}",
        page="mitre", matrix=matrix, gap=gap,
        current_time=datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        flash_msg=None,
    )


@app.route("/investigations")
def investigations_view():
    investigations = Investigation.query.order_by(Investigation.created_at.desc()).all()
    return render_template_string(
        "{% extends 'investigations' %}",
        page="investigations", investigations=investigations,
        current_time=datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        flash_msg=None,
    )


@app.route("/investigation/<int:inv_id>")
def investigation_detail(inv_id):
    report = investigation_mgr.get_investigation_report(inv_id)
    return jsonify(report)


@app.route("/rules")
def rules_view():
    rules = DetectionRule.query.all()
    return render_template_string(
        "{% extends 'rules' %}",
        page="rules", rules=rules,
        current_time=datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        flash_msg=None,
    )


@app.route("/logs")
def logs_view():
    query = LogEntry.query.order_by(LogEntry.timestamp.desc())
    if request.args.get("source"):
        query = query.filter_by(source=request.args["source"])
    if request.args.get("malicious"):
        query = query.filter_by(is_malicious=True)
    logs = query.limit(300).all()
    return render_template_string(
        "{% extends 'logs' %}",
        page="logs", logs=logs,
        current_time=datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC"),
        flash_msg=None,
    )


@app.route("/simulate")
def simulate():
    simulator = AttackSimulator()
    results = simulator.run_all_scenarios()
    msg = f"Simulations complete: {len(results)} scenarios executed, {len(simulator.generated_logs)} logs generated"
    return redirect(url_for("dashboard", msg=msg))


@app.route("/scan")
def scan():
    detection_engine.load_builtin_rules()
    alerts = detection_engine.scan_all_logs()
    msg = f"Detection scan complete: {len(alerts)} alerts generated from {detection_engine.stats['rules_loaded']} rules"
    return redirect(url_for("dashboard", msg=msg))


# ── API Endpoints ──────────────────────────────────────────────────────────

@app.route("/api/stats")
def api_stats():
    return jsonify(detection_engine.get_stats())


@app.route("/api/alerts")
def api_alerts():
    alerts = Alert.query.order_by(Alert.timestamp.desc()).limit(100).all()
    return jsonify([a.to_dict() for a in alerts])


@app.route("/api/mitre/coverage")
def api_mitre_coverage():
    return jsonify(detection_engine.mitre_mapper.generate_gap_analysis())


# ── Initialization ─────────────────────────────────────────────────────────

with app.app_context():
    db.create_all()
    detection_engine.load_builtin_rules()

if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("  🛡️  Enterprise SOC Detection Lab")
    print("  Starting on http://localhost:5000")
    print("=" * 60 + "\n")
    print("Quick Start:")
    print("  1. Visit http://localhost:5000/simulate to generate attack logs")
    print("  2. Visit http://localhost:5000/scan to run detection engine")
    print("  3. Review alerts and investigate incidents\n")
    app.run(debug=True, port=5000)
