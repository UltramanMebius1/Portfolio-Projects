"""
Seed data generator for Advanced Electricity Billing System.
Creates realistic demo data including admin user, customers,
meter readings, bills, payments, and tariff slabs.
"""

import random
import uuid
from datetime import datetime, timedelta
from app import app
from models import db, User, Customer, MeterReading, Bill, Payment, Tariff, EmailLog
from billing import calculate_energy_charge, generate_bill, process_payment

# --- Seed Configuration ---

ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123'
ADMIN_EMAIL = 'admin@aebs.gov.in'

CUSTOMERS = [
    {
        'username': 'rajesh.kumar',
        'email': 'rajesh.kumar@email.com',
        'password': 'cust123',
        'full_name': 'Rajesh Kumar',
        'phone': '+91 98765 43210',
        'address': '42, MG Road, Sector 15',
        'city': 'Chennai',
        'state': 'Tamil Nadu',
        'pincode': '600001',
        'connection_type': 'Domestic',
        'sanctioned_load': 5.0,
        'base_consumption': 180,  # Average monthly units
    },
    {
        'username': 'priya.sharma',
        'email': 'priya.sharma@email.com',
        'password': 'cust123',
        'full_name': 'Priya Sharma',
        'phone': '+91 87654 32109',
        'address': '15, Anna Nagar, 3rd Street',
        'city': 'Chennai',
        'state': 'Tamil Nadu',
        'pincode': '600040',
        'connection_type': 'Domestic',
        'sanctioned_load': 3.0,
        'base_consumption': 120,
    },
    {
        'username': 'tech.solutions',
        'email': 'billing@techsolutions.com',
        'password': 'cust123',
        'full_name': 'Tech Solutions Pvt Ltd',
        'phone': '+91 44 2345 6789',
        'address': 'Plot 78, IT Park, Sholinganallur',
        'city': 'Chennai',
        'state': 'Tamil Nadu',
        'pincode': '600119',
        'connection_type': 'Commercial',
        'sanctioned_load': 25.0,
        'base_consumption': 850,
    },
    {
        'username': 'arun.nair',
        'email': 'arun.nair@email.com',
        'password': 'cust123',
        'full_name': 'Arun Nair',
        'phone': '+91 76543 21098',
        'address': '8, Thiruvanmiyur, East Coast Road',
        'city': 'Chennai',
        'state': 'Tamil Nadu',
        'pincode': '600041',
        'connection_type': 'Domestic',
        'sanctioned_load': 5.0,
        'base_consumption': 250,
    },
    {
        'username': 'steel.works',
        'email': 'accounts@steelworks.ind',
        'password': 'cust123',
        'full_name': 'Chennai Steel Works',
        'phone': '+91 44 6789 0123',
        'address': 'Industrial Area, Phase 2, Ambattur',
        'city': 'Chennai',
        'state': 'Tamil Nadu',
        'pincode': '600058',
        'connection_type': 'Industrial',
        'sanctioned_load': 100.0,
        'base_consumption': 3500,
    },
    {
        'username': 'lakshmi.devi',
        'email': 'lakshmi.devi@email.com',
        'password': 'cust123',
        'full_name': 'Lakshmi Devi',
        'phone': '+91 65432 10987',
        'address': '23, T Nagar, South Usman Road',
        'city': 'Chennai',
        'state': 'Tamil Nadu',
        'pincode': '600017',
        'connection_type': 'Domestic',
        'sanctioned_load': 4.0,
        'base_consumption': 150,
    },
    {
        'username': 'food.palace',
        'email': 'manager@foodpalace.com',
        'password': 'cust123',
        'full_name': 'Royal Food Palace',
        'phone': '+91 44 5678 1234',
        'address': '56, Mount Road, Guindy',
        'city': 'Chennai',
        'state': 'Tamil Nadu',
        'pincode': '600032',
        'connection_type': 'Commercial',
        'sanctioned_load': 15.0,
        'base_consumption': 600,
    },
]

# Tariff slabs
TARIFF_SLABS = {
    'Domestic': [
        {'name': 'Domestic Slab 1', 'start': 0, 'end': 100, 'rate': 2.50, 'base': 50.0},
        {'name': 'Domestic Slab 2', 'start': 100, 'end': 200, 'rate': 3.50, 'base': 0},
        {'name': 'Domestic Slab 3', 'start': 200, 'end': 500, 'rate': 5.00, 'base': 0},
        {'name': 'Domestic Slab 4', 'start': 500, 'end': -1, 'rate': 7.50, 'base': 0},
    ],
    'Commercial': [
        {'name': 'Commercial Slab 1', 'start': 0, 'end': 500, 'rate': 6.00, 'base': 200.0},
        {'name': 'Commercial Slab 2', 'start': 500, 'end': 1000, 'rate': 8.50, 'base': 0},
        {'name': 'Commercial Slab 3', 'start': 1000, 'end': -1, 'rate': 10.00, 'base': 0},
    ],
    'Industrial': [
        {'name': 'Industrial Slab 1', 'start': 0, 'end': 1000, 'rate': 5.50, 'base': 500.0},
        {'name': 'Industrial Slab 2', 'start': 1000, 'end': 5000, 'rate': 7.00, 'base': 0},
        {'name': 'Industrial Slab 3', 'start': 5000, 'end': -1, 'rate': 8.50, 'base': 0},
    ],
}

MONTHS_OF_DATA = 14  # Generate 14 months of historical data


def seasonal_variation(month):
    """Generate seasonal consumption multiplier (summer peaks, winter dips)."""
    # Higher consumption in summer (Apr-Jun), lower in winter (Nov-Jan)
    seasonal = {
        1: 0.80, 2: 0.85, 3: 0.95, 4: 1.20, 5: 1.35, 6: 1.30,
        7: 1.10, 8: 1.05, 9: 1.00, 10: 0.90, 11: 0.85, 12: 0.80
    }
    return seasonal.get(month, 1.0)


def seed_database():
    """Seed the database with realistic demo data."""
    print("=" * 60)
    print("  Advanced Electricity Billing System - Data Seeder")
    print("=" * 60)

    with app.app_context():
        # Drop and recreate all tables
        print("\n[1/6] Resetting database...")
        db.drop_all()
        db.create_all()

        # --- Create Tariffs ---
        print("[2/6] Creating tariff slabs...")
        for conn_type, slabs in TARIFF_SLABS.items():
            for slab in slabs:
                tariff = Tariff(
                    name=slab['name'],
                    connection_type=conn_type,
                    slab_start=slab['start'],
                    slab_end=slab['end'],
                    rate_per_unit=slab['rate'],
                    base_charge=slab['base'],
                    effective_from=datetime(2024, 1, 1)
                )
                db.session.add(tariff)
        db.session.commit()
        print(f"   ✓ Created {sum(len(s) for s in TARIFF_SLABS.values())} tariff slabs")

        # --- Create Admin ---
        print("[3/6] Creating admin user...")
        admin = User(
            username=ADMIN_USERNAME,
            email=ADMIN_EMAIL,
            role='admin'
        )
        admin.set_password(ADMIN_PASSWORD)
        db.session.add(admin)
        db.session.commit()
        print(f"   ✓ Admin: {ADMIN_USERNAME} / {ADMIN_PASSWORD}")

        # --- Create Customers ---
        print("[4/6] Creating customers...")
        created_customers = []

        for i, cust_data in enumerate(CUSTOMERS):
            # Create user
            user = User(
                username=cust_data['username'],
                email=cust_data['email'],
                role='customer'
            )
            user.set_password(cust_data['password'])
            db.session.add(user)
            db.session.flush()

            # Create customer profile
            customer = Customer(
                user_id=user.id,
                customer_id=f"CUST-2024-{i + 1:04d}",
                full_name=cust_data['full_name'],
                phone=cust_data['phone'],
                address=cust_data['address'],
                city=cust_data['city'],
                state=cust_data['state'],
                pincode=cust_data['pincode'],
                meter_number=f"MTR-{random.randint(100000, 999999)}",
                connection_type=cust_data['connection_type'],
                sanctioned_load=cust_data['sanctioned_load'],
                connection_date=datetime(2023, random.randint(1, 6), random.randint(1, 28))
            )
            db.session.add(customer)
            db.session.flush()

            created_customers.append((customer, cust_data))
            print(f"   ✓ {cust_data['full_name']} ({cust_data['connection_type']}) - {cust_data['username']}/cust123")

        db.session.commit()

        # --- Generate Meter Readings & Bills ---
        print(f"[5/6] Generating {MONTHS_OF_DATA} months of readings, bills, and payments...")
        now = datetime.utcnow()
        total_readings = 0
        total_bills = 0
        total_payments = 0

        for customer, cust_data in created_customers:
            base = cust_data['base_consumption']
            cumulative_reading = random.randint(5000, 20000)  # Starting meter value

            for month_offset in range(MONTHS_OF_DATA - 1, -1, -1):
                reading_date = now - timedelta(days=30 * month_offset + random.randint(0, 5))
                month_num = reading_date.month

                # Calculate consumption with seasonal variation and randomness
                seasonal = seasonal_variation(month_num)
                variation = random.uniform(0.85, 1.15)
                units = max(10, int(base * seasonal * variation))

                prev_reading = cumulative_reading
                cumulative_reading += units

                # Create meter reading
                reading = MeterReading(
                    customer_id=customer.id,
                    reading_date=reading_date,
                    reading_value=cumulative_reading,
                    previous_reading=prev_reading,
                    units_consumed=units,
                    reading_type='smart_meter',
                    recorded_by='system',
                    created_at=reading_date
                )
                db.session.add(reading)
                db.session.flush()
                total_readings += 1

                # Generate bill
                bill = generate_bill(customer, reading, tax_rate=5.0, due_days=30)
                bill.bill_date = reading_date
                bill.due_date = reading_date + timedelta(days=30)
                bill.created_at = reading_date
                total_bills += 1

                # Simulate payments (most bills paid, some unpaid/overdue)
                if month_offset > 1:
                    # Older bills - mostly paid
                    if random.random() < 0.85:
                        payment_date = reading_date + timedelta(days=random.randint(5, 25))
                        methods = ['online', 'upi', 'cash', 'cheque']
                        payment = Payment(
                            payment_id=f"PAY-{reading_date.strftime('%Y%m%d')}-{uuid.uuid4().hex[:8].upper()}",
                            bill_id=bill.id,
                            amount=bill.total_amount,
                            payment_date=payment_date,
                            payment_method=random.choice(methods),
                            transaction_ref=uuid.uuid4().hex[:12].upper(),
                            status='completed',
                            created_at=payment_date
                        )
                        bill.payment_status = 'paid'
                        bill.payment_date = payment_date
                        db.session.add(payment)
                        total_payments += 1
                    else:
                        # Mark as overdue
                        bill.payment_status = 'overdue'
                elif month_offset == 1:
                    # Last month's bill - 50% chance paid
                    if random.random() < 0.5:
                        payment_date = reading_date + timedelta(days=random.randint(10, 28))
                        payment = Payment(
                            payment_id=f"PAY-{reading_date.strftime('%Y%m%d')}-{uuid.uuid4().hex[:8].upper()}",
                            bill_id=bill.id,
                            amount=bill.total_amount,
                            payment_date=payment_date,
                            payment_method='online',
                            transaction_ref=uuid.uuid4().hex[:12].upper(),
                            status='completed',
                            created_at=payment_date
                        )
                        bill.payment_status = 'paid'
                        bill.payment_date = payment_date
                        db.session.add(payment)
                        total_payments += 1
                # Current month bills stay unpaid

            db.session.flush()

        db.session.commit()
        print(f"   ✓ {total_readings} meter readings created")
        print(f"   ✓ {total_bills} bills generated")
        print(f"   ✓ {total_payments} payments recorded")

        # --- Summary ---
        print("\n[6/6] Seed data summary:")
        print(f"   • Tariff Slabs: {Tariff.query.count()}")
        print(f"   • Users: {User.query.count()} (1 admin + {User.query.filter_by(role='customer').count()} customers)")
        print(f"   • Customers: {Customer.query.count()}")
        print(f"   • Meter Readings: {MeterReading.query.count()}")
        print(f"   • Bills: {Bill.query.count()}")
        print(f"   • Payments: {Payment.query.count()}")
        print(f"   • Email Logs: {EmailLog.query.count()}")

        paid = Bill.query.filter_by(payment_status='paid').count()
        unpaid = Bill.query.filter_by(payment_status='unpaid').count()
        overdue = Bill.query.filter_by(payment_status='overdue').count()
        print(f"   • Bill Status: {paid} paid | {unpaid} unpaid | {overdue} overdue")

        print("\n" + "=" * 60)
        print("  ✅ Database seeded successfully!")
        print(f"  Admin Login: {ADMIN_USERNAME} / {ADMIN_PASSWORD}")
        print(f"  Customer Login: rajesh.kumar / cust123")
        print("=" * 60)


if __name__ == '__main__':
    seed_database()
