"""
Configuration module for Advanced Electricity Billing System.
Handles application settings, database configuration, and environment variables.
"""

import os

basedir = os.path.abspath(os.path.dirname(__file__))


class Config:
    """Base configuration class."""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'aebs-super-secret-key-2024-prod'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(basedir, 'electricity_billing.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Mail simulation settings
    MAIL_SIMULATION = True
    MAIL_LOG_FILE = os.path.join(basedir, 'email_log.txt')

    # PDF generation
    PDF_OUTPUT_DIR = os.path.join(basedir, 'generated_bills')

    # Application settings
    ITEMS_PER_PAGE = 15
    BILL_DUE_DAYS = 30
    LATE_FEE_PERCENTAGE = 2.0
    TAX_PERCENTAGE = 5.0

    # Prediction settings
    MIN_READINGS_FOR_PREDICTION = 3
    PREDICTION_MONTHS_AHEAD = 6


class DevelopmentConfig(Config):
    """Development configuration."""
    DEBUG = True


class ProductionConfig(Config):
    """Production configuration."""
    DEBUG = False


class TestingConfig(Config):
    """Testing configuration."""
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}
