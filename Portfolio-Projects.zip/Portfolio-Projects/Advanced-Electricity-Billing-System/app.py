"""
Advanced Electricity Billing System - Main Flask Application.
Handles routing, authentication, and all application endpoints
for both admin and customer portals.
"""

import os
import json
import logging
from datetime import datetime, timedelta
from functools import wraps

from flask import (Flask, render_template, request, redirect, url_for,
                   flash, jsonify, abort, make_response)
from flask_login import (LoginManager, login_user, logout_user,
                         login_required, current_user)

from config import config
from models import db, User, Customer, MeterReading, Bill, Payment, Tariff, EmailLog
from billing import (calculate_energy_charge, generate_bill, process_payment,
                     update_overdue_bills, predict_consumption, get_revenue_summary,
                     get_monthly_revenue, get_customer_consumption_data,
                     get_customer_billing_data, generate_bill_html)

# --- App Factory ---

def create_app(config_name='default'):
    """Application factory."""
    app = Flask(__name__)
    app.config.from_object(config[config_name])

    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)

    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
    )

    # Create tables
    with app.app_context():
        db.create_all()

    return app


# --- Login Manager Setup ---

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'
login_manager.login_message = 'Please log in to access this page.'


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# --- Create App ---

app = create_app('development')


# --- Decorators ---

def admin_required(f):
    """Decorator to restrict access to admin users only."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Access denied. Admin privileges required.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def customer_required(f):
    """Decorator to restrict access to customer users only."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.is_admin:
            flash('Access denied.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


# --- Context Processor ---

@app.context_processor
def utility_processor():
    """Inject utility functions and data into all templates."""
    def format_currency(amount):
        return f"₹{amount:,.2f}"

    def format_date(dt):
        if dt:
            return dt.strftime('%d %b %Y')
        return 'N/A'

    return dict(
        format_currency=format_currency,
        format_date=format_date,
        now=datetime.utcnow()
    )


# --- Auth Routes ---

@app.route('/')
def index():
    """Landing page - redirect based on auth status."""
    if current_user.is_authenticated:
        if current_user.is_admin:
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('customer_dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page for all users."""
    if current_user.is_authenticated:
        return redirect(url_for('index'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')

        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            if not user.is_active:
                flash('Account is deactivated. Contact admin.', 'danger')
                return render_template('login.html')

            login_user(user, remember=request.form.get('remember'))
            flash(f'Welcome back, {username}!', 'success')
            next_page = request.args.get('next')
            if next_page:
                return redirect(next_page)
            if user.is_admin:
                return redirect(url_for('admin_dashboard'))
            return redirect(url_for('customer_dashboard'))

        flash('Invalid username or password.', 'danger')

    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    """Logout current user."""
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))


# --- Admin Dashboard ---

@app.route('/admin/dashboard')
@login_required
@admin_required
def admin_dashboard():
    """Admin dashboard with analytics overview."""
    # Update overdue bills
    update_overdue_bills()

    # Get stats
    total_customers = Customer.query.count()
    active_customers = Customer.query.filter_by(is_active=True).count()
    total_bills = Bill.query.count()
    unpaid_bills = Bill.query.filter_by(payment_status='unpaid').count()
    overdue_bills = Bill.query.filter_by(payment_status='overdue').count()

    revenue = get_revenue_summary()
    monthly_revenue = get_monthly_revenue(12)

    # Recent activity
    recent_bills = Bill.query.order_by(Bill.created_at.desc()).limit(5).all()
    recent_payments = Payment.query.order_by(Payment.created_at.desc()).limit(5).all()

    return render_template('admin_dashboard.html',
                         total_customers=total_customers,
                         active_customers=active_customers,
                         total_bills=total_bills,
                         unpaid_bills=unpaid_bills,
                         overdue_bills=overdue_bills,
                         revenue=revenue,
                         monthly_revenue=json.dumps(monthly_revenue),
                         recent_bills=recent_bills,
                         recent_payments=recent_payments)


# --- Customer Dashboard ---

@app.route('/customer/dashboard')
@login_required
@customer_required
def customer_dashboard():
    """Customer self-service dashboard."""
    customer = current_user.customer
    if not customer:
        flash('Customer profile not found.', 'danger')
        return redirect(url_for('logout'))

    # Update overdue bills
    update_overdue_bills()

    # Get customer data
    consumption_data = get_customer_consumption_data(customer.id, 12)
    billing_data = get_customer_billing_data(customer.id, 12)

    recent_bills = customer.bills.limit(5).all()
    unpaid_bills = customer.bills.filter(Bill.payment_status.in_(['unpaid', 'overdue'])).all()
    total_outstanding = sum(b.total_amount for b in unpaid_bills)

    latest_reading = customer.latest_reading

    return render_template('customer_dashboard.html',
                         customer=customer,
                         consumption_data=json.dumps(consumption_data),
                         billing_data=json.dumps(billing_data),
                         recent_bills=recent_bills,
                         unpaid_bills=unpaid_bills,
                         total_outstanding=total_outstanding,
                         latest_reading=latest_reading)


# --- Customer Management (Admin) ---

@app.route('/admin/customers')
@login_required
@admin_required
def customers():
    """List all customers."""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')

    query = Customer.query
    if search:
        query = query.filter(
            (Customer.full_name.ilike(f'%{search}%')) |
            (Customer.customer_id.ilike(f'%{search}%')) |
            (Customer.meter_number.ilike(f'%{search}%'))
        )

    customers_list = query.order_by(Customer.created_at.desc()).paginate(
        page=page, per_page=15, error_out=False
    )

    return render_template('customers.html', customers=customers_list, search=search)


@app.route('/admin/customer/add', methods=['POST'])
@login_required
@admin_required
def add_customer():
    """Add a new customer."""
    try:
        # Create user account
        username = request.form['username']
        email = request.form['email']
        password = request.form.get('password', 'password123')

        if User.query.filter_by(username=username).first():
            flash('Username already exists.', 'danger')
            return redirect(url_for('customers'))

        user = User(username=username, email=email, role='customer')
        user.set_password(password)
        db.session.add(user)
        db.session.flush()

        # Create customer profile
        customer = Customer(
            user_id=user.id,
            customer_id=f"CUST-{datetime.utcnow().strftime('%Y%m')}-{user.id:04d}",
            full_name=request.form['full_name'],
            phone=request.form.get('phone', ''),
            address=request.form.get('address', ''),
            city=request.form.get('city', ''),
            state=request.form.get('state', ''),
            pincode=request.form.get('pincode', ''),
            meter_number=request.form['meter_number'],
            connection_type=request.form.get('connection_type', 'Domestic'),
            sanctioned_load=float(request.form.get('sanctioned_load', 5.0))
        )
        db.session.add(customer)
        db.session.commit()

        flash(f'Customer {customer.full_name} added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding customer: {str(e)}', 'danger')

    return redirect(url_for('customers'))


# --- Meter Readings ---

@app.route('/admin/meter-readings')
@login_required
@admin_required
def meter_readings():
    """View and manage meter readings."""
    page = request.args.get('page', 1, type=int)
    customer_filter = request.args.get('customer_id', '')

    query = MeterReading.query
    if customer_filter:
        customer = Customer.query.filter_by(customer_id=customer_filter).first()
        if customer:
            query = query.filter_by(customer_id=customer.id)

    readings = query.order_by(MeterReading.reading_date.desc()).paginate(
        page=page, per_page=15, error_out=False
    )

    all_customers = Customer.query.filter_by(is_active=True).all()

    return render_template('meter_readings.html',
                         readings=readings,
                         customers=all_customers,
                         selected_customer=customer_filter)


@app.route('/admin/meter-reading/add', methods=['POST'])
@login_required
@admin_required
def add_meter_reading():
    """Record a new meter reading."""
    try:
        customer_id = int(request.form['customer_id'])
        customer = Customer.query.get_or_404(customer_id)

        reading_value = float(request.form['reading_value'])
        reading_date_str = request.form.get('reading_date')
        reading_date = datetime.strptime(reading_date_str, '%Y-%m-%d') if reading_date_str else datetime.utcnow()

        # Get previous reading
        prev_reading = MeterReading.query.filter_by(
            customer_id=customer.id
        ).order_by(MeterReading.reading_date.desc()).first()

        previous_value = prev_reading.reading_value if prev_reading else 0

        if reading_value < previous_value:
            flash('Current reading cannot be less than previous reading.', 'danger')
            return redirect(url_for('meter_readings'))

        reading = MeterReading(
            customer_id=customer.id,
            reading_date=reading_date,
            reading_value=reading_value,
            previous_reading=previous_value,
            reading_type='manual',
            recorded_by=current_user.username
        )
        reading.calculate_consumption()
        db.session.add(reading)

        # Auto-generate bill
        bill = generate_bill(customer, reading,
                           tax_rate=app.config['TAX_PERCENTAGE'],
                           due_days=app.config['BILL_DUE_DAYS'])

        db.session.commit()

        flash(f'Reading recorded! Bill {bill.bill_number} generated for {reading.units_consumed:.1f} units.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error recording reading: {str(e)}', 'danger')

    return redirect(url_for('meter_readings'))


# --- Bills ---

@app.route('/admin/bills')
@login_required
@admin_required
def bills():
    """View all bills (admin)."""
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', '')
    customer_filter = request.args.get('customer_id', '')

    query = Bill.query
    if status_filter:
        query = query.filter_by(payment_status=status_filter)
    if customer_filter:
        customer = Customer.query.filter_by(customer_id=customer_filter).first()
        if customer:
            query = query.filter_by(customer_id=customer.id)

    bills_list = query.order_by(Bill.bill_date.desc()).paginate(
        page=page, per_page=15, error_out=False
    )

    return render_template('bills.html',
                         bills=bills_list,
                         status_filter=status_filter,
                         customer_filter=customer_filter)


@app.route('/bills/<int:bill_id>')
@login_required
def bill_detail(bill_id):
    """View detailed bill breakdown."""
    bill = Bill.query.get_or_404(bill_id)

    # Customer can only view their own bills
    if not current_user.is_admin:
        if not current_user.customer or bill.customer_id != current_user.customer.id:
            abort(403)

    slab_details = json.loads(bill.slab_details) if bill.slab_details else []
    payments = bill.payments.all()

    return render_template('bill_detail.html',
                         bill=bill,
                         slab_details=slab_details,
                         payments=payments)


@app.route('/bills/<int:bill_id>/html')
@login_required
def bill_html(bill_id):
    """Generate HTML bill for viewing/printing (PDF-like)."""
    bill = Bill.query.get_or_404(bill_id)

    if not current_user.is_admin:
        if not current_user.customer or bill.customer_id != current_user.customer.id:
            abort(403)

    html_content = generate_bill_html(bill)
    return html_content


# --- Customer Bills View ---

@app.route('/customer/bills')
@login_required
@customer_required
def customer_bills():
    """Customer view their own bills."""
    customer = current_user.customer
    page = request.args.get('page', 1, type=int)
    status_filter = request.args.get('status', '')

    query = Bill.query.filter_by(customer_id=customer.id)
    if status_filter:
        query = query.filter_by(payment_status=status_filter)

    bills_list = query.order_by(Bill.bill_date.desc()).paginate(
        page=page, per_page=15, error_out=False
    )

    return render_template('bills.html',
                         bills=bills_list,
                         status_filter=status_filter,
                         customer_filter='',
                         is_customer_view=True)


# --- Payments ---

@app.route('/admin/payments')
@login_required
@admin_required
def payments():
    """View all payment records."""
    page = request.args.get('page', 1, type=int)
    payments_list = Payment.query.order_by(Payment.payment_date.desc()).paginate(
        page=page, per_page=15, error_out=False
    )
    return render_template('payments.html', payments=payments_list)


@app.route('/pay/<int:bill_id>', methods=['POST'])
@login_required
def make_payment(bill_id):
    """Process a payment for a bill."""
    bill = Bill.query.get_or_404(bill_id)

    # Verify customer ownership
    if not current_user.is_admin:
        if not current_user.customer or bill.customer_id != current_user.customer.id:
            abort(403)

    if bill.payment_status == 'paid':
        flash('This bill is already paid.', 'info')
        return redirect(url_for('bill_detail', bill_id=bill.id))

    try:
        payment_method = request.form.get('payment_method', 'online')
        payment = process_payment(bill, bill.total_amount, payment_method)
        db.session.commit()
        flash(f'Payment of ₹{bill.total_amount:.2f} processed successfully! Ref: {payment.payment_id}', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Payment failed: {str(e)}', 'danger')

    return redirect(url_for('bill_detail', bill_id=bill.id))


# --- Tariff Management ---

@app.route('/admin/tariffs')
@login_required
@admin_required
def tariffs():
    """View and manage tariff slabs."""
    all_tariffs = Tariff.query.order_by(
        Tariff.connection_type, Tariff.slab_start
    ).all()

    # Group by connection type
    grouped = {}
    for t in all_tariffs:
        if t.connection_type not in grouped:
            grouped[t.connection_type] = []
        grouped[t.connection_type].append(t)

    return render_template('tariffs.html', grouped_tariffs=grouped)


@app.route('/admin/tariff/add', methods=['POST'])
@login_required
@admin_required
def add_tariff():
    """Add a new tariff slab."""
    try:
        tariff = Tariff(
            name=request.form['name'],
            connection_type=request.form['connection_type'],
            slab_start=int(request.form['slab_start']),
            slab_end=int(request.form['slab_end']),
            rate_per_unit=float(request.form['rate_per_unit']),
            base_charge=float(request.form.get('base_charge', 0))
        )
        db.session.add(tariff)
        db.session.commit()
        flash('Tariff slab added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding tariff: {str(e)}', 'danger')

    return redirect(url_for('tariffs'))


@app.route('/admin/tariff/delete/<int:tariff_id>', methods=['POST'])
@login_required
@admin_required
def delete_tariff(tariff_id):
    """Delete a tariff slab."""
    tariff = Tariff.query.get_or_404(tariff_id)
    db.session.delete(tariff)
    db.session.commit()
    flash('Tariff slab deleted.', 'success')
    return redirect(url_for('tariffs'))


# --- Predictions ---

@app.route('/predictions')
@login_required
def predictions():
    """Consumption prediction page."""
    if current_user.is_admin:
        # Admin can view predictions for any customer
        customer_id = request.args.get('customer_id', type=int)
        customers_list = Customer.query.filter_by(is_active=True).all()

        if customer_id:
            customer = Customer.query.get_or_404(customer_id)
        elif customers_list:
            customer = customers_list[0]
            customer_id = customer.id
        else:
            return render_template('predictions.html', customers=customers_list,
                                 predictions=[], stats={})
    else:
        customer = current_user.customer
        customer_id = customer.id
        customers_list = None

    preds, stats = predict_consumption(customer_id, months_ahead=6)

    return render_template('predictions.html',
                         customers=customers_list,
                         selected_customer_id=customer_id,
                         customer=customer,
                         predictions=preds,
                         stats=json.dumps(stats),
                         predictions_json=json.dumps(preds))


# --- Reports ---

@app.route('/admin/reports')
@login_required
@admin_required
def reports():
    """Admin reports page with charts and analytics."""
    revenue = get_revenue_summary()
    monthly_revenue = get_monthly_revenue(12)

    # Customer stats
    connection_types = db.session.query(
        Customer.connection_type,
        db.func.count(Customer.id)
    ).group_by(Customer.connection_type).all()

    # Bill status distribution
    bill_statuses = db.session.query(
        Bill.payment_status,
        db.func.count(Bill.id)
    ).group_by(Bill.payment_status).all()

    # Top consumers
    top_consumers = db.session.query(
        Customer,
        db.func.sum(Bill.units_consumed).label('total_units')
    ).join(Bill).group_by(Customer.id).order_by(
        db.desc('total_units')
    ).limit(10).all()

    return render_template('reports.html',
                         revenue=revenue,
                         monthly_revenue=json.dumps(monthly_revenue),
                         connection_types=connection_types,
                         bill_statuses=bill_statuses,
                         top_consumers=top_consumers)


# --- Customer Usage History ---

@app.route('/customer/usage')
@login_required
@customer_required
def customer_usage():
    """Customer's usage history page."""
    customer = current_user.customer
    readings = customer.meter_readings.order_by(MeterReading.reading_date.desc()).all()
    consumption_data = get_customer_consumption_data(customer.id, 24)

    return render_template('meter_readings.html',
                         readings_list=readings,
                         consumption_data=json.dumps(consumption_data),
                         is_customer_view=True,
                         customer=customer)


# --- Customer Payments ---

@app.route('/customer/payments')
@login_required
@customer_required
def customer_payments():
    """Customer's payment history."""
    customer = current_user.customer
    page = request.args.get('page', 1, type=int)

    bill_ids = [b.id for b in customer.bills.all()]
    payments_list = Payment.query.filter(
        Payment.bill_id.in_(bill_ids)
    ).order_by(Payment.payment_date.desc()).paginate(
        page=page, per_page=15, error_out=False
    )

    return render_template('payments.html',
                         payments=payments_list,
                         is_customer_view=True)


# --- API Endpoints ---

@app.route('/api/consumption/<int:customer_id>')
@login_required
def api_consumption(customer_id):
    """API: Get consumption data for charts."""
    if not current_user.is_admin:
        if not current_user.customer or current_user.customer.id != customer_id:
            return jsonify({'error': 'Unauthorized'}), 403

    data = get_customer_consumption_data(customer_id, 12)
    return jsonify(data)


@app.route('/api/billing/<int:customer_id>')
@login_required
def api_billing(customer_id):
    """API: Get billing data for charts."""
    if not current_user.is_admin:
        if not current_user.customer or current_user.customer.id != customer_id:
            return jsonify({'error': 'Unauthorized'}), 403

    data = get_customer_billing_data(customer_id, 12)
    return jsonify(data)


@app.route('/api/revenue')
@login_required
@admin_required
def api_revenue():
    """API: Get revenue summary."""
    return jsonify(get_revenue_summary())


# --- Email Log (Admin) ---

@app.route('/admin/emails')
@login_required
@admin_required
def email_logs():
    """View simulated email logs."""
    page = request.args.get('page', 1, type=int)
    emails = EmailLog.query.order_by(EmailLog.sent_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    return render_template('reports.html', emails=emails, show_emails=True)


# --- Error Handlers ---

@app.errorhandler(404)
def not_found(e):
    return render_template('base.html', error='Page not found', error_code=404), 404


@app.errorhandler(403)
def forbidden(e):
    return render_template('base.html', error='Access forbidden', error_code=403), 403


@app.errorhandler(500)
def internal_error(e):
    db.session.rollback()
    return render_template('base.html', error='Internal server error', error_code=500), 500


# --- Main Entry Point ---

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)
