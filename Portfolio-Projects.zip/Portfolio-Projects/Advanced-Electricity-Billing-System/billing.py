"""
Billing calculation engine and consumption prediction module.
Handles slab-based tariff calculations, bill generation,
and linear regression-based consumption forecasting.
"""

import json
import uuid
import logging
from datetime import datetime, timedelta
from models import db, Tariff, Bill, MeterReading, Customer, Payment, EmailLog

logger = logging.getLogger(__name__)

# --- Billing Calculation Engine ---

def get_tariff_slabs(connection_type='Domestic'):
    """Retrieve active tariff slabs for a given connection type, ordered by slab_start."""
    return Tariff.query.filter_by(
        connection_type=connection_type,
        is_active=True
    ).order_by(Tariff.slab_start).all()


def calculate_energy_charge(units, connection_type='Domestic'):
    """
    Calculate energy charge using slab-based tariff.
    Returns (total_charge, slab_breakdown_list, base_charge).
    """
    slabs = get_tariff_slabs(connection_type)
    if not slabs:
        logger.warning(f"No tariff slabs found for {connection_type}, using default rate.")
        return units * 5.0, [{'slab': '0-∞', 'units': units, 'rate': 5.0, 'amount': units * 5.0}], 50.0

    total_charge = 0.0
    remaining_units = units
    slab_breakdown = []
    base_charge = slabs[0].base_charge if slabs else 50.0

    for slab in slabs:
        if remaining_units <= 0:
            break

        slab_end = slab.slab_end if slab.slab_end != -1 else float('inf')
        slab_range = slab_end - slab.slab_start

        if slab.slab_end == -1:
            # Last slab (unlimited)
            applicable_units = remaining_units
        else:
            applicable_units = min(remaining_units, slab_range)

        charge = applicable_units * slab.rate_per_unit
        total_charge += charge
        remaining_units -= applicable_units

        end_label = '∞' if slab.slab_end == -1 else str(slab.slab_end)
        slab_breakdown.append({
            'slab': f'{slab.slab_start}-{end_label}',
            'units': round(applicable_units, 2),
            'rate': slab.rate_per_unit,
            'amount': round(charge, 2)
        })

    return round(total_charge, 2), slab_breakdown, base_charge


def generate_bill(customer, meter_reading, tax_rate=5.0, due_days=30):
    """
    Generate a complete bill for a customer based on meter reading.
    Returns the created Bill object.
    """
    units = meter_reading.units_consumed
    connection_type = customer.connection_type

    # Calculate charges
    energy_charge, slab_breakdown, base_charge = calculate_energy_charge(units, connection_type)

    # Additional charges
    fuel_surcharge = round(energy_charge * 0.02, 2)  # 2% fuel surcharge
    electricity_duty = round(energy_charge * 0.06, 2)  # 6% electricity duty
    subtotal = base_charge + energy_charge + fuel_surcharge + electricity_duty
    tax_amount = round(subtotal * (tax_rate / 100), 2)
    total_amount = round(subtotal + tax_amount, 2)

    # Generate bill number
    bill_number = f"BILL-{datetime.utcnow().strftime('%Y%m')}-{uuid.uuid4().hex[:8].upper()}"

    bill = Bill(
        bill_number=bill_number,
        customer_id=customer.id,
        meter_reading_id=meter_reading.id,
        bill_date=meter_reading.reading_date,
        due_date=meter_reading.reading_date + timedelta(days=due_days),
        billing_period_start=meter_reading.reading_date - timedelta(days=30),
        billing_period_end=meter_reading.reading_date,
        units_consumed=units,
        base_charge=base_charge,
        energy_charge=energy_charge,
        fuel_surcharge=fuel_surcharge,
        electricity_duty=electricity_duty,
        tax_amount=tax_amount,
        total_amount=total_amount,
        slab_details=json.dumps(slab_breakdown),
        payment_status='unpaid'
    )

    db.session.add(bill)

    # Simulate email notification
    log_email_notification(
        customer.user.email,
        f"Bill Generated - {bill_number}",
        f"Dear {customer.full_name},\n\nYour electricity bill {bill_number} has been generated.\n"
        f"Units Consumed: {units} kWh\nTotal Amount: ₹{total_amount:.2f}\n"
        f"Due Date: {bill.due_date.strftime('%d %b %Y')}\n\nPlease pay before the due date to avoid late fees.",
        'bill_generated'
    )

    return bill


def process_payment(bill, amount, payment_method='online', transaction_ref=None):
    """Process a payment against a bill."""
    payment_id = f"PAY-{datetime.utcnow().strftime('%Y%m%d')}-{uuid.uuid4().hex[:8].upper()}"

    payment = Payment(
        payment_id=payment_id,
        bill_id=bill.id,
        amount=amount,
        payment_date=datetime.utcnow(),
        payment_method=payment_method,
        transaction_ref=transaction_ref or uuid.uuid4().hex[:12].upper(),
        status='completed'
    )

    bill.payment_status = 'paid'
    bill.payment_date = datetime.utcnow()

    db.session.add(payment)

    # Simulate email notification
    customer = bill.customer
    log_email_notification(
        customer.user.email,
        f"Payment Received - {payment_id}",
        f"Dear {customer.full_name},\n\nPayment of ₹{amount:.2f} received for bill {bill.bill_number}.\n"
        f"Transaction Reference: {payment.transaction_ref}\n\nThank you for your payment.",
        'payment_received'
    )

    return payment


def update_overdue_bills():
    """Update all unpaid bills past due date to overdue status."""
    overdue_bills = Bill.query.filter(
        Bill.payment_status == 'unpaid',
        Bill.due_date < datetime.utcnow()
    ).all()

    count = 0
    for bill in overdue_bills:
        bill.payment_status = 'overdue'
        count += 1

        # Send overdue notification
        customer = bill.customer
        log_email_notification(
            customer.user.email,
            f"Overdue Notice - Bill {bill.bill_number}",
            f"Dear {customer.full_name},\n\nYour bill {bill.bill_number} of ₹{bill.total_amount:.2f} "
            f"is overdue.\nPlease pay immediately to avoid disconnection.\n",
            'overdue_notice'
        )

    if count > 0:
        db.session.commit()
        logger.info(f"Updated {count} bills to overdue status.")
    return count


# --- Consumption Prediction (Linear Regression) ---

def predict_consumption(customer_id, months_ahead=6):
    """
    Predict future consumption using simple linear regression on historical data.
    Uses numpy for calculation (avoids heavy sklearn dependency for simple case).
    Returns list of predictions with month and predicted units.
    """
    try:
        import numpy as np
    except ImportError:
        logger.error("NumPy not installed. Prediction unavailable.")
        return [], {}

    # Get historical readings ordered by date
    readings = MeterReading.query.filter_by(
        customer_id=customer_id
    ).order_by(MeterReading.reading_date.asc()).all()

    if len(readings) < 3:
        return [], {'error': 'Insufficient data. At least 3 readings required for prediction.'}

    # Prepare data
    consumption_data = []
    dates = []
    for r in readings:
        if r.units_consumed > 0:
            consumption_data.append(r.units_consumed)
            dates.append(r.reading_date)

    if len(consumption_data) < 3:
        return [], {'error': 'Insufficient valid consumption data.'}

    # Create X (month indices) and y (consumption)
    X = np.arange(len(consumption_data)).reshape(-1, 1).astype(float)
    y = np.array(consumption_data, dtype=float)

    # Simple linear regression: y = mx + b
    X_flat = X.flatten()
    n = len(X_flat)
    sum_x = np.sum(X_flat)
    sum_y = np.sum(y)
    sum_xy = np.sum(X_flat * y)
    sum_x2 = np.sum(X_flat ** 2)

    denominator = (n * sum_x2 - sum_x ** 2)
    if denominator == 0:
        slope = 0
        intercept = np.mean(y)
    else:
        slope = (n * sum_xy - sum_x * sum_y) / denominator
        intercept = (sum_y - slope * sum_x) / n

    # Calculate R² score
    y_pred_hist = slope * X_flat + intercept
    ss_res = np.sum((y - y_pred_hist) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0

    # Predict future months
    predictions = []
    last_date = dates[-1]
    last_index = len(consumption_data) - 1

    for i in range(1, months_ahead + 1):
        future_index = last_index + i
        predicted_units = max(0, slope * future_index + intercept)
        future_date = last_date + timedelta(days=30 * i)

        predictions.append({
            'month': future_date.strftime('%b %Y'),
            'predicted_units': round(predicted_units, 1),
            'month_index': future_index
        })

    stats = {
        'slope': round(slope, 4),
        'intercept': round(intercept, 4),
        'r_squared': round(r_squared, 4),
        'avg_consumption': round(float(np.mean(y)), 1),
        'max_consumption': round(float(np.max(y)), 1),
        'min_consumption': round(float(np.min(y)), 1),
        'trend': 'increasing' if slope > 1 else ('decreasing' if slope < -1 else 'stable'),
        'data_points': len(consumption_data),
        'historical_months': [d.strftime('%b %Y') for d in dates],
        'historical_values': [round(v, 1) for v in consumption_data],
        'regression_line': [round(float(v), 1) for v in y_pred_hist]
    }

    return predictions, stats


# --- Revenue and Analytics ---

def get_revenue_summary():
    """Calculate revenue summary for admin dashboard."""
    total_billed = db.session.query(db.func.sum(Bill.total_amount)).scalar() or 0
    total_collected = db.session.query(
        db.func.sum(Payment.amount)
    ).filter(Payment.status == 'completed').scalar() or 0
    total_outstanding = db.session.query(
        db.func.sum(Bill.total_amount)
    ).filter(Bill.payment_status.in_(['unpaid', 'overdue'])).scalar() or 0
    overdue_amount = db.session.query(
        db.func.sum(Bill.total_amount)
    ).filter(Bill.payment_status == 'overdue').scalar() or 0

    return {
        'total_billed': round(total_billed, 2),
        'total_collected': round(total_collected, 2),
        'total_outstanding': round(total_outstanding, 2),
        'overdue_amount': round(overdue_amount, 2),
        'collection_rate': round((total_collected / total_billed * 100) if total_billed > 0 else 0, 1)
    }


def get_monthly_revenue(months=12):
    """Get monthly revenue data for charts."""
    data = []
    now = datetime.utcnow()

    for i in range(months - 1, -1, -1):
        month_start = datetime(now.year, now.month, 1) - timedelta(days=30 * i)
        month_end = month_start + timedelta(days=32)
        month_end = datetime(month_end.year, month_end.month, 1)

        billed = db.session.query(
            db.func.sum(Bill.total_amount)
        ).filter(
            Bill.bill_date >= month_start,
            Bill.bill_date < month_end
        ).scalar() or 0

        collected = db.session.query(
            db.func.sum(Payment.amount)
        ).filter(
            Payment.payment_date >= month_start,
            Payment.payment_date < month_end,
            Payment.status == 'completed'
        ).scalar() or 0

        data.append({
            'month': month_start.strftime('%b %Y'),
            'billed': round(billed, 2),
            'collected': round(collected, 2)
        })

    return data


def get_customer_consumption_data(customer_id, months=12):
    """Get monthly consumption data for a customer."""
    readings = MeterReading.query.filter_by(
        customer_id=customer_id
    ).order_by(MeterReading.reading_date.desc()).limit(months).all()

    readings.reverse()

    return {
        'months': [r.reading_date.strftime('%b %Y') for r in readings],
        'consumption': [round(r.units_consumed, 1) for r in readings],
        'reading_values': [round(r.reading_value, 1) for r in readings]
    }


def get_customer_billing_data(customer_id, months=12):
    """Get billing history data for charts."""
    bills = Bill.query.filter_by(
        customer_id=customer_id
    ).order_by(Bill.bill_date.desc()).limit(months).all()

    bills.reverse()

    return {
        'months': [b.bill_date.strftime('%b %Y') for b in bills],
        'amounts': [round(b.total_amount, 2) for b in bills],
        'units': [round(b.units_consumed, 1) for b in bills],
        'statuses': [b.payment_status for b in bills]
    }


# --- Email Simulation ---

def log_email_notification(recipient, subject, body, email_type='general'):
    """Simulate sending an email by logging it to the database."""
    email = EmailLog(
        recipient_email=recipient,
        subject=subject,
        body=body,
        email_type=email_type,
        status='sent'
    )
    db.session.add(email)
    logger.info(f"[EMAIL SIMULATED] To: {recipient} | Subject: {subject}")
    return email


# --- Bill PDF Generation (HTML-based) ---

def generate_bill_html(bill):
    """Generate an HTML representation of the bill for PDF-like viewing."""
    customer = bill.customer
    slab_details = json.loads(bill.slab_details) if bill.slab_details else []

    slab_rows = ""
    for s in slab_details:
        slab_rows += f"""
        <tr>
            <td>{s['slab']} units</td>
            <td>{s['units']:.1f}</td>
            <td>₹{s['rate']:.2f}</td>
            <td>₹{s['amount']:.2f}</td>
        </tr>"""

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Electricity Bill - {bill.bill_number}</title>
        <style>
            body {{ font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; color: #333; }}
            .bill-container {{ max-width: 800px; margin: 0 auto; border: 2px solid #1a1a2e; padding: 30px; }}
            .header {{ text-align: center; border-bottom: 3px solid #6c63ff; padding-bottom: 20px; margin-bottom: 20px; }}
            .header h1 {{ color: #1a1a2e; margin: 0; font-size: 24px; }}
            .header p {{ color: #666; margin: 5px 0; }}
            .section {{ margin: 20px 0; }}
            .section h3 {{ color: #6c63ff; border-bottom: 1px solid #eee; padding-bottom: 8px; }}
            .info-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }}
            .info-item {{ padding: 5px 0; }}
            .info-label {{ font-weight: 600; color: #555; }}
            table {{ width: 100%; border-collapse: collapse; margin: 10px 0; }}
            th, td {{ padding: 10px; text-align: left; border-bottom: 1px solid #eee; }}
            th {{ background: #f8f9fa; color: #1a1a2e; font-weight: 600; }}
            .total-row {{ font-size: 18px; font-weight: bold; color: #6c63ff; background: #f0efff; }}
            .footer {{ text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #999; font-size: 12px; }}
            .status {{ display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 600; }}
            .status-paid {{ background: #d4edda; color: #155724; }}
            .status-unpaid {{ background: #fff3cd; color: #856404; }}
            .status-overdue {{ background: #f8d7da; color: #721c24; }}
        </style>
    </head>
    <body>
        <div class="bill-container">
            <div class="header">
                <h1>⚡ Advanced Electricity Billing System</h1>
                <p>Government of Energy Distribution</p>
                <p>Bill Number: <strong>{bill.bill_number}</strong></p>
            </div>

            <div class="section">
                <h3>Customer Information</h3>
                <div class="info-grid">
                    <div class="info-item"><span class="info-label">Customer ID:</span> {customer.customer_id}</div>
                    <div class="info-item"><span class="info-label">Name:</span> {customer.full_name}</div>
                    <div class="info-item"><span class="info-label">Meter No:</span> {customer.meter_number}</div>
                    <div class="info-item"><span class="info-label">Connection:</span> {customer.connection_type}</div>
                    <div class="info-item"><span class="info-label">Address:</span> {customer.address}, {customer.city}</div>
                    <div class="info-item"><span class="info-label">Load:</span> {customer.sanctioned_load} kW</div>
                </div>
            </div>

            <div class="section">
                <h3>Billing Details</h3>
                <div class="info-grid">
                    <div class="info-item"><span class="info-label">Bill Date:</span> {bill.bill_date.strftime('%d %b %Y')}</div>
                    <div class="info-item"><span class="info-label">Due Date:</span> {bill.due_date.strftime('%d %b %Y')}</div>
                    <div class="info-item"><span class="info-label">Period:</span> {bill.billing_period_start.strftime('%d %b %Y') if bill.billing_period_start else 'N/A'} - {bill.billing_period_end.strftime('%d %b %Y') if bill.billing_period_end else 'N/A'}</div>
                    <div class="info-item"><span class="info-label">Status:</span> <span class="status status-{bill.payment_status}">{bill.payment_status.upper()}</span></div>
                </div>
            </div>

            <div class="section">
                <h3>Consumption & Slab Breakdown</h3>
                <p><strong>Total Units Consumed: {bill.units_consumed:.1f} kWh</strong></p>
                <table>
                    <thead>
                        <tr><th>Slab Range</th><th>Units</th><th>Rate/Unit</th><th>Amount</th></tr>
                    </thead>
                    <tbody>
                        {slab_rows}
                    </tbody>
                </table>
            </div>

            <div class="section">
                <h3>Charge Summary</h3>
                <table>
                    <tr><td>Base Charge (Fixed)</td><td>₹{bill.base_charge:.2f}</td></tr>
                    <tr><td>Energy Charge</td><td>₹{bill.energy_charge:.2f}</td></tr>
                    <tr><td>Fuel Surcharge (2%)</td><td>₹{bill.fuel_surcharge:.2f}</td></tr>
                    <tr><td>Electricity Duty (6%)</td><td>₹{bill.electricity_duty:.2f}</td></tr>
                    <tr><td>Tax (5%)</td><td>₹{bill.tax_amount:.2f}</td></tr>
                    <tr class="total-row"><td>Total Amount Due</td><td>₹{bill.total_amount:.2f}</td></tr>
                </table>
            </div>

            <div class="footer">
                <p>This is a computer-generated bill. For queries, contact support@aebs.gov.in</p>
                <p>Generated on {datetime.utcnow().strftime('%d %b %Y %H:%M:%S')} UTC</p>
            </div>
        </div>
    </body>
    </html>
    """
    return html
