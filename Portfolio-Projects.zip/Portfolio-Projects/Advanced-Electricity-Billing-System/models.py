"""
Database models for Advanced Electricity Billing System.
Defines Customer, MeterReading, Bill, Payment, and Tariff models
with proper SQLAlchemy relationships and helper methods.
"""

from datetime import datetime, timedelta
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class User(UserMixin, db.Model):
    """User model for authentication. Supports Admin and Customer roles."""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='customer')  # 'admin' or 'customer'
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationship to customer profile (only for customer role)
    customer = db.relationship('Customer', backref='user', uselist=False, lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def is_admin(self):
        return self.role == 'admin'

    def __repr__(self):
        return f'<User {self.username} ({self.role})>'


class Customer(db.Model):
    """Customer profile with billing and contact information."""
    __tablename__ = 'customers'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)
    customer_id = db.Column(db.String(20), unique=True, nullable=False, index=True)
    full_name = db.Column(db.String(120), nullable=False)
    phone = db.Column(db.String(20))
    address = db.Column(db.Text)
    city = db.Column(db.String(80))
    state = db.Column(db.String(80))
    pincode = db.Column(db.String(10))
    meter_number = db.Column(db.String(30), unique=True, nullable=False)
    connection_type = db.Column(db.String(30), default='Domestic')  # Domestic, Commercial, Industrial
    connection_date = db.Column(db.DateTime, default=datetime.utcnow)
    sanctioned_load = db.Column(db.Float, default=5.0)  # in kW
    is_active = db.Column(db.Boolean, default=True)

    # Relationships
    meter_readings = db.relationship('MeterReading', backref='customer', lazy='dynamic',
                                     order_by='MeterReading.reading_date.desc()')
    bills = db.relationship('Bill', backref='customer', lazy='dynamic',
                           order_by='Bill.bill_date.desc()')

    @property
    def total_outstanding(self):
        """Calculate total outstanding amount for this customer."""
        unpaid_bills = self.bills.filter(Bill.payment_status.in_(['unpaid', 'overdue'])).all()
        return sum(b.total_amount for b in unpaid_bills)

    @property
    def latest_reading(self):
        """Get the most recent meter reading."""
        return self.meter_readings.first()

    def __repr__(self):
        return f'<Customer {self.customer_id} - {self.full_name}>'


class MeterReading(db.Model):
    """Meter reading records with consumption calculation."""
    __tablename__ = 'meter_readings'

    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    reading_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    reading_value = db.Column(db.Float, nullable=False)  # Current meter reading in kWh
    previous_reading = db.Column(db.Float, default=0.0)
    units_consumed = db.Column(db.Float, default=0.0)
    reading_type = db.Column(db.String(20), default='manual')  # manual, smart_meter
    recorded_by = db.Column(db.String(80))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationship
    bill = db.relationship('Bill', backref='meter_reading', uselist=False, lazy=True)

    def calculate_consumption(self):
        """Calculate units consumed from previous and current reading."""
        self.units_consumed = max(0, self.reading_value - self.previous_reading)
        return self.units_consumed

    def __repr__(self):
        return f'<MeterReading {self.customer_id} - {self.units_consumed} units on {self.reading_date}>'


class Bill(db.Model):
    """Bill records with detailed charge breakdown."""
    __tablename__ = 'bills'

    id = db.Column(db.Integer, primary_key=True)
    bill_number = db.Column(db.String(30), unique=True, nullable=False, index=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    meter_reading_id = db.Column(db.Integer, db.ForeignKey('meter_readings.id'), nullable=True)
    bill_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    due_date = db.Column(db.DateTime, nullable=False)
    billing_period_start = db.Column(db.DateTime)
    billing_period_end = db.Column(db.DateTime)

    # Consumption
    units_consumed = db.Column(db.Float, default=0.0)

    # Charge breakdown
    base_charge = db.Column(db.Float, default=0.0)
    energy_charge = db.Column(db.Float, default=0.0)
    fuel_surcharge = db.Column(db.Float, default=0.0)
    electricity_duty = db.Column(db.Float, default=0.0)
    tax_amount = db.Column(db.Float, default=0.0)
    late_fee = db.Column(db.Float, default=0.0)
    total_amount = db.Column(db.Float, default=0.0)

    # Slab breakdown (stored as text for display)
    slab_details = db.Column(db.Text)

    # Payment tracking
    payment_status = db.Column(db.String(20), default='unpaid')  # paid, unpaid, overdue
    payment_date = db.Column(db.DateTime)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    payments = db.relationship('Payment', backref='bill', lazy='dynamic')

    @property
    def is_overdue(self):
        """Check if bill is overdue."""
        if self.payment_status == 'paid':
            return False
        return datetime.utcnow() > self.due_date

    def update_overdue_status(self):
        """Update payment status to overdue if past due date."""
        if self.payment_status == 'unpaid' and self.is_overdue:
            self.payment_status = 'overdue'

    def __repr__(self):
        return f'<Bill {self.bill_number} - ₹{self.total_amount:.2f} ({self.payment_status})>'


class Payment(db.Model):
    """Payment records linked to bills."""
    __tablename__ = 'payments'

    id = db.Column(db.Integer, primary_key=True)
    payment_id = db.Column(db.String(30), unique=True, nullable=False, index=True)
    bill_id = db.Column(db.Integer, db.ForeignKey('bills.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    payment_date = db.Column(db.DateTime, default=datetime.utcnow)
    payment_method = db.Column(db.String(30), default='online')  # online, cash, cheque, upi
    transaction_ref = db.Column(db.String(50))
    status = db.Column(db.String(20), default='completed')  # completed, pending, failed
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<Payment {self.payment_id} - ₹{self.amount:.2f}>'


class Tariff(db.Model):
    """Tariff/slab configuration for billing calculation."""
    __tablename__ = 'tariffs'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    connection_type = db.Column(db.String(30), nullable=False)  # Domestic, Commercial, Industrial
    slab_start = db.Column(db.Integer, nullable=False)  # Units from
    slab_end = db.Column(db.Integer, nullable=False)    # Units to (-1 for unlimited)
    rate_per_unit = db.Column(db.Float, nullable=False)  # Rate in ₹ per kWh
    base_charge = db.Column(db.Float, default=0.0)      # Fixed base charge
    is_active = db.Column(db.Boolean, default=True)
    effective_from = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        end = '∞' if self.slab_end == -1 else self.slab_end
        return f'<Tariff {self.connection_type}: {self.slab_start}-{end} units @ ₹{self.rate_per_unit}/unit>'


class EmailLog(db.Model):
    """Simulated email notification log."""
    __tablename__ = 'email_logs'

    id = db.Column(db.Integer, primary_key=True)
    recipient_email = db.Column(db.String(120), nullable=False)
    subject = db.Column(db.String(200), nullable=False)
    body = db.Column(db.Text)
    email_type = db.Column(db.String(30))  # bill_generated, payment_received, overdue_notice
    sent_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='sent')

    def __repr__(self):
        return f'<EmailLog to={self.recipient_email} type={self.email_type}>'
