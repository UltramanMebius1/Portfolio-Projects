import os
from datetime import datetime, date, timedelta
from functools import wraps

from flask import (Flask, render_template, redirect, url_for, flash, request,
                   jsonify, send_from_directory)
from flask_login import (LoginManager, login_user, logout_user, login_required,
                         current_user)
from werkzeug.utils import secure_filename

from config import Config
from models import db, User, Employee, Department, Attendance, Leave, Payroll

# ─── App Factory ────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.config.from_object(Config)
Config.init_app(app)

db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# ─── Helpers ────────────────────────────────────────────────────────────────────
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin():
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function


def manager_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.has_privilege():
            flash('Manager or Admin access required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


def generate_employee_id():
    last = Employee.query.order_by(Employee.id.desc()).first()
    num = (last.id + 1) if last else 1
    return f'EMP{num:04d}'


# ─── Context Processor ─────────────────────────────────────────────────────────
@app.context_processor
def inject_globals():
    pending_leaves = 0
    if current_user.is_authenticated and current_user.has_privilege():
        pending_leaves = Leave.query.filter_by(status='Pending').count()
    return dict(pending_leaves_count=pending_leaves, now=datetime.utcnow())


# ─── Auth Routes ────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        remember = request.form.get('remember', False)

        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            login_user(user, remember=bool(remember))
            flash(f'Welcome back, {username}!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard'))
        else:
            flash('Invalid username or password.', 'danger')

    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')

        if password != confirm:
            flash('Passwords do not match.', 'danger')
            return render_template('login.html', register=True)

        if User.query.filter_by(username=username).first():
            flash('Username already exists.', 'danger')
            return render_template('login.html', register=True)

        if User.query.filter_by(email=email).first():
            flash('Email already registered.', 'danger')
            return render_template('login.html', register=True)

        user = User(username=username, email=email, role='employee')
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))

    return render_template('login.html', register=True)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))


# ─── Dashboard ──────────────────────────────────────────────────────────────────
@app.route('/dashboard')
@login_required
def dashboard():
    total_employees = Employee.query.filter_by(status='Active').count()
    total_departments = Department.query.count()
    pending_leaves = Leave.query.filter_by(status='Pending').count()

    today = date.today()
    present_today = Attendance.query.filter_by(date=today, status='Present').count()

    # Department distribution
    departments = Department.query.all()
    dept_labels = [d.name for d in departments]
    dept_counts = [d.employee_count for d in departments]

    # Monthly attendance (last 7 days)
    attendance_labels = []
    attendance_present = []
    attendance_absent = []
    for i in range(6, -1, -1):
        d = today - timedelta(days=i)
        attendance_labels.append(d.strftime('%b %d'))
        present = Attendance.query.filter_by(date=d, status='Present').count()
        absent = Attendance.query.filter_by(date=d, status='Absent').count()
        attendance_present.append(present)
        attendance_absent.append(absent)

    # Payroll summary (last 6 months)
    payroll_labels = []
    payroll_amounts = []
    for i in range(5, -1, -1):
        m = today.month - i
        y = today.year
        if m <= 0:
            m += 12
            y -= 1
        month_name = date(y, m, 1).strftime('%b %Y')
        total = db.session.query(db.func.sum(Payroll.net_salary)).filter_by(month=m, year=y).scalar() or 0
        payroll_labels.append(month_name)
        payroll_amounts.append(float(total))

    # Recent activities
    recent_leaves = Leave.query.order_by(Leave.applied_on.desc()).limit(5).all()
    recent_attendance = Attendance.query.filter_by(date=today).order_by(Attendance.check_in.desc()).limit(5).all()

    # Total payroll this month
    current_payroll = db.session.query(db.func.sum(Payroll.net_salary)).filter_by(
        month=today.month, year=today.year
    ).scalar() or 0

    return render_template('dashboard.html',
                           total_employees=total_employees,
                           total_departments=total_departments,
                           pending_leaves=pending_leaves,
                           present_today=present_today,
                           current_payroll=current_payroll,
                           dept_labels=dept_labels,
                           dept_counts=dept_counts,
                           attendance_labels=attendance_labels,
                           attendance_present=attendance_present,
                           attendance_absent=attendance_absent,
                           payroll_labels=payroll_labels,
                           payroll_amounts=payroll_amounts,
                           recent_leaves=recent_leaves,
                           recent_attendance=recent_attendance)


# ─── Employee Routes ────────────────────────────────────────────────────────────
@app.route('/employees')
@login_required
def employees():
    search = request.args.get('search', '').strip()
    dept_filter = request.args.get('department', '')
    status_filter = request.args.get('status', '')

    query = Employee.query

    if search:
        query = query.filter(
            db.or_(
                Employee.first_name.ilike(f'%{search}%'),
                Employee.last_name.ilike(f'%{search}%'),
                Employee.email.ilike(f'%{search}%'),
                Employee.employee_id.ilike(f'%{search}%'),
                Employee.position.ilike(f'%{search}%')
            )
        )

    if dept_filter:
        query = query.filter_by(department_id=int(dept_filter))

    if status_filter:
        query = query.filter_by(status=status_filter)

    employee_list = query.order_by(Employee.first_name).all()
    departments = Department.query.order_by(Department.name).all()

    return render_template('employees.html',
                           employees=employee_list,
                           departments=departments,
                           search=search,
                           dept_filter=dept_filter,
                           status_filter=status_filter)


@app.route('/employees/add', methods=['POST'])
@login_required
@manager_required
def add_employee():
    try:
        emp = Employee(
            employee_id=generate_employee_id(),
            first_name=request.form.get('first_name', '').strip(),
            last_name=request.form.get('last_name', '').strip(),
            email=request.form.get('email', '').strip(),
            phone=request.form.get('phone', '').strip(),
            position=request.form.get('position', '').strip(),
            department_id=int(request.form.get('department_id')) if request.form.get('department_id') else None,
            salary=float(request.form.get('salary', 0)),
            employment_type=request.form.get('employment_type', 'Full-time'),
            gender=request.form.get('gender', ''),
            date_of_birth=datetime.strptime(request.form.get('date_of_birth'), '%Y-%m-%d').date() if request.form.get('date_of_birth') else None,
            hire_date=datetime.strptime(request.form.get('hire_date'), '%Y-%m-%d').date() if request.form.get('hire_date') else date.today(),
            address=request.form.get('address', '').strip(),
            city=request.form.get('city', '').strip(),
            state=request.form.get('state', '').strip(),
            zip_code=request.form.get('zip_code', '').strip(),
        )

        # Handle profile picture upload
        if 'profile_picture' in request.files:
            file = request.files['profile_picture']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(f"{emp.employee_id}_{file.filename}")
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                emp.profile_picture = filename

        db.session.add(emp)
        db.session.commit()
        flash(f'Employee {emp.full_name} added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding employee: {str(e)}', 'danger')

    return redirect(url_for('employees'))


@app.route('/employees/<int:emp_id>')
@login_required
def employee_detail(emp_id):
    emp = Employee.query.get_or_404(emp_id)
    attendances = Attendance.query.filter_by(employee_id=emp.id).order_by(Attendance.date.desc()).limit(30).all()
    leaves = Leave.query.filter_by(employee_id=emp.id).order_by(Leave.applied_on.desc()).all()
    payrolls = Payroll.query.filter_by(employee_id=emp.id).order_by(Payroll.year.desc(), Payroll.month.desc()).all()

    # Attendance stats
    total_present = Attendance.query.filter_by(employee_id=emp.id, status='Present').count()
    total_absent = Attendance.query.filter_by(employee_id=emp.id, status='Absent').count()
    total_late = Attendance.query.filter_by(employee_id=emp.id, status='Late').count()
    total_leaves_taken = Leave.query.filter_by(employee_id=emp.id, status='Approved').count()

    return render_template('employee_detail.html',
                           employee=emp,
                           attendances=attendances,
                           leaves=leaves,
                           payrolls=payrolls,
                           total_present=total_present,
                           total_absent=total_absent,
                           total_late=total_late,
                           total_leaves_taken=total_leaves_taken)


@app.route('/employees/<int:emp_id>/edit', methods=['POST'])
@login_required
@manager_required
def edit_employee(emp_id):
    emp = Employee.query.get_or_404(emp_id)
    try:
        emp.first_name = request.form.get('first_name', emp.first_name).strip()
        emp.last_name = request.form.get('last_name', emp.last_name).strip()
        emp.email = request.form.get('email', emp.email).strip()
        emp.phone = request.form.get('phone', emp.phone).strip()
        emp.position = request.form.get('position', emp.position).strip()
        emp.department_id = int(request.form.get('department_id')) if request.form.get('department_id') else emp.department_id
        emp.salary = float(request.form.get('salary', emp.salary))
        emp.employment_type = request.form.get('employment_type', emp.employment_type)
        emp.status = request.form.get('status', emp.status)
        emp.gender = request.form.get('gender', emp.gender)
        emp.address = request.form.get('address', emp.address).strip()
        emp.city = request.form.get('city', emp.city).strip()
        emp.state = request.form.get('state', emp.state).strip()
        emp.zip_code = request.form.get('zip_code', emp.zip_code).strip()

        if request.form.get('date_of_birth'):
            emp.date_of_birth = datetime.strptime(request.form.get('date_of_birth'), '%Y-%m-%d').date()

        if 'profile_picture' in request.files:
            file = request.files['profile_picture']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(f"{emp.employee_id}_{file.filename}")
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                emp.profile_picture = filename

        db.session.commit()
        flash(f'Employee {emp.full_name} updated successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating employee: {str(e)}', 'danger')

    return redirect(url_for('employee_detail', emp_id=emp.id))


@app.route('/employees/<int:emp_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_employee(emp_id):
    emp = Employee.query.get_or_404(emp_id)
    try:
        name = emp.full_name
        db.session.delete(emp)
        db.session.commit()
        flash(f'Employee {name} deleted successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting employee: {str(e)}', 'danger')
    return redirect(url_for('employees'))


# ─── Attendance Routes ──────────────────────────────────────────────────────────
@app.route('/attendance')
@login_required
def attendance():
    filter_date = request.args.get('date', date.today().isoformat())
    try:
        selected_date = datetime.strptime(filter_date, '%Y-%m-%d').date()
    except ValueError:
        selected_date = date.today()

    records = Attendance.query.filter_by(date=selected_date).order_by(Attendance.check_in.desc()).all()
    all_employees = Employee.query.filter_by(status='Active').order_by(Employee.first_name).all()

    return render_template('attendance.html',
                           records=records,
                           employees=all_employees,
                           selected_date=selected_date)


@app.route('/attendance/checkin', methods=['POST'])
@login_required
def attendance_checkin():
    employee_id = request.form.get('employee_id')
    if not employee_id:
        flash('Please select an employee.', 'danger')
        return redirect(url_for('attendance'))

    emp = Employee.query.get_or_404(int(employee_id))
    today = date.today()
    now = datetime.now()

    existing = Attendance.query.filter_by(employee_id=emp.id, date=today).first()
    if existing:
        flash(f'{emp.full_name} has already checked in today.', 'warning')
    else:
        status = 'Late' if now.hour >= 10 else 'Present'
        record = Attendance(
            employee_id=emp.id,
            date=today,
            check_in=now,
            status=status,
            notes=request.form.get('notes', '')
        )
        db.session.add(record)
        db.session.commit()
        flash(f'{emp.full_name} checked in at {now.strftime("%I:%M %p")}.', 'success')

    return redirect(url_for('attendance'))


@app.route('/attendance/checkout', methods=['POST'])
@login_required
def attendance_checkout():
    record_id = request.form.get('record_id')
    if not record_id:
        flash('Invalid attendance record.', 'danger')
        return redirect(url_for('attendance'))

    record = Attendance.query.get_or_404(int(record_id))
    if record.check_out:
        flash('Already checked out.', 'warning')
    else:
        record.check_out = datetime.now()
        record.work_hours = record.calculated_hours
        db.session.commit()
        flash(f'Checked out at {record.check_out.strftime("%I:%M %p")}. Hours: {record.work_hours}h', 'success')

    return redirect(url_for('attendance'))


@app.route('/attendance/mark-absent', methods=['POST'])
@login_required
@manager_required
def mark_absent():
    employee_id = request.form.get('employee_id')
    mark_date = request.form.get('date', date.today().isoformat())
    try:
        mark_d = datetime.strptime(mark_date, '%Y-%m-%d').date()
    except ValueError:
        mark_d = date.today()

    emp = Employee.query.get_or_404(int(employee_id))
    existing = Attendance.query.filter_by(employee_id=emp.id, date=mark_d).first()
    if existing:
        flash(f'Record already exists for {emp.full_name} on {mark_d}.', 'warning')
    else:
        record = Attendance(employee_id=emp.id, date=mark_d, status='Absent')
        db.session.add(record)
        db.session.commit()
        flash(f'{emp.full_name} marked absent for {mark_d}.', 'info')

    return redirect(url_for('attendance'))


# ─── Leave Routes ───────────────────────────────────────────────────────────────
@app.route('/leave')
@login_required
def leave():
    if current_user.has_privilege():
        pending = Leave.query.filter_by(status='Pending').order_by(Leave.applied_on.desc()).all()
        all_leaves = Leave.query.order_by(Leave.applied_on.desc()).limit(50).all()
    else:
        emp = Employee.query.filter_by(user_id=current_user.id).first()
        pending = Leave.query.filter_by(employee_id=emp.id, status='Pending').all() if emp else []
        all_leaves = Leave.query.filter_by(employee_id=emp.id).order_by(Leave.applied_on.desc()).all() if emp else []

    employees = Employee.query.filter_by(status='Active').order_by(Employee.first_name).all()

    return render_template('leave.html',
                           pending_leaves=pending,
                           all_leaves=all_leaves,
                           employees=employees)


@app.route('/leave/apply', methods=['POST'])
@login_required
def apply_leave():
    try:
        employee_id = request.form.get('employee_id')
        if not employee_id:
            # Try to find employee linked to current user
            emp = Employee.query.filter_by(user_id=current_user.id).first()
            if emp:
                employee_id = emp.id
            else:
                flash('No employee profile linked to your account.', 'danger')
                return redirect(url_for('leave'))

        leave_entry = Leave(
            employee_id=int(employee_id),
            leave_type=request.form.get('leave_type', 'Casual'),
            start_date=datetime.strptime(request.form.get('start_date'), '%Y-%m-%d').date(),
            end_date=datetime.strptime(request.form.get('end_date'), '%Y-%m-%d').date(),
            reason=request.form.get('reason', '').strip(),
        )
        db.session.add(leave_entry)
        db.session.commit()
        flash('Leave application submitted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error applying for leave: {str(e)}', 'danger')

    return redirect(url_for('leave'))


@app.route('/leave/<int:leave_id>/approve', methods=['POST'])
@login_required
@manager_required
def approve_leave(leave_id):
    leave_entry = Leave.query.get_or_404(leave_id)
    leave_entry.status = 'Approved'
    leave_entry.reviewed_by = current_user.username
    leave_entry.reviewed_on = datetime.utcnow()
    leave_entry.reviewer_notes = request.form.get('notes', '')
    db.session.commit()
    flash('Leave approved.', 'success')
    return redirect(url_for('leave'))


@app.route('/leave/<int:leave_id>/reject', methods=['POST'])
@login_required
@manager_required
def reject_leave(leave_id):
    leave_entry = Leave.query.get_or_404(leave_id)
    leave_entry.status = 'Rejected'
    leave_entry.reviewed_by = current_user.username
    leave_entry.reviewed_on = datetime.utcnow()
    leave_entry.reviewer_notes = request.form.get('notes', '')
    db.session.commit()
    flash('Leave rejected.', 'info')
    return redirect(url_for('leave'))


# ─── Payroll Routes ─────────────────────────────────────────────────────────────
@app.route('/payroll')
@login_required
def payroll():
    month_filter = request.args.get('month', datetime.now().month, type=int)
    year_filter = request.args.get('year', datetime.now().year, type=int)

    payrolls = Payroll.query.filter_by(month=month_filter, year=year_filter)\
        .order_by(Payroll.generated_on.desc()).all()

    employees = Employee.query.filter_by(status='Active').order_by(Employee.first_name).all()

    total_gross = sum(p.gross_salary for p in payrolls)
    total_deductions = sum(p.total_deductions for p in payrolls)
    total_net = sum(p.net_salary for p in payrolls)

    return render_template('payroll.html',
                           payrolls=payrolls,
                           employees=employees,
                           month_filter=month_filter,
                           year_filter=year_filter,
                           total_gross=total_gross,
                           total_deductions=total_deductions,
                           total_net=total_net)


@app.route('/payroll/generate', methods=['POST'])
@login_required
@admin_required
def generate_payroll():
    try:
        employee_id = request.form.get('employee_id')
        month = int(request.form.get('month', datetime.now().month))
        year = int(request.form.get('year', datetime.now().year))

        if employee_id == 'all':
            employees = Employee.query.filter_by(status='Active').all()
        else:
            employees = [Employee.query.get_or_404(int(employee_id))]

        generated = 0
        for emp in employees:
            existing = Payroll.query.filter_by(employee_id=emp.id, month=month, year=year).first()
            if existing:
                continue

            p = Payroll(
                employee_id=emp.id,
                month=month,
                year=year,
                basic_salary=emp.salary,
                bonus=float(request.form.get('bonus', 0)),
                other_deductions=float(request.form.get('other_deductions', 0)),
            )
            p.calculate()
            db.session.add(p)
            generated += 1

        db.session.commit()
        flash(f'Payroll generated for {generated} employee(s).', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error generating payroll: {str(e)}', 'danger')

    return redirect(url_for('payroll'))


@app.route('/payroll/<int:payroll_id>/pay', methods=['POST'])
@login_required
@admin_required
def mark_paid(payroll_id):
    p = Payroll.query.get_or_404(payroll_id)
    p.payment_status = 'Paid'
    p.payment_date = date.today()
    db.session.commit()
    flash('Payment marked as paid.', 'success')
    return redirect(url_for('payroll'))


# ─── Department Routes ──────────────────────────────────────────────────────────
@app.route('/departments')
@login_required
def departments():
    dept_list = Department.query.order_by(Department.name).all()
    return render_template('departments.html', departments=dept_list)


@app.route('/departments/add', methods=['POST'])
@login_required
@admin_required
def add_department():
    try:
        dept = Department(
            name=request.form.get('name', '').strip(),
            description=request.form.get('description', '').strip(),
            location=request.form.get('location', '').strip(),
            budget=float(request.form.get('budget', 0)),
        )
        db.session.add(dept)
        db.session.commit()
        flash(f'Department "{dept.name}" added successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error adding department: {str(e)}', 'danger')

    return redirect(url_for('departments'))


@app.route('/departments/<int:dept_id>/edit', methods=['POST'])
@login_required
@admin_required
def edit_department(dept_id):
    dept = Department.query.get_or_404(dept_id)
    try:
        dept.name = request.form.get('name', dept.name).strip()
        dept.description = request.form.get('description', dept.description).strip()
        dept.location = request.form.get('location', dept.location).strip()
        dept.budget = float(request.form.get('budget', dept.budget))
        db.session.commit()
        flash(f'Department "{dept.name}" updated.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating department: {str(e)}', 'danger')

    return redirect(url_for('departments'))


@app.route('/departments/<int:dept_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_department(dept_id):
    dept = Department.query.get_or_404(dept_id)
    if dept.employee_count > 0:
        flash(f'Cannot delete "{dept.name}" — has {dept.employee_count} employees.', 'danger')
    else:
        try:
            db.session.delete(dept)
            db.session.commit()
            flash(f'Department deleted.', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error deleting department: {str(e)}', 'danger')

    return redirect(url_for('departments'))


# ─── Reports Routes ─────────────────────────────────────────────────────────────
@app.route('/reports')
@login_required
@manager_required
def reports():
    return render_template('reports.html')


@app.route('/reports/generate', methods=['POST'])
@login_required
@manager_required
def generate_report():
    report_type = request.form.get('report_type', 'employee_list')
    start_date_str = request.form.get('start_date', '')
    end_date_str = request.form.get('end_date', '')

    try:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date() if start_date_str else date.today() - timedelta(days=30)
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date() if end_date_str else date.today()
    except ValueError:
        start_date = date.today() - timedelta(days=30)
        end_date = date.today()

    report_data = {}
    report_title = ''

    if report_type == 'employee_list':
        report_title = 'Employee Directory Report'
        report_data['employees'] = Employee.query.order_by(Employee.first_name).all()
        report_data['departments'] = Department.query.all()

    elif report_type == 'attendance':
        report_title = f'Attendance Report ({start_date} to {end_date})'
        report_data['records'] = Attendance.query.filter(
            Attendance.date.between(start_date, end_date)
        ).order_by(Attendance.date.desc()).all()
        report_data['total_present'] = sum(1 for r in report_data['records'] if r.status == 'Present')
        report_data['total_absent'] = sum(1 for r in report_data['records'] if r.status == 'Absent')
        report_data['total_late'] = sum(1 for r in report_data['records'] if r.status == 'Late')

    elif report_type == 'leave':
        report_title = f'Leave Report ({start_date} to {end_date})'
        report_data['leaves'] = Leave.query.filter(
            Leave.start_date.between(start_date, end_date)
        ).order_by(Leave.start_date.desc()).all()
        report_data['approved'] = sum(1 for l in report_data['leaves'] if l.status == 'Approved')
        report_data['rejected'] = sum(1 for l in report_data['leaves'] if l.status == 'Rejected')
        report_data['pending'] = sum(1 for l in report_data['leaves'] if l.status == 'Pending')

    elif report_type == 'payroll':
        report_title = f'Payroll Report ({start_date} to {end_date})'
        payrolls = Payroll.query.filter(
            db.and_(
                Payroll.year >= start_date.year,
                Payroll.year <= end_date.year
            )
        ).order_by(Payroll.year.desc(), Payroll.month.desc()).all()
        report_data['payrolls'] = payrolls
        report_data['total_gross'] = sum(p.gross_salary for p in payrolls)
        report_data['total_deductions'] = sum(p.total_deductions for p in payrolls)
        report_data['total_net'] = sum(p.net_salary for p in payrolls)

    elif report_type == 'department':
        report_title = 'Department Summary Report'
        report_data['departments'] = Department.query.all()
        report_data['total_budget'] = sum(d.budget for d in report_data['departments'])
        report_data['total_employees'] = Employee.query.filter_by(status='Active').count()

    return render_template('reports.html',
                           report_type=report_type,
                           report_title=report_title,
                           report_data=report_data,
                           start_date=start_date,
                           end_date=end_date,
                           generated=True)


# ─── API endpoints (for charts) ─────────────────────────────────────────────────
@app.route('/api/dashboard-stats')
@login_required
def api_dashboard_stats():
    today = date.today()
    return jsonify({
        'total_employees': Employee.query.filter_by(status='Active').count(),
        'total_departments': Department.query.count(),
        'pending_leaves': Leave.query.filter_by(status='Pending').count(),
        'present_today': Attendance.query.filter_by(date=today, status='Present').count(),
    })


# ─── Error handlers ─────────────────────────────────────────────────────────────
@app.errorhandler(404)
def not_found_error(error):
    flash('Page not found.', 'warning')
    return redirect(url_for('dashboard'))


@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    flash('An internal error occurred.', 'danger')
    return redirect(url_for('dashboard'))


# ─── Main ───────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        # Create default admin if no users exist
        if not User.query.first():
            print('[*] No users found. Run seed_data.py to populate demo data.')
    app.run(debug=True, host='0.0.0.0', port=5000)
