from datetime import datetime, date, time
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='employee')  # admin, manager, employee
    is_active_user = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    employee = db.relationship('Employee', backref='user', uselist=False, lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def is_admin(self):
        return self.role == 'admin'

    def is_manager(self):
        return self.role == 'manager'

    def has_privilege(self):
        return self.role in ('admin', 'manager')

    def __repr__(self):
        return f'<User {self.username}>'


class Department(db.Model):
    __tablename__ = 'departments'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    description = db.Column(db.Text)
    location = db.Column(db.String(100))
    budget = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    employees = db.relationship('Employee', backref='department', lazy=True)

    @property
    def employee_count(self):
        return len(self.employees)

    def __repr__(self):
        return f'<Department {self.name}>'


class Employee(db.Model):
    __tablename__ = 'employees'

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.String(20), unique=True, nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20))
    date_of_birth = db.Column(db.Date)
    gender = db.Column(db.String(10))
    address = db.Column(db.Text)
    city = db.Column(db.String(50))
    state = db.Column(db.String(50))
    zip_code = db.Column(db.String(10))
    position = db.Column(db.String(100))
    employment_type = db.Column(db.String(20), default='Full-time')  # Full-time, Part-time, Contract
    hire_date = db.Column(db.Date, default=date.today)
    salary = db.Column(db.Float, default=0.0)
    profile_picture = db.Column(db.String(200), default='default_avatar.png')
    status = db.Column(db.String(20), default='Active')  # Active, Inactive, On Leave

    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)

    attendances = db.relationship('Attendance', backref='employee', lazy=True, cascade='all, delete-orphan')
    leaves = db.relationship('Leave', backref='employee', lazy=True, cascade='all, delete-orphan')
    payrolls = db.relationship('Payroll', backref='employee', lazy=True, cascade='all, delete-orphan')

    @property
    def full_name(self):
        return f'{self.first_name} {self.last_name}'

    def __repr__(self):
        return f'<Employee {self.full_name}>'


class Attendance(db.Model):
    __tablename__ = 'attendance'

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey('employees.id'), nullable=False)
    date = db.Column(db.Date, default=date.today, nullable=False)
    check_in = db.Column(db.DateTime, nullable=True)
    check_out = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), default='Present')  # Present, Absent, Late, Half-day
    work_hours = db.Column(db.Float, default=0.0)
    notes = db.Column(db.Text)

    @property
    def calculated_hours(self):
        if self.check_in and self.check_out:
            delta = self.check_out - self.check_in
            return round(delta.total_seconds() / 3600, 2)
        return 0.0

    def __repr__(self):
        return f'<Attendance {self.employee_id} - {self.date}>'


class Leave(db.Model):
    __tablename__ = 'leaves'

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey('employees.id'), nullable=False)
    leave_type = db.Column(db.String(30), nullable=False)  # Sick, Casual, Annual, Maternity, Other
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='Pending')  # Pending, Approved, Rejected
    applied_on = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_by = db.Column(db.String(100))
    reviewed_on = db.Column(db.DateTime)
    reviewer_notes = db.Column(db.Text)

    @property
    def total_days(self):
        if self.start_date and self.end_date:
            return (self.end_date - self.start_date).days + 1
        return 0

    def __repr__(self):
        return f'<Leave {self.employee_id} - {self.leave_type}>'


class Payroll(db.Model):
    __tablename__ = 'payroll'

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey('employees.id'), nullable=False)
    month = db.Column(db.Integer, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    basic_salary = db.Column(db.Float, default=0.0)
    hra = db.Column(db.Float, default=0.0)  # House Rent Allowance
    da = db.Column(db.Float, default=0.0)  # Dearness Allowance
    ta = db.Column(db.Float, default=0.0)  # Travel Allowance
    bonus = db.Column(db.Float, default=0.0)
    pf_deduction = db.Column(db.Float, default=0.0)  # Provident Fund
    tax_deduction = db.Column(db.Float, default=0.0)
    insurance_deduction = db.Column(db.Float, default=0.0)
    other_deductions = db.Column(db.Float, default=0.0)
    gross_salary = db.Column(db.Float, default=0.0)
    total_deductions = db.Column(db.Float, default=0.0)
    net_salary = db.Column(db.Float, default=0.0)
    payment_status = db.Column(db.String(20), default='Pending')  # Pending, Paid, On Hold
    payment_date = db.Column(db.Date)
    generated_on = db.Column(db.DateTime, default=datetime.utcnow)

    def calculate(self):
        self.hra = round(self.basic_salary * 0.20, 2)
        self.da = round(self.basic_salary * 0.10, 2)
        self.ta = round(self.basic_salary * 0.05, 2)
        self.gross_salary = round(self.basic_salary + self.hra + self.da + self.ta + self.bonus, 2)
        self.pf_deduction = round(self.basic_salary * 0.12, 2)
        self.tax_deduction = round(self.gross_salary * 0.10, 2)
        self.insurance_deduction = round(self.basic_salary * 0.02, 2)
        self.total_deductions = round(
            self.pf_deduction + self.tax_deduction + self.insurance_deduction + self.other_deductions, 2
        )
        self.net_salary = round(self.gross_salary - self.total_deductions, 2)

    def __repr__(self):
        return f'<Payroll {self.employee_id} - {self.month}/{self.year}>'
