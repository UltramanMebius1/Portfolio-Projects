"""
Ransomware Detection System — Complete Flask Application
File system monitoring, entropy analysis, suspicious extension detection, process killing, alerting.
"""

import os, math, random, json
from datetime import datetime, timedelta
from collections import Counter, defaultdict
from flask import Flask, render_template_string, request, redirect, jsonify

app = Flask(__name__)
app.secret_key = "ransomware-detect-secret"

# ── Ransomware Detection Engine ───────────────────────────────────────────

RANSOMWARE_EXTENSIONS = {
    ".encrypted", ".locked", ".crypt", ".enc", ".crypted", ".locky", ".cerber",
    ".zepto", ".thor", ".aesir", ".zzzzz", ".micro", ".fun", ".crypto",
    ".WNCRY", ".wcry", ".wncrypt", ".wncryt", ".lockbit", ".revil", ".ryuk",
}

RANSOM_NOTE_NAMES = {
    "readme_decrypt.txt", "how_to_decrypt.txt", "ransom_note.txt", "decrypt_instructions.txt",
    "help_decrypt.html", "restore_files.txt", "your_files.txt", "attention.txt",
    "!readme!.txt", "_readme.txt",
}

class FileEvent:
    def __init__(self, path, action, timestamp=None, process=None, old_name=None):
        self.path = path
        self.action = action  # create, modify, rename, delete
        self.timestamp = timestamp or datetime.utcnow()
        self.process = process or "unknown.exe"
        self.old_name = old_name
        self.entropy = 0
        self.suspicious = False
        self.reason = ""

    def to_dict(self):
        return {"path": self.path, "action": self.action, "timestamp": self.timestamp.isoformat(),
                "process": self.process, "entropy": self.entropy, "suspicious": self.suspicious, "reason": self.reason}


class RansomwareDetector:
    def __init__(self):
        self.events = []
        self.alerts = []
        self.file_changes_per_second = defaultdict(int)
        self.quarantined_processes = set()
        self.stats = {"total_events": 0, "suspicious": 0, "alerts": 0, "processes_killed": 0}

    def simulate_ransomware_attack(self):
        """Simulate a realistic ransomware attack sequence."""
        self.events = []
        self.alerts = []
        base_time = datetime.utcnow()
        process = "suspicious_svchost.exe"

        # Phase 1: Reconnaissance (file enumeration)
        dirs = ["C:\\Users\\Documents", "C:\\Users\\Desktop", "C:\\Users\\Pictures", "C:\\SharedDrive\\Finance"]
        for i, d in enumerate(dirs):
            self.events.append(FileEvent(d, "enumerate", base_time + timedelta(seconds=i), process))

        # Phase 2: Shadow copy deletion
        self.events.append(FileEvent("vssadmin delete shadows /all /quiet", "execute_command",
                                     base_time + timedelta(seconds=5), "cmd.exe"))

        # Phase 3: Mass file encryption
        files = [
            ("report_q4.docx", ".docx"), ("budget_2024.xlsx", ".xlsx"), ("presentation.pptx", ".pptx"),
            ("employee_data.csv", ".csv"), ("database_backup.sql", ".sql"), ("logo.png", ".png"),
            ("contract.pdf", ".pdf"), ("meeting_notes.txt", ".txt"), ("salary_data.xlsx", ".xlsx"),
            ("project_plan.mpp", ".mpp"), ("audit_report.docx", ".docx"), ("tax_returns.pdf", ".pdf"),
            ("photo_001.jpg", ".jpg"), ("video_clip.mp4", ".mp4"), ("source_code.py", ".py"),
        ]

        for i, (fname, ext) in enumerate(files):
            t = base_time + timedelta(seconds=10 + i * 0.5)
            # File read
            self.events.append(FileEvent(f"C:\\Users\\Documents\\{fname}", "read", t, process))
            # File encrypted & renamed
            event = FileEvent(f"C:\\Users\\Documents\\{fname}.LOCKED", "rename", t + timedelta(milliseconds=200),
                              process, old_name=f"C:\\Users\\Documents\\{fname}")
            event.entropy = round(random.uniform(7.5, 7.99), 4)
            event.suspicious = True
            event.reason = f"High entropy ({event.entropy}) + ransomware extension (.LOCKED)"
            self.events.append(event)

        # Phase 4: Ransom note
        note_event = FileEvent("C:\\Users\\Desktop\\HOW_TO_DECRYPT.txt", "create",
                               base_time + timedelta(seconds=30), process)
        note_event.suspicious = True
        note_event.reason = "Ransom note file created"
        self.events.append(note_event)

        # Run detection
        self._analyze_events()
        return self.events

    def simulate_normal_activity(self, count=50):
        """Generate normal file activity for comparison."""
        normal_processes = ["explorer.exe", "word.exe", "excel.exe", "chrome.exe", "notepad.exe"]
        normal_extensions = [".docx", ".xlsx", ".pdf", ".txt", ".py", ".json"]
        base_time = datetime.utcnow()

        for i in range(count):
            fname = f"normal_file_{i}{random.choice(normal_extensions)}"
            event = FileEvent(f"C:\\Users\\Documents\\{fname}",
                              random.choice(["create", "modify", "read"]),
                              base_time + timedelta(seconds=i * random.randint(5, 60)),
                              random.choice(normal_processes))
            event.entropy = round(random.uniform(3.0, 5.5), 4)
            self.events.append(event)

        self._analyze_events()

    def _analyze_events(self):
        """Analyze file events for ransomware indicators."""
        self.alerts = []

        # 1. Check for ransomware extensions
        ransom_ext_count = sum(1 for e in self.events if any(e.path.lower().endswith(ext) for ext in RANSOMWARE_EXTENSIONS))
        if ransom_ext_count > 3:
            self._add_alert("critical", "Mass Ransomware Extension Detected",
                            f"{ransom_ext_count} files renamed with ransomware extensions",
                            "T1486 — Data Encrypted for Impact")

        # 2. High entropy files
        high_entropy = [e for e in self.events if e.entropy > 7.0]
        if len(high_entropy) > 5:
            self._add_alert("critical", "Mass File Encryption Detected",
                            f"{len(high_entropy)} files with entropy > 7.0 (encrypted)",
                            "T1486 — Data Encrypted for Impact")

        # 3. Rapid file changes
        rename_events = [e for e in self.events if e.action == "rename"]
        if len(rename_events) > 10:
            time_span = max(1, (rename_events[-1].timestamp - rename_events[0].timestamp).total_seconds())
            rate = len(rename_events) / time_span
            if rate > 0.5:
                self._add_alert("critical", "Abnormal File Rename Rate",
                                f"{len(rename_events)} renames in {time_span:.0f}s (rate: {rate:.1f}/s)",
                                "T1486")

        # 4. Shadow copy deletion
        for e in self.events:
            if "vssadmin" in e.path.lower() and "delete" in e.path.lower():
                self._add_alert("critical", "Volume Shadow Copy Deletion",
                                "vssadmin delete shadows detected — ransomware precursor",
                                "T1490 — Inhibit System Recovery")

        # 5. Ransom note detection
        for e in self.events:
            basename = os.path.basename(e.path).lower()
            if basename in RANSOM_NOTE_NAMES or "decrypt" in basename:
                if e.action == "create":
                    self._add_alert("critical", "Ransom Note Detected",
                                    f"Ransom note created: {e.path}",
                                    "T1486")

        # 6. Update stats
        self.stats["total_events"] = len(self.events)
        self.stats["suspicious"] = sum(1 for e in self.events if e.suspicious)
        self.stats["alerts"] = len(self.alerts)

    def _add_alert(self, severity, title, description, mitre=""):
        self.alerts.append({
            "id": len(self.alerts) + 1,
            "timestamp": datetime.utcnow().isoformat(),
            "severity": severity,
            "title": title,
            "description": description,
            "mitre": mitre,
            "action_taken": "Process quarantine recommended",
        })

    def calculate_entropy(self, data: bytes) -> float:
        if not data: return 0.0
        counter = Counter(data)
        length = len(data)
        return -sum((c / length) * math.log2(c / length) for c in counter.values())


detector = RansomwareDetector()

# ── Routes ─────────────────────────────────────────────────────────────────

TMPL = """
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Ransomware Detection</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0a0610;--card:#1a1230;--text:#e0d8f0;--dim:#8070a0;--red:#ff3366;--orange:#ff8c42;--green:#22c55e;--purple:#9b6dff;--border:#2a1e4a;--blue:#4a8ef7}
body{font-family:'Segoe UI',sans-serif;background:var(--bg);color:var(--text)}
.header{background:linear-gradient(135deg,#1a1230,#100a20);border-bottom:1px solid var(--border);padding:16px 32px}
.header h1{font-size:1.4rem;background:linear-gradient(135deg,#ff3366,#9b6dff);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav{background:#12091f;border-bottom:1px solid var(--border);display:flex;padding:0 32px}
.nav a{color:var(--dim);text-decoration:none;padding:12px 18px;font-size:.85rem;border-bottom:2px solid transparent;transition:.2s}
.nav a:hover,.nav a.active{color:var(--purple);border-bottom-color:var(--purple)}
.container{max-width:1400px;margin:0 auto;padding:24px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:24px}
.stat{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:20px}
.stat .label{font-size:.7rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px}
.stat .val{font-size:1.8rem;font-weight:700}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:24px}
.card h2{font-size:1.1rem;margin-bottom:16px}
table{width:100%;border-collapse:collapse}
th{text-align:left;padding:10px;font-size:.7rem;text-transform:uppercase;color:var(--dim);border-bottom:1px solid var(--border)}
td{padding:10px;border-bottom:1px solid var(--border);font-size:.85rem}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:600;text-transform:uppercase}
.badge.critical{background:rgba(255,51,102,.12);color:var(--red)}.badge.high{background:rgba(255,140,66,.12);color:var(--orange)}
.badge.medium{background:rgba(155,109,255,.12);color:var(--purple)}.badge.low{background:rgba(34,197,94,.12);color:var(--green)}
.btn{padding:8px 16px;border-radius:8px;border:none;cursor:pointer;font-size:.85rem;font-weight:500;text-decoration:none;display:inline-block;margin:2px}
.btn-red{background:var(--red);color:#fff}.btn-purple{background:var(--purple);color:#fff}
.btn-blue{background:var(--blue);color:#fff}
.alert-card{padding:12px 16px;margin:8px 0;border-radius:8px;border-left:4px solid}
.alert-card.critical{border-color:var(--red);background:rgba(255,51,102,.06)}
.flash{padding:12px;border-radius:8px;margin-bottom:16px;background:rgba(155,109,255,.12);border:1px solid rgba(155,109,255,.3);color:var(--purple);font-size:.85rem}
</style></head><body>
<div class="header"><h1>🔒 Ransomware Detection System</h1></div>
<div class="nav">
    <a href="/" class="{{ 'active' if page=='dash' }}">Dashboard</a>
    <a href="/events" class="{{ 'active' if page=='events' }}">File Events</a>
    <a href="/alerts" class="{{ 'active' if page=='alerts' }}">Alerts</a>
</div>
<div class="container">{% if flash %}<div class="flash">{{ flash }}</div>{% endif %}{% block c %}{% endblock %}</div>
</body></html>
"""

@app.route("/")
def dashboard():
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="grid">
    <div class="stat"><div class="label">File Events</div><div class="val" style="color:var(--purple)">{{ s.total_events }}</div></div>
    <div class="stat"><div class="label">Suspicious</div><div class="val" style="color:var(--orange)">{{ s.suspicious }}</div></div>
    <div class="stat"><div class="label">Alerts</div><div class="val" style="color:var(--red)">{{ s.alerts }}</div></div>
    <div class="stat"><div class="label">Quarantined</div><div class="val" style="color:var(--green)">{{ s.processes_killed }}</div></div>
</div>
<div class="card">
    <h2>⚡ Simulation Controls</h2>
    <a href="/simulate/ransomware" class="btn btn-red">🔐 Simulate Ransomware Attack</a>
    <a href="/simulate/normal" class="btn btn-blue">📁 Simulate Normal Activity</a>
</div>
{% for a in detector.alerts %}
<div class="alert-card critical">
    <strong style="color:var(--red)">🚨 {{ a.title }}</strong> <span class="badge critical">{{ a.severity }}</span><br>
    <span style="font-size:.85rem">{{ a.description }}</span><br>
    <span style="font-size:.75rem;color:var(--dim)">MITRE: {{ a.mitre }}</span>
</div>{% endfor %}
""")
    from jinja2 import Template
    return Template(content).render(page="dash", s=detector.stats, detector=detector, flash=request.args.get("msg"))


@app.route("/simulate/<sim_type>")
def simulate(sim_type):
    detector.events = []
    detector.alerts = []
    if sim_type == "ransomware":
        detector.simulate_ransomware_attack()
        msg = f"Ransomware simulation complete: {len(detector.events)} events, {len(detector.alerts)} alerts"
    else:
        detector.simulate_normal_activity()
        msg = f"Normal activity simulated: {len(detector.events)} events"
    return redirect(f"/?msg={msg}")


@app.route("/events")
def events_page():
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>📂 File Events ({{ detector.events|length }})</h2>
    <table><thead><tr><th>Time</th><th>Action</th><th>Path</th><th>Process</th><th>Entropy</th><th>Suspicious</th></tr></thead><tbody>
    {% for e in detector.events %}
    <tr style="{{ 'background:rgba(255,51,102,.05)' if e.suspicious else '' }}">
        <td style="font-size:.7rem">{{ e.timestamp.strftime('%H:%M:%S.%f')[:12] }}</td>
        <td><span class="badge {{ 'critical' if e.suspicious else 'low' }}">{{ e.action }}</span></td>
        <td style="font-size:.8rem;font-family:monospace">{{ e.path[:60] }}</td>
        <td style="font-size:.8rem">{{ e.process }}</td>
        <td>{{ '%.2f'|format(e.entropy) if e.entropy else '-' }}</td>
        <td>{{ '🔴 ' + e.reason if e.suspicious else '🟢' }}</td>
    </tr>{% endfor %}</tbody></table>
</div>""")
    from jinja2 import Template
    return Template(content).render(page="events", detector=detector, flash=None)


@app.route("/alerts")
def alerts_page():
    content = TMPL.replace("{% block c %}{% endblock %}", """
<div class="card">
    <h2>🚨 Detection Alerts ({{ detector.alerts|length }})</h2>
    {% for a in detector.alerts %}
    <div class="alert-card critical">
        <strong>#{{ a.id }} — {{ a.title }}</strong> <span class="badge {{ a.severity }}">{{ a.severity }}</span><br>
        <p style="margin:8px 0;font-size:.85rem">{{ a.description }}</p>
        <span style="font-size:.75rem;color:var(--dim)">MITRE: {{ a.mitre }} | {{ a.action_taken }}</span>
    </div>{% endfor %}
    {% if not detector.alerts %}<p style="color:var(--dim);text-align:center;padding:20px">No alerts. Run a simulation first.</p>{% endif %}
</div>""")
    from jinja2 import Template
    return Template(content).render(page="alerts", detector=detector, flash=None)


if __name__ == "__main__":
    print("\n  🔒 Ransomware Detection — http://localhost:5007\n")
    app.run(debug=True, port=5007)
