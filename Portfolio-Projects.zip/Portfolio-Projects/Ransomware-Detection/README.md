# 🔒 Ransomware Detection System
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)

Windows file system monitor detecting ransomware behavior through entropy analysis, extension monitoring, mass file changes, and automated process killing. Real-time alerting dashboard.

## ✨ Features
- File system monitoring with change detection
- Shannon entropy analysis for encrypted file detection
- Suspicious extension monitoring (.encrypted, .locked, .crypt)
- Mass file change detection (rename/delete rate)
- Shadow copy deletion detection
- Process identification and kill capability
- Real-time Flask dashboard with alerts

## 🚀 Quick Start
```bash
pip install -r requirements.txt
python app.py  # http://localhost:5007
```
## 📜 License — MIT — **Koventhan M**
