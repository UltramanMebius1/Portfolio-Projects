"""
Database models for AI Resume Analyzer.
Defines SQLAlchemy models for storing analysis results and comparisons.
"""

from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
import json

db = SQLAlchemy()


class Analysis(db.Model):
    """Model for storing resume analysis results."""

    __tablename__ = "analyses"

    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    file_size = db.Column(db.Integer, default=0)

    # Extracted Text
    raw_text = db.Column(db.Text, default="")

    # Contact Info (stored as JSON)
    contact_info = db.Column(db.Text, default="{}")

    # ATS Score
    ats_score = db.Column(db.Float, default=0.0)

    # Parsed Data (stored as JSON strings)
    skills_data = db.Column(db.Text, default="[]")
    education_data = db.Column(db.Text, default="[]")
    experience_data = db.Column(db.Text, default="[]")

    # Keyword Analysis (stored as JSON)
    keyword_density = db.Column(db.Text, default="{}")

    # Suggestions (stored as JSON)
    suggestions = db.Column(db.Text, default="[]")

    # Format Score breakdown (stored as JSON)
    score_breakdown = db.Column(db.Text, default="{}")

    # Relationships
    comparisons = db.relationship("Comparison", backref="analysis", lazy=True,
                                  cascade="all, delete-orphan")

    def get_skills(self):
        """Deserialize skills data."""
        try:
            return json.loads(self.skills_data) if self.skills_data else []
        except (json.JSONDecodeError, TypeError):
            return []

    def set_skills(self, skills):
        """Serialize skills data."""
        self.skills_data = json.dumps(skills)

    def get_education(self):
        """Deserialize education data."""
        try:
            return json.loads(self.education_data) if self.education_data else []
        except (json.JSONDecodeError, TypeError):
            return []

    def set_education(self, education):
        """Serialize education data."""
        self.education_data = json.dumps(education)

    def get_experience(self):
        """Deserialize experience data."""
        try:
            return json.loads(self.experience_data) if self.experience_data else []
        except (json.JSONDecodeError, TypeError):
            return []

    def set_experience(self, experience):
        """Serialize experience data."""
        self.experience_data = json.dumps(experience)

    def get_contact_info(self):
        """Deserialize contact info."""
        try:
            return json.loads(self.contact_info) if self.contact_info else {}
        except (json.JSONDecodeError, TypeError):
            return {}

    def set_contact_info(self, info):
        """Serialize contact info."""
        self.contact_info = json.dumps(info)

    def get_keyword_density(self):
        """Deserialize keyword density."""
        try:
            return json.loads(self.keyword_density) if self.keyword_density else {}
        except (json.JSONDecodeError, TypeError):
            return {}

    def set_keyword_density(self, density):
        """Serialize keyword density."""
        self.keyword_density = json.dumps(density)

    def get_suggestions(self):
        """Deserialize suggestions."""
        try:
            return json.loads(self.suggestions) if self.suggestions else []
        except (json.JSONDecodeError, TypeError):
            return []

    def set_suggestions(self, suggestions):
        """Serialize suggestions."""
        self.suggestions = json.dumps(suggestions)

    def get_score_breakdown(self):
        """Deserialize score breakdown."""
        try:
            return json.loads(self.score_breakdown) if self.score_breakdown else {}
        except (json.JSONDecodeError, TypeError):
            return {}

    def set_score_breakdown(self, breakdown):
        """Serialize score breakdown."""
        self.score_breakdown = json.dumps(breakdown)

    def __repr__(self):
        return f"<Analysis {self.id}: {self.filename} - Score: {self.ats_score}>"


class Comparison(db.Model):
    """Model for storing resume vs job description comparison results."""

    __tablename__ = "comparisons"

    id = db.Column(db.Integer, primary_key=True)
    analysis_id = db.Column(db.Integer, db.ForeignKey("analyses.id"), nullable=False)
    job_description = db.Column(db.Text, nullable=False)
    job_title = db.Column(db.String(255), default="")
    comparison_date = db.Column(db.DateTime, default=datetime.utcnow)

    # Match Score (TF-IDF cosine similarity)
    match_score = db.Column(db.Float, default=0.0)

    # Matching & Missing Keywords (stored as JSON)
    matching_keywords = db.Column(db.Text, default="[]")
    missing_keywords = db.Column(db.Text, default="[]")

    # Skill Gap Analysis (stored as JSON)
    skill_gap = db.Column(db.Text, default="{}")

    # Category Scores (stored as JSON) - for radar chart
    category_scores = db.Column(db.Text, default="{}")

    # Recommendations (stored as JSON)
    recommendations = db.Column(db.Text, default="[]")

    def get_matching_keywords(self):
        """Deserialize matching keywords."""
        try:
            return json.loads(self.matching_keywords) if self.matching_keywords else []
        except (json.JSONDecodeError, TypeError):
            return []

    def set_matching_keywords(self, keywords):
        """Serialize matching keywords."""
        self.matching_keywords = json.dumps(keywords)

    def get_missing_keywords(self):
        """Deserialize missing keywords."""
        try:
            return json.loads(self.missing_keywords) if self.missing_keywords else []
        except (json.JSONDecodeError, TypeError):
            return []

    def set_missing_keywords(self, keywords):
        """Serialize missing keywords."""
        self.missing_keywords = json.dumps(keywords)

    def get_skill_gap(self):
        """Deserialize skill gap."""
        try:
            return json.loads(self.skill_gap) if self.skill_gap else {}
        except (json.JSONDecodeError, TypeError):
            return {}

    def set_skill_gap(self, gap):
        """Serialize skill gap."""
        self.skill_gap = json.dumps(gap)

    def get_category_scores(self):
        """Deserialize category scores."""
        try:
            return json.loads(self.category_scores) if self.category_scores else {}
        except (json.JSONDecodeError, TypeError):
            return {}

    def set_category_scores(self, scores):
        """Serialize category scores."""
        self.category_scores = json.dumps(scores)

    def get_recommendations(self):
        """Deserialize recommendations."""
        try:
            return json.loads(self.recommendations) if self.recommendations else []
        except (json.JSONDecodeError, TypeError):
            return []

    def set_recommendations(self, recommendations):
        """Serialize recommendations."""
        self.recommendations = json.dumps(recommendations)

    def __repr__(self):
        return f"<Comparison {self.id}: Analysis {self.analysis_id} - Match: {self.match_score}%>"
