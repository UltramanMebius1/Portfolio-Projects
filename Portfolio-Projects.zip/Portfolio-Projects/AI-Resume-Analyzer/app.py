"""
AI Resume Analyzer - Main Flask Application.
Provides routes for upload, analysis, comparison, history, and export.
"""

import os
import json
from datetime import datetime

from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, jsonify, send_file, make_response,
)
from werkzeug.utils import secure_filename

from config import Config
from models import db, Analysis, Comparison
from analyzer import ResumeAnalyzer, extract_text, compare_with_jd, skill_gap_analysis, parse_skills


# ─────────────────────────────────────────────
# App Factory
# ─────────────────────────────────────────────

def create_app():
    """Create and configure the Flask application."""
    app = Flask(__name__)
    app.config.from_object(Config)
    Config.init_app(app)

    db.init_app(app)

    with app.app_context():
        db.create_all()

    return app


app = create_app()


# ─────────────────────────────────────────────
# Utility Functions
# ─────────────────────────────────────────────

def allowed_file(filename):
    """Check if the uploaded file has an allowed extension."""
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in Config.ALLOWED_EXTENSIONS
    )


# ─────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────

@app.route("/")
def index():
    """Landing page."""
    # Get recent analyses count for stats
    total_analyses = Analysis.query.count()
    return render_template("index.html", total_analyses=total_analyses)


@app.route("/upload")
def upload():
    """Upload page with drag & drop area."""
    return render_template("upload.html")


@app.route("/analyze", methods=["POST"])
def analyze():
    """Handle file upload and run analysis."""
    # Check if file was uploaded
    if "resume" not in request.files:
        flash("No file selected. Please upload a resume.", "error")
        return redirect(url_for("upload"))

    file = request.files["resume"]

    if file.filename == "":
        flash("No file selected. Please choose a file.", "error")
        return redirect(url_for("upload"))

    if not allowed_file(file.filename):
        flash("Invalid file type. Please upload PDF, DOCX, or TXT files.", "error")
        return redirect(url_for("upload"))

    # Save file
    filename = secure_filename(file.filename)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_")
    safe_filename = timestamp + filename
    file_path = os.path.join(Config.UPLOAD_FOLDER, safe_filename)
    file.save(file_path)

    # Get file size
    file_size = os.path.getsize(file_path)

    # Run analysis
    analyzer = ResumeAnalyzer(file_path=file_path)
    results = analyzer.analyze()

    if "error" in results:
        flash(f"Analysis error: {results['error']}", "error")
        return redirect(url_for("upload"))

    # Save to database
    analysis = Analysis(
        filename=filename,
        file_size=file_size,
        raw_text=results["raw_text"],
        ats_score=results["ats_score"],
    )
    analysis.set_contact_info(results["contact_info"])
    analysis.set_skills(results["skills"])
    analysis.set_education(results["education"])
    analysis.set_experience(results["experience"])
    analysis.set_keyword_density(results["keyword_density"])
    analysis.set_suggestions(results["suggestions"])
    analysis.set_score_breakdown(results["score_breakdown"])

    db.session.add(analysis)
    db.session.commit()

    # Clean up uploaded file (optional - keep for re-analysis)
    # os.remove(file_path)

    flash("Resume analyzed successfully!", "success")
    return redirect(url_for("results", analysis_id=analysis.id))


@app.route("/results/<int:analysis_id>")
def results(analysis_id):
    """Display analysis results."""
    analysis = Analysis.query.get_or_404(analysis_id)

    return render_template(
        "results.html",
        analysis=analysis,
        contact_info=analysis.get_contact_info(),
        skills=analysis.get_skills(),
        education=analysis.get_education(),
        experience=analysis.get_experience(),
        keyword_density=analysis.get_keyword_density(),
        suggestions=analysis.get_suggestions(),
        score_breakdown=analysis.get_score_breakdown(),
    )


@app.route("/compare", methods=["GET"])
def compare():
    """Compare page - select resume and enter JD."""
    analyses = Analysis.query.order_by(Analysis.upload_date.desc()).all()
    analysis_id = request.args.get("analysis_id", type=int)
    return render_template("compare.html", analyses=analyses, selected_id=analysis_id)


@app.route("/compare/results", methods=["POST"])
def compare_results():
    """Run comparison between resume and job description."""
    analysis_id = request.form.get("analysis_id", type=int)
    jd_text = request.form.get("job_description", "").strip()
    job_title = request.form.get("job_title", "").strip()

    if not analysis_id:
        flash("Please select a resume to compare.", "error")
        return redirect(url_for("compare"))

    if not jd_text:
        flash("Please enter a job description.", "error")
        return redirect(url_for("compare"))

    analysis = Analysis.query.get_or_404(analysis_id)

    # Run comparison
    analyzer = ResumeAnalyzer(text=analysis.raw_text)
    analyzer.skills = analysis.get_skills()
    analyzer.analyze()

    comparison_data = analyzer.compare(jd_text)

    # Save comparison to database
    comp = Comparison(
        analysis_id=analysis.id,
        job_description=jd_text,
        job_title=job_title or "Untitled Position",
        match_score=comparison_data["match_score"],
    )
    comp.set_matching_keywords(comparison_data.get("matching_keywords", []))
    comp.set_missing_keywords(comparison_data.get("missing_keywords", []))
    comp.set_skill_gap(comparison_data.get("skill_gap", {}))
    comp.set_category_scores(comparison_data.get("category_scores", {}))
    comp.set_recommendations(comparison_data.get("recommendations", []))

    db.session.add(comp)
    db.session.commit()

    return render_template(
        "compare.html",
        analyses=Analysis.query.order_by(Analysis.upload_date.desc()).all(),
        selected_id=analysis_id,
        comparison=comparison_data,
        analysis=analysis,
        job_title=job_title,
        jd_text=jd_text,
        show_results=True,
    )


@app.route("/history")
def history():
    """Display analysis history."""
    analyses = Analysis.query.order_by(Analysis.upload_date.desc()).all()
    return render_template("history.html", analyses=analyses)


@app.route("/history/delete/<int:analysis_id>", methods=["POST"])
def delete_analysis(analysis_id):
    """Delete an analysis record."""
    analysis = Analysis.query.get_or_404(analysis_id)
    db.session.delete(analysis)
    db.session.commit()
    flash("Analysis deleted successfully.", "success")
    return redirect(url_for("history"))


@app.route("/export/<int:analysis_id>")
def export_report(analysis_id):
    """Export analysis report as a downloadable text file."""
    analysis = Analysis.query.get_or_404(analysis_id)

    contact_info = analysis.get_contact_info()
    skills = analysis.get_skills()
    education = analysis.get_education()
    experience = analysis.get_experience()
    suggestions = analysis.get_suggestions()
    score_breakdown = analysis.get_score_breakdown()

    # Build report text
    lines = []
    lines.append("=" * 60)
    lines.append("    AI RESUME ANALYZER - ANALYSIS REPORT")
    lines.append("=" * 60)
    lines.append("")
    lines.append(f"File: {analysis.filename}")
    lines.append(f"Date: {analysis.upload_date.strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"ATS Score: {analysis.ats_score}/100")
    lines.append("")

    # Contact Info
    lines.append("-" * 40)
    lines.append("CONTACT INFORMATION")
    lines.append("-" * 40)
    for key, value in contact_info.items():
        lines.append(f"  {key.title()}: {value}")
    lines.append("")

    # Score Breakdown
    lines.append("-" * 40)
    lines.append("SCORE BREAKDOWN")
    lines.append("-" * 40)
    for section, data in score_breakdown.items():
        if isinstance(data, dict):
            lines.append(f"  {section.title()}: {data.get('score', 0)}/100 (Weight: {data.get('weight', 0) * 100:.0f}%)")
            lines.append(f"    Details: {data.get('details', '')}")
    lines.append("")

    # Skills
    lines.append("-" * 40)
    lines.append("SKILLS FOUND")
    lines.append("-" * 40)
    if isinstance(skills, dict):
        for category, skill_list in skills.items():
            lines.append(f"  {category}:")
            lines.append(f"    {', '.join(skill_list)}")
    lines.append("")

    # Education
    lines.append("-" * 40)
    lines.append("EDUCATION")
    lines.append("-" * 40)
    for edu in education:
        if isinstance(edu, dict):
            lines.append(f"  {edu.get('degree', 'N/A')}")
            if edu.get('institution'):
                lines.append(f"    Institution: {edu['institution']}")
            if edu.get('year'):
                lines.append(f"    Year: {edu['year']}")
    lines.append("")

    # Experience
    lines.append("-" * 40)
    lines.append("EXPERIENCE")
    lines.append("-" * 40)
    for exp in experience:
        if isinstance(exp, dict):
            lines.append(f"  {exp.get('title', 'N/A')}")
            if exp.get('company'):
                lines.append(f"    Company: {exp['company']}")
            if exp.get('date_range'):
                lines.append(f"    Period: {exp['date_range']}")
            for resp in exp.get('responsibilities', []):
                lines.append(f"    • {resp}")
    lines.append("")

    # Suggestions
    lines.append("-" * 40)
    lines.append("IMPROVEMENT SUGGESTIONS")
    lines.append("-" * 40)
    for i, sug in enumerate(suggestions, 1):
        if isinstance(sug, dict):
            priority = sug.get("priority", "medium").upper()
            lines.append(f"  {i}. [{priority}] {sug.get('text', '')}")
    lines.append("")

    lines.append("=" * 60)
    lines.append("    Generated by AI Resume Analyzer")
    lines.append("=" * 60)

    report_text = "\n".join(lines)

    # Create response
    response = make_response(report_text)
    response.headers["Content-Type"] = "text/plain; charset=utf-8"
    response.headers["Content-Disposition"] = (
        f"attachment; filename=resume_analysis_{analysis.id}.txt"
    )
    return response


# ─────────────────────────────────────────────
# Error Handlers
# ─────────────────────────────────────────────

@app.errorhandler(404)
def not_found(e):
    """Handle 404 errors."""
    flash("Page not found.", "error")
    return redirect(url_for("index"))


@app.errorhandler(413)
def file_too_large(e):
    """Handle file too large errors."""
    flash("File is too large. Maximum size is 16 MB.", "error")
    return redirect(url_for("upload"))


@app.errorhandler(500)
def internal_error(e):
    """Handle 500 errors."""
    db.session.rollback()
    flash("An internal error occurred. Please try again.", "error")
    return redirect(url_for("index"))


# ─────────────────────────────────────────────
# Main Entry Point
# ─────────────────────────────────────────────

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
