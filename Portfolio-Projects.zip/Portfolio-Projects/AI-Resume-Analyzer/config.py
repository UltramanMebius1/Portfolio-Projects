"""
Configuration module for AI Resume Analyzer.
Handles all application settings including file upload, database, and security.
"""

import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    """Base configuration class."""

    # Security
    SECRET_KEY = os.environ.get("SECRET_KEY", "ai-resume-analyzer-secret-key-2024")

    # File Upload Settings
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max file size
    ALLOWED_EXTENSIONS = {"pdf", "docx", "doc", "txt"}

    # Database
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'resume_analyzer.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Analysis Settings
    MIN_ATS_SCORE = 0
    MAX_ATS_SCORE = 100
    SKILLS_MATCH_WEIGHT = 0.35
    KEYWORD_MATCH_WEIGHT = 0.25
    FORMAT_SCORE_WEIGHT = 0.20
    EXPERIENCE_WEIGHT = 0.20

    @staticmethod
    def init_app(app):
        """Initialize application with config."""
        os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)


class DevelopmentConfig(Config):
    """Development configuration."""
    DEBUG = True


class ProductionConfig(Config):
    """Production configuration."""
    DEBUG = False


config = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig,
}
