"""
Core Resume Analysis Engine.
Handles text extraction, parsing, scoring, and comparison using NLP techniques.
"""

import re
import os
from collections import Counter

try:
    import PyPDF2
except ImportError:
    PyPDF2 = None

try:
    import docx
except ImportError:
    docx = None

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
except ImportError:
    TfidfVectorizer = None
    cosine_similarity = None


# ─────────────────────────────────────────────
# Comprehensive Skills Database (100+ skills)
# ─────────────────────────────────────────────

SKILLS_DATABASE = {
    "programming_languages": [
        "python", "javascript", "typescript", "java", "c++", "c#", "go", "golang",
        "rust", "ruby", "php", "swift", "kotlin", "scala", "r", "matlab",
        "perl", "haskell", "lua", "dart", "objective-c", "assembly",
        "vba", "cobol", "fortran", "elixir", "clojure", "erlang",
        "groovy", "julia", "sql", "bash", "shell", "powershell",
    ],
    "frontend": [
        "react", "reactjs", "react.js", "angular", "angularjs", "vue", "vuejs",
        "vue.js", "svelte", "next.js", "nextjs", "nuxt.js", "nuxtjs",
        "html", "html5", "css", "css3", "sass", "scss", "less",
        "tailwind", "tailwindcss", "bootstrap", "material-ui", "mui",
        "jquery", "webpack", "vite", "babel", "redux", "mobx",
        "styled-components", "emotion", "chakra-ui", "ant-design",
        "gatsby", "remix", "astro", "alpine.js",
    ],
    "backend": [
        "flask", "django", "fastapi", "node.js", "nodejs", "express",
        "express.js", "expressjs", "spring", "spring boot", "springboot",
        "rails", "ruby on rails", "laravel", "asp.net", ".net", "dotnet",
        "gin", "fiber", "actix", "rocket", "nestjs", "nest.js",
        "koa", "hapi", "strapi", "graphql", "rest", "restful",
        "rest api", "rest apis", "grpc", "soap", "microservices",
        "serverless", "websocket", "websockets",
    ],
    "databases": [
        "postgresql", "postgres", "mysql", "mariadb", "sqlite",
        "mongodb", "redis", "cassandra", "dynamodb", "couchdb",
        "elasticsearch", "neo4j", "firebase", "supabase",
        "oracle", "sql server", "mssql", "memcached",
        "influxdb", "timescaledb", "cockroachdb",
    ],
    "cloud_devops": [
        "aws", "amazon web services", "azure", "microsoft azure",
        "gcp", "google cloud", "google cloud platform",
        "docker", "kubernetes", "k8s", "terraform", "ansible",
        "jenkins", "circleci", "travis ci", "github actions",
        "gitlab ci", "ci/cd", "cicd", "devops",
        "ec2", "s3", "lambda", "rds", "ecs", "eks", "fargate",
        "cloudformation", "helm", "istio", "nginx", "apache",
        "heroku", "vercel", "netlify", "digitalocean",
        "vagrant", "puppet", "chef", "prometheus", "grafana",
        "datadog", "new relic", "splunk", "elk stack",
    ],
    "data_ml": [
        "machine learning", "deep learning", "artificial intelligence", "ai",
        "tensorflow", "pytorch", "keras", "scikit-learn", "sklearn",
        "pandas", "numpy", "scipy", "matplotlib", "seaborn",
        "nlp", "natural language processing", "computer vision",
        "opencv", "hugging face", "transformers", "bert", "gpt",
        "data science", "data analysis", "data engineering",
        "etl", "data pipeline", "apache spark", "spark",
        "hadoop", "hive", "airflow", "dbt", "snowflake",
        "tableau", "power bi", "looker", "metabase",
        "feature engineering", "model deployment",
    ],
    "tools_practices": [
        "git", "github", "gitlab", "bitbucket", "svn",
        "jira", "confluence", "trello", "asana", "notion",
        "slack", "swagger", "openapi", "postman",
        "agile", "scrum", "kanban", "tdd", "bdd",
        "code review", "pair programming", "mob programming",
        "design patterns", "solid", "clean code",
        "linux", "unix", "windows server",
    ],
    "testing": [
        "unit testing", "integration testing", "e2e testing",
        "pytest", "jest", "mocha", "chai", "jasmine",
        "selenium", "cypress", "playwright", "puppeteer",
        "testng", "junit", "rspec", "load testing",
        "performance testing", "security testing",
        "test automation", "qa", "quality assurance",
    ],
    "security": [
        "cybersecurity", "penetration testing", "owasp",
        "encryption", "ssl", "tls", "https", "oauth",
        "jwt", "sso", "ldap", "active directory",
        "firewall", "ids", "ips", "siem",
        "vulnerability assessment", "security audit",
        "iso 27001", "soc 2", "gdpr", "compliance",
    ],
    "mobile": [
        "android", "ios", "react native", "flutter",
        "xamarin", "ionic", "cordova", "swift ui", "swiftui",
        "jetpack compose", "mobile development",
    ],
    "soft_skills": [
        "leadership", "communication", "teamwork", "collaboration",
        "problem solving", "problem-solving", "critical thinking",
        "project management", "time management", "mentoring",
        "stakeholder management", "presentation",
        "cross-functional", "strategic planning",
    ],
}

# Flatten all skills for quick lookup
ALL_SKILLS = set()
SKILL_CATEGORIES = {}
for category, skills in SKILLS_DATABASE.items():
    for skill in skills:
        ALL_SKILLS.add(skill.lower())
        SKILL_CATEGORIES[skill.lower()] = category


# ─────────────────────────────────────────────
# Section Keywords for Parsing
# ─────────────────────────────────────────────

SECTION_HEADERS = {
    "education": [
        "education", "academic", "qualification", "degree", "university",
        "college", "school", "coursework", "academic background",
    ],
    "experience": [
        "experience", "work experience", "employment", "professional experience",
        "work history", "career", "positions held", "job history",
    ],
    "skills": [
        "skills", "technical skills", "core competencies", "technologies",
        "proficiencies", "expertise", "tools", "frameworks",
    ],
    "certifications": [
        "certifications", "certificates", "accreditations", "licenses",
        "professional development", "credentials",
    ],
    "projects": [
        "projects", "personal projects", "side projects", "portfolio",
        "open source", "open-source",
    ],
    "summary": [
        "summary", "professional summary", "objective", "about",
        "profile", "career objective", "about me",
    ],
}

EDUCATION_KEYWORDS = [
    "bachelor", "master", "phd", "doctorate", "associate",
    "b.s.", "b.a.", "m.s.", "m.a.", "mba", "b.sc", "m.sc",
    "b.tech", "m.tech", "b.e.", "m.e.", "bca", "mca",
    "diploma", "certificate", "degree", "university",
    "college", "institute", "school", "academy",
    "computer science", "engineering", "information technology",
    "mathematics", "physics", "business", "management",
    "gpa", "cgpa", "honors", "cum laude", "magna cum laude",
    "summa cum laude", "dean's list", "distinction",
]

EXPERIENCE_KEYWORDS = [
    "engineer", "developer", "manager", "analyst", "designer",
    "architect", "lead", "senior", "junior", "intern",
    "consultant", "specialist", "coordinator", "director",
    "associate", "administrator", "technician", "officer",
    "present", "current",
]


# ─────────────────────────────────────────────
# Text Extraction
# ─────────────────────────────────────────────

def extract_text_from_pdf(file_path):
    """Extract text content from a PDF file using PyPDF2."""
    if PyPDF2 is None:
        return "Error: PyPDF2 not installed."

    text = ""
    try:
        with open(file_path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
    except Exception as e:
        return f"Error extracting PDF text: {str(e)}"

    return text.strip()


def extract_text_from_docx(file_path):
    """Extract text content from a DOCX file using python-docx."""
    if docx is None:
        return "Error: python-docx not installed."

    text = ""
    try:
        doc = docx.Document(file_path)
        for paragraph in doc.paragraphs:
            if paragraph.text.strip():
                text += paragraph.text + "\n"

        # Also extract from tables
        for table in doc.tables:
            for row in table.rows:
                row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
                if row_text:
                    text += row_text + "\n"
    except Exception as e:
        return f"Error extracting DOCX text: {str(e)}"

    return text.strip()


def extract_text_from_txt(file_path):
    """Extract text from a plain text file."""
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read().strip()
    except Exception as e:
        return f"Error reading text file: {str(e)}"


def extract_text(file_path):
    """Extract text from a file based on its extension."""
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".pdf":
        return extract_text_from_pdf(file_path)
    elif ext in (".docx", ".doc"):
        return extract_text_from_docx(file_path)
    elif ext == ".txt":
        return extract_text_from_txt(file_path)
    else:
        return "Unsupported file format."


# ─────────────────────────────────────────────
# Contact Information Parsing
# ─────────────────────────────────────────────

def parse_contact_info(text):
    """Extract contact information from resume text."""
    contact = {}

    # Email
    email_pattern = r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
    emails = re.findall(email_pattern, text)
    if emails:
        contact["email"] = emails[0]

    # Phone
    phone_pattern = r"(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"
    phones = re.findall(phone_pattern, text)
    if phones:
        contact["phone"] = phones[0].strip()

    # LinkedIn
    linkedin_pattern = r"(?:linkedin\.com/in/|linkedin:\s*)([a-zA-Z0-9\-_]+)"
    linkedin = re.findall(linkedin_pattern, text, re.IGNORECASE)
    if linkedin:
        contact["linkedin"] = f"linkedin.com/in/{linkedin[0]}"

    # GitHub
    github_pattern = r"(?:github\.com/|github:\s*)([a-zA-Z0-9\-_]+)"
    github = re.findall(github_pattern, text, re.IGNORECASE)
    if github:
        contact["github"] = f"github.com/{github[0]}"

    # Location
    location_pattern = r"(?:Location|Address|City|Based in)[:\s]+([A-Za-z\s,]+(?:,\s*[A-Z]{2})?)(?:\n|$)"
    location = re.findall(location_pattern, text, re.IGNORECASE)
    if location:
        contact["location"] = location[0].strip()
    else:
        # Try to find city, state pattern
        city_state = re.findall(r"([A-Z][a-z]+(?:\s[A-Z][a-z]+)*,\s*[A-Z]{2})\b", text)
        if city_state:
            contact["location"] = city_state[0]

    # Name (usually first line or first prominent text)
    lines = text.strip().split("\n")
    for line in lines[:5]:
        line = line.strip()
        if line and not re.search(r"[@\.\d]", line) and len(line.split()) <= 5:
            # Likely a name if it's short and doesn't contain email/numbers
            if not any(kw in line.lower() for kw in ["resume", "curriculum", "cv", "page"]):
                contact["name"] = line
                break

    return contact


# ─────────────────────────────────────────────
# Skills Parsing
# ─────────────────────────────────────────────

def parse_skills(text):
    """
    Parse and categorize skills from resume text.
    Uses the comprehensive skills database with 100+ skills.
    Returns a dict of categorized skills found.
    """
    text_lower = text.lower()
    found_skills = {}
    found_set = set()

    for category, skills in SKILLS_DATABASE.items():
        category_found = []
        for skill in skills:
            skill_lower = skill.lower()
            # Use word boundary matching for short skills to avoid false positives
            if len(skill_lower) <= 2:
                pattern = r"\b" + re.escape(skill_lower) + r"\b"
                if re.search(pattern, text_lower):
                    if skill_lower not in found_set:
                        category_found.append(skill)
                        found_set.add(skill_lower)
            else:
                if skill_lower in text_lower:
                    if skill_lower not in found_set:
                        category_found.append(skill)
                        found_set.add(skill_lower)

        if category_found:
            # Format category name
            display_name = category.replace("_", " ").title()
            found_skills[display_name] = sorted(category_found, key=str.lower)

    return found_skills


def get_flat_skills(skills_dict):
    """Flatten categorized skills into a single list."""
    flat = []
    for category_skills in skills_dict.values():
        flat.extend(category_skills)
    return flat


# ─────────────────────────────────────────────
# Education Parsing
# ─────────────────────────────────────────────

def parse_education(text):
    """Parse education entries from resume text."""
    education = []
    text_lower = text.lower()

    # Find education section
    edu_start = -1
    lines = text.split("\n")

    for i, line in enumerate(lines):
        line_lower = line.lower().strip()
        if any(header in line_lower for header in SECTION_HEADERS["education"]):
            edu_start = i
            break

    if edu_start == -1:
        # Try to find education info without explicit section header
        degree_pattern = r"(?:Bachelor|Master|Ph\.?D|Doctorate|Associate|B\.S\.|B\.A\.|M\.S\.|M\.A\.|MBA|B\.Tech|M\.Tech|B\.E\.|M\.E\.|BCA|MCA|Diploma)[\w\s]*(?:in|of)?\s*[\w\s]*"
        degrees = re.findall(degree_pattern, text, re.IGNORECASE)
        for degree in degrees:
            education.append({
                "degree": degree.strip(),
                "institution": "",
                "year": "",
                "details": "",
            })
        return education

    # Parse lines after education header
    edu_end = len(lines)
    for i in range(edu_start + 1, len(lines)):
        line_lower = lines[i].lower().strip()
        # Check if we've hit another section
        for section, headers in SECTION_HEADERS.items():
            if section != "education" and any(header in line_lower for header in headers):
                edu_end = i
                break
        if edu_end != len(lines):
            break

    edu_lines = lines[edu_start + 1 : edu_end]
    current_entry = None

    for line in edu_lines:
        line = line.strip()
        if not line or line.startswith("==="):
            continue

        # Check if this line contains a degree
        has_degree = any(kw in line.lower() for kw in [
            "bachelor", "master", "phd", "doctorate", "associate",
            "b.s.", "b.a.", "m.s.", "m.a.", "mba", "b.tech", "m.tech",
            "diploma", "certificate",
        ])

        has_institution = any(kw in line.lower() for kw in [
            "university", "college", "institute", "school", "academy",
        ])

        if has_degree or has_institution:
            if current_entry:
                education.append(current_entry)

            # Extract year
            years = re.findall(r"(?:19|20)\d{2}", line)
            year = years[-1] if years else ""

            current_entry = {
                "degree": line.split("|")[0].strip() if "|" in line else line,
                "institution": line.split("|")[1].strip() if "|" in line and len(line.split("|")) > 1 else "",
                "year": year,
                "details": "",
            }
        elif current_entry and line.startswith("-"):
            detail = line.lstrip("- ").strip()
            if current_entry["details"]:
                current_entry["details"] += "; " + detail
            else:
                current_entry["details"] = detail

    if current_entry:
        education.append(current_entry)

    return education


# ─────────────────────────────────────────────
# Experience Parsing
# ─────────────────────────────────────────────

def parse_experience(text):
    """Parse work experience entries from resume text."""
    experience = []
    lines = text.split("\n")

    # Find experience section
    exp_start = -1
    for i, line in enumerate(lines):
        line_lower = line.lower().strip()
        if any(header in line_lower for header in SECTION_HEADERS["experience"]):
            exp_start = i
            break

    if exp_start == -1:
        return experience

    # Find end of experience section
    exp_end = len(lines)
    for i in range(exp_start + 1, len(lines)):
        line_lower = lines[i].lower().strip()
        for section, headers in SECTION_HEADERS.items():
            if section != "experience" and any(header in line_lower for header in headers):
                exp_end = i
                break
        if exp_end != len(lines):
            break

    exp_lines = lines[exp_start + 1 : exp_end]
    current_entry = None

    for line in exp_lines:
        line = line.strip()
        if not line or line.startswith("==="):
            continue

        # Check if this is a role title line (contains | or common role keywords)
        has_role = any(kw in line.lower() for kw in EXPERIENCE_KEYWORDS)
        has_separator = "|" in line
        has_date = bool(re.search(r"(?:19|20)\d{2}|present|current", line, re.IGNORECASE))

        if (has_role and (has_separator or has_date)) or (has_separator and has_date):
            if current_entry:
                experience.append(current_entry)

            parts = [p.strip() for p in line.split("|")]

            # Extract date range
            date_range = ""
            date_match = re.search(
                r"((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+\d{4}\s*[-–]\s*(?:(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+\d{4}|Present|Current))",
                line, re.IGNORECASE,
            )
            if date_match:
                date_range = date_match.group(1)

            current_entry = {
                "title": parts[0] if parts else line,
                "company": parts[1] if len(parts) > 1 else "",
                "date_range": date_range or (parts[-1] if len(parts) > 2 else ""),
                "responsibilities": [],
            }
        elif current_entry and line.startswith("-"):
            responsibility = line.lstrip("- ").strip()
            if responsibility:
                current_entry["responsibilities"].append(responsibility)
        elif current_entry and line and not line.startswith("-"):
            # Could be a continuation of responsibilities
            if current_entry["responsibilities"]:
                current_entry["responsibilities"][-1] += " " + line

    if current_entry:
        experience.append(current_entry)

    return experience


# ─────────────────────────────────────────────
# ATS Score Calculation
# ─────────────────────────────────────────────

def calculate_ats_score(text, skills_dict, education, experience, contact_info):
    """
    Calculate ATS compatibility score (0-100).
    Evaluates resume on multiple dimensions.
    """
    score_breakdown = {}
    total_score = 0

    # 1. Skills Score (35% weight) - Based on number and diversity of skills
    all_skills = get_flat_skills(skills_dict)
    skills_count = len(all_skills)
    categories_count = len(skills_dict)

    if skills_count >= 20:
        skills_score = 100
    elif skills_count >= 15:
        skills_score = 90
    elif skills_count >= 10:
        skills_score = 75
    elif skills_count >= 5:
        skills_score = 60
    elif skills_count >= 1:
        skills_score = 40
    else:
        skills_score = 10

    # Bonus for skill diversity (multiple categories)
    if categories_count >= 5:
        skills_score = min(100, skills_score + 10)

    score_breakdown["skills"] = {
        "score": skills_score,
        "weight": 0.35,
        "details": f"{skills_count} skills across {categories_count} categories",
    }
    total_score += skills_score * 0.35

    # 2. Contact Information Score (10% weight)
    contact_fields = ["email", "phone", "linkedin", "github", "name", "location"]
    contact_filled = sum(1 for f in contact_fields if f in contact_info)
    contact_score = min(100, (contact_filled / len(contact_fields)) * 100)
    score_breakdown["contact"] = {
        "score": round(contact_score),
        "weight": 0.10,
        "details": f"{contact_filled}/{len(contact_fields)} fields found",
    }
    total_score += contact_score * 0.10

    # 3. Education Score (15% weight)
    if len(education) >= 2:
        edu_score = 100
    elif len(education) == 1:
        edu_score = 75
    else:
        edu_score = 30

    # Check for advanced degree
    text_lower = text.lower()
    if any(kw in text_lower for kw in ["master", "phd", "doctorate", "m.s.", "m.a."]):
        edu_score = min(100, edu_score + 15)

    score_breakdown["education"] = {
        "score": min(100, edu_score),
        "weight": 0.15,
        "details": f"{len(education)} education entries found",
    }
    total_score += min(100, edu_score) * 0.15

    # 4. Experience Score (25% weight)
    if len(experience) >= 3:
        exp_score = 100
    elif len(experience) == 2:
        exp_score = 80
    elif len(experience) == 1:
        exp_score = 60
    else:
        exp_score = 20

    # Check for quantified achievements
    quantified = len(re.findall(r"\d+[%+]|\$[\d,]+|\d+[xX]|\d+\+", text))
    if quantified >= 5:
        exp_score = min(100, exp_score + 15)
    elif quantified >= 2:
        exp_score = min(100, exp_score + 10)

    score_breakdown["experience"] = {
        "score": min(100, exp_score),
        "weight": 0.25,
        "details": f"{len(experience)} positions, {quantified} quantified achievements",
    }
    total_score += min(100, exp_score) * 0.25

    # 5. Formatting & Content Quality Score (15% weight)
    format_score = 50  # Base score
    word_count = len(text.split())

    # Word count check
    if 300 <= word_count <= 1500:
        format_score += 20
    elif 200 <= word_count <= 2000:
        format_score += 10

    # Action verbs check
    action_verbs = [
        "developed", "built", "designed", "implemented", "led", "managed",
        "created", "architected", "optimized", "improved", "reduced",
        "increased", "deployed", "automated", "established", "launched",
        "maintained", "collaborated", "delivered", "engineered",
    ]
    verb_count = sum(1 for verb in action_verbs if verb in text_lower)
    if verb_count >= 8:
        format_score += 20
    elif verb_count >= 4:
        format_score += 10

    # Section completeness
    sections_found = 0
    for section, headers in SECTION_HEADERS.items():
        if any(h in text_lower for h in headers):
            sections_found += 1
    if sections_found >= 4:
        format_score += 10
    elif sections_found >= 2:
        format_score += 5

    format_score = min(100, format_score)
    score_breakdown["formatting"] = {
        "score": format_score,
        "weight": 0.15,
        "details": f"{word_count} words, {verb_count} action verbs, {sections_found} sections",
    }
    total_score += format_score * 0.15

    return round(total_score), score_breakdown


# ─────────────────────────────────────────────
# Keyword Density Analysis
# ─────────────────────────────────────────────

def analyze_keyword_density(text, top_n=20):
    """
    Analyze keyword density in resume text.
    Returns top N most frequent meaningful keywords.
    """
    # Common stop words to exclude
    stop_words = {
        "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "do", "does", "did", "will", "would", "could",
        "should", "may", "might", "can", "shall", "to", "of", "in", "for",
        "on", "with", "at", "by", "from", "as", "into", "through", "during",
        "before", "after", "above", "below", "between", "under", "again",
        "further", "then", "once", "here", "there", "when", "where", "why",
        "how", "all", "each", "every", "both", "few", "more", "most", "other",
        "some", "such", "no", "not", "only", "own", "same", "so", "than",
        "too", "very", "just", "because", "if", "or", "and", "but", "nor",
        "yet", "also", "about", "up", "out", "off", "over", "this", "that",
        "these", "those", "i", "me", "my", "we", "our", "you", "your", "he",
        "she", "it", "they", "them", "their", "its", "his", "her", "what",
        "which", "who", "whom", "while", "am", "us", "etc",
    }

    # Tokenize and clean
    words = re.findall(r"\b[a-zA-Z]{2,}\b", text.lower())
    filtered_words = [w for w in words if w not in stop_words and len(w) > 2]

    # Count frequencies
    word_freq = Counter(filtered_words)
    total_words = len(filtered_words)

    # Calculate density
    keyword_density = {}
    for word, count in word_freq.most_common(top_n):
        density = round((count / total_words) * 100, 2) if total_words > 0 else 0
        keyword_density[word] = {
            "count": count,
            "density": density,
        }

    return keyword_density


# ─────────────────────────────────────────────
# Resume vs Job Description Comparison
# ─────────────────────────────────────────────

def compare_with_jd(resume_text, jd_text):
    """
    Compare resume with job description using TF-IDF vectorization
    and cosine similarity.
    Returns match score and detailed analysis.
    """
    if TfidfVectorizer is None or cosine_similarity is None:
        return {
            "match_score": 0,
            "error": "scikit-learn not installed",
        }

    # TF-IDF Vectorization
    vectorizer = TfidfVectorizer(
        stop_words="english",
        max_features=5000,
        ngram_range=(1, 2),  # Unigrams and bigrams
        min_df=1,
    )

    try:
        tfidf_matrix = vectorizer.fit_transform([resume_text, jd_text])
        similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
        match_score = round(similarity * 100, 1)
    except Exception:
        match_score = 0

    # Find matching and missing keywords
    resume_lower = resume_text.lower()
    jd_lower = jd_text.lower()

    # Extract important terms from JD
    jd_words = set(re.findall(r"\b[a-zA-Z]{3,}\b", jd_lower))
    resume_words = set(re.findall(r"\b[a-zA-Z]{3,}\b", resume_lower))

    stop_words = {
        "the", "and", "for", "are", "but", "not", "you", "all", "can",
        "had", "her", "was", "one", "our", "out", "has", "his", "how",
        "its", "may", "new", "now", "old", "see", "way", "who", "did",
        "get", "let", "say", "she", "too", "use", "will", "with", "from",
        "this", "that", "have", "been", "they", "their", "what", "when",
        "make", "like", "time", "just", "know", "take", "come", "than",
        "look", "only", "into", "year", "your", "some", "them", "also",
        "about", "would", "there", "other", "which", "these", "then",
        "could", "after", "more", "such", "should", "over", "each",
        "including", "work", "working", "experience", "able", "strong",
    }

    # Filter out stop words from JD keywords
    jd_important = jd_words - stop_words
    matching_keywords = sorted(list(jd_important & resume_words))[:30]
    missing_keywords = sorted(list(jd_important - resume_words))[:20]

    # Also check for skill matches
    resume_skills = parse_skills(resume_text)
    jd_skills = parse_skills(jd_text)

    resume_flat = set(s.lower() for s in get_flat_skills(resume_skills))
    jd_flat = set(s.lower() for s in get_flat_skills(jd_skills))

    matching_skills = sorted(list(resume_flat & jd_flat))
    missing_skills = sorted(list(jd_flat - resume_flat))

    # Category scores for radar chart
    category_scores = {}
    for category in SKILLS_DATABASE:
        display_name = category.replace("_", " ").title()
        resume_cat = set(s.lower() for s in resume_skills.get(display_name, []))
        jd_cat = set(s.lower() for s in jd_skills.get(display_name, []))

        if jd_cat:
            cat_score = round(len(resume_cat & jd_cat) / len(jd_cat) * 100)
        else:
            cat_score = 100 if resume_cat else 50  # No requirements = neutral

        category_scores[display_name] = cat_score

    # Filter out categories with no data on either side for cleaner radar
    category_scores = {k: v for k, v in category_scores.items()
                       if k in jd_skills or k in resume_skills}

    return {
        "match_score": match_score,
        "matching_keywords": matching_keywords,
        "missing_keywords": missing_keywords,
        "matching_skills": matching_skills,
        "missing_skills": missing_skills,
        "category_scores": category_scores,
    }


# ─────────────────────────────────────────────
# Skill Gap Analysis
# ─────────────────────────────────────────────

def skill_gap_analysis(resume_skills, jd_text):
    """
    Perform detailed skill gap analysis comparing resume skills
    against job description requirements.
    """
    jd_skills = parse_skills(jd_text)

    resume_flat = set(s.lower() for s in get_flat_skills(resume_skills))
    jd_flat = set(s.lower() for s in get_flat_skills(jd_skills))

    matched = resume_flat & jd_flat
    gaps = jd_flat - resume_flat
    extras = resume_flat - jd_flat

    # Categorize gaps
    gap_by_category = {}
    for skill in gaps:
        category = SKILL_CATEGORIES.get(skill, "other")
        display_name = category.replace("_", " ").title()
        if display_name not in gap_by_category:
            gap_by_category[display_name] = []
        gap_by_category[display_name].append(skill)

    match_percentage = round(len(matched) / len(jd_flat) * 100) if jd_flat else 0

    return {
        "matched_skills": sorted(list(matched)),
        "missing_skills": sorted(list(gaps)),
        "extra_skills": sorted(list(extras)),
        "gap_by_category": gap_by_category,
        "match_percentage": match_percentage,
        "total_required": len(jd_flat),
        "total_matched": len(matched),
    }


# ─────────────────────────────────────────────
# Suggestions Generation
# ─────────────────────────────────────────────

def generate_suggestions(text, skills_dict, education, experience, contact_info, ats_score):
    """Generate actionable suggestions for resume improvement."""
    suggestions = []
    text_lower = text.lower()

    # Contact Info Suggestions
    if "email" not in contact_info:
        suggestions.append({
            "category": "Contact",
            "priority": "high",
            "text": "Add a professional email address to your resume.",
            "icon": "envelope",
        })
    if "phone" not in contact_info:
        suggestions.append({
            "category": "Contact",
            "priority": "high",
            "text": "Include a phone number for easy communication.",
            "icon": "telephone",
        })
    if "linkedin" not in contact_info:
        suggestions.append({
            "category": "Contact",
            "priority": "medium",
            "text": "Add your LinkedIn profile URL to improve professional visibility.",
            "icon": "linkedin",
        })
    if "github" not in contact_info:
        suggestions.append({
            "category": "Contact",
            "priority": "medium",
            "text": "Include a GitHub profile link to showcase your projects and code.",
            "icon": "github",
        })

    # Skills Suggestions
    all_skills = get_flat_skills(skills_dict)
    if len(all_skills) < 10:
        suggestions.append({
            "category": "Skills",
            "priority": "high",
            "text": "Add more relevant technical skills. Aim for at least 15-20 skills across multiple categories.",
            "icon": "lightning",
        })

    if "programming_languages" not in [k.lower().replace(" ", "_") for k in skills_dict]:
        suggestions.append({
            "category": "Skills",
            "priority": "high",
            "text": "List specific programming languages you're proficient in.",
            "icon": "code-slash",
        })

    if not any(cat.lower() in ["cloud devops", "cloud_devops"] for cat in skills_dict):
        suggestions.append({
            "category": "Skills",
            "priority": "medium",
            "text": "Consider adding cloud/DevOps skills (AWS, Docker, Kubernetes) — highly in-demand.",
            "icon": "cloud",
        })

    # Experience Suggestions
    if len(experience) == 0:
        suggestions.append({
            "category": "Experience",
            "priority": "high",
            "text": "Add work experience entries with clear role titles, companies, and dates.",
            "icon": "briefcase",
        })

    # Check for quantified achievements
    quantified = len(re.findall(r"\d+[%+]|\$[\d,]+|\d+[xX]|\d+\+", text))
    if quantified < 3:
        suggestions.append({
            "category": "Experience",
            "priority": "high",
            "text": "Quantify your achievements with numbers (e.g., 'Reduced costs by 30%', 'Managed 5-person team').",
            "icon": "graph-up",
        })

    # Check for action verbs
    action_verbs = [
        "developed", "built", "designed", "implemented", "led", "managed",
        "created", "optimized", "improved", "reduced", "increased",
        "deployed", "automated", "architected", "delivered",
    ]
    verb_count = sum(1 for verb in action_verbs if verb in text_lower)
    if verb_count < 5:
        suggestions.append({
            "category": "Experience",
            "priority": "medium",
            "text": "Use strong action verbs to start bullet points (e.g., 'Architected', 'Deployed', 'Optimized').",
            "icon": "pencil",
        })

    # Education Suggestions
    if len(education) == 0:
        suggestions.append({
            "category": "Education",
            "priority": "medium",
            "text": "Include your educational background with degree, institution, and graduation year.",
            "icon": "mortarboard",
        })

    # Content Quality Suggestions
    word_count = len(text.split())
    if word_count < 200:
        suggestions.append({
            "category": "Content",
            "priority": "high",
            "text": "Your resume seems too short. Aim for 400-800 words for a comprehensive resume.",
            "icon": "file-text",
        })
    elif word_count > 1500:
        suggestions.append({
            "category": "Content",
            "priority": "medium",
            "text": "Your resume may be too long. Consider condensing to 1-2 pages for better readability.",
            "icon": "file-text",
        })

    if "summary" not in text_lower and "objective" not in text_lower and "profile" not in text_lower:
        suggestions.append({
            "category": "Content",
            "priority": "medium",
            "text": "Add a professional summary or objective at the top of your resume.",
            "icon": "card-text",
        })

    if "certification" not in text_lower and "certified" not in text_lower:
        suggestions.append({
            "category": "Content",
            "priority": "low",
            "text": "Consider adding relevant certifications to strengthen your credentials.",
            "icon": "award",
        })

    if "project" not in text_lower:
        suggestions.append({
            "category": "Content",
            "priority": "low",
            "text": "Include a projects section to showcase hands-on work and initiative.",
            "icon": "folder",
        })

    # ATS-Specific Suggestions
    if ats_score < 50:
        suggestions.append({
            "category": "ATS",
            "priority": "high",
            "text": "Your ATS score is below average. Focus on using standard section headings and including more relevant keywords.",
            "icon": "exclamation-triangle",
        })

    # Sort by priority
    priority_order = {"high": 0, "medium": 1, "low": 2}
    suggestions.sort(key=lambda x: priority_order.get(x["priority"], 3))

    return suggestions


# ─────────────────────────────────────────────
# Resume Analyzer Class
# ─────────────────────────────────────────────

class ResumeAnalyzer:
    """
    Main class that orchestrates the complete resume analysis pipeline.
    """

    def __init__(self, file_path=None, text=None):
        """Initialize with either a file path or raw text."""
        self.file_path = file_path
        self.raw_text = text or ""
        self.contact_info = {}
        self.skills = {}
        self.education = []
        self.experience = []
        self.ats_score = 0
        self.score_breakdown = {}
        self.keyword_density = {}
        self.suggestions = []

    def extract(self):
        """Extract text from file."""
        if self.file_path and not self.raw_text:
            self.raw_text = extract_text(self.file_path)
        return self.raw_text

    def analyze(self):
        """Run the complete analysis pipeline."""
        if not self.raw_text:
            self.extract()

        if not self.raw_text or self.raw_text.startswith("Error"):
            return {
                "error": self.raw_text or "No text extracted from file.",
            }

        # Parse all components
        self.contact_info = parse_contact_info(self.raw_text)
        self.skills = parse_skills(self.raw_text)
        self.education = parse_education(self.raw_text)
        self.experience = parse_experience(self.raw_text)

        # Calculate scores
        self.ats_score, self.score_breakdown = calculate_ats_score(
            self.raw_text, self.skills, self.education,
            self.experience, self.contact_info,
        )

        # Keyword analysis
        self.keyword_density = analyze_keyword_density(self.raw_text)

        # Generate suggestions
        self.suggestions = generate_suggestions(
            self.raw_text, self.skills, self.education,
            self.experience, self.contact_info, self.ats_score,
        )

        return self.get_results()

    def compare(self, jd_text):
        """Compare resume against a job description."""
        comparison = compare_with_jd(self.raw_text, jd_text)
        gap = skill_gap_analysis(self.skills, jd_text)
        comparison["skill_gap"] = gap

        # Generate comparison-specific recommendations
        recommendations = []
        if comparison["match_score"] < 40:
            recommendations.append(
                "Your resume has a low match with this job description. Consider tailoring it specifically for this role."
            )
        if gap["missing_skills"]:
            top_missing = gap["missing_skills"][:5]
            recommendations.append(
                f"Consider acquiring these in-demand skills: {', '.join(top_missing)}"
            )
        if len(comparison.get("missing_keywords", [])) > 10:
            recommendations.append(
                "Add more relevant keywords from the job description to improve ATS matching."
            )
        if gap["match_percentage"] >= 70:
            recommendations.append(
                "Strong skill match! Focus on highlighting relevant project experience."
            )

        comparison["recommendations"] = recommendations
        return comparison

    def get_results(self):
        """Return all analysis results as a dictionary."""
        return {
            "raw_text": self.raw_text,
            "contact_info": self.contact_info,
            "skills": self.skills,
            "flat_skills": get_flat_skills(self.skills),
            "education": self.education,
            "experience": self.experience,
            "ats_score": self.ats_score,
            "score_breakdown": self.score_breakdown,
            "keyword_density": self.keyword_density,
            "suggestions": self.suggestions,
        }
